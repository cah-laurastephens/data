CREATE FUNCTION void_out()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.void_out(void)
  RETURNS cstring
AS
$BODY$
void_out
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

