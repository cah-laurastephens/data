CREATE FUNCTION tintervalsend()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.tintervalsend(tinterval)
  RETURNS bytea
AS
$BODY$
tintervalsend
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

