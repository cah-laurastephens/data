CREATE FUNCTION strpos()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.strpos(text, text)
  RETURNS int4
AS
$BODY$
textpos
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

