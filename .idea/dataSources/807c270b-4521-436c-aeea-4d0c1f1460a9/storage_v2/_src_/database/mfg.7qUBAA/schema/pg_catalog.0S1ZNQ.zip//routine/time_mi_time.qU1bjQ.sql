CREATE FUNCTION time_mi_time()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.time_mi_time(time, time)
  RETURNS interval
AS
$BODY$
time_mi_time
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

