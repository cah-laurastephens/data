CREATE FUNCTION timestamptz_out()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamptz_out(timestamptz)
  RETURNS cstring
AS
$BODY$
timestamptz_out
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

