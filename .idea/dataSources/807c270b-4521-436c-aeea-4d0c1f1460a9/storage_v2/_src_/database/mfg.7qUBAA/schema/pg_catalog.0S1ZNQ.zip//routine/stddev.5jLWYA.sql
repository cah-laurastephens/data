CREATE FUNCTION stddev()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.stddev(float8)
  RETURNS float8
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
$$;

