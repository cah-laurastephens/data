CREATE FUNCTION xidsend()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.xidsend(xid)
  RETURNS bytea
AS
$BODY$
xidsend
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

