CREATE FUNCTION pow()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.pow(float8, float8)
  RETURNS float8
AS
$BODY$
dpow
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

