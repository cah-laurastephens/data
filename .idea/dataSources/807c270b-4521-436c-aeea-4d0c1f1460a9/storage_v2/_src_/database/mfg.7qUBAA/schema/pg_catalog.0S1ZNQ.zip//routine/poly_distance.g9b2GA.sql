CREATE FUNCTION poly_distance()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.poly_distance(polygon, polygon)
  RETURNS float8
AS
$BODY$
poly_distance
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

