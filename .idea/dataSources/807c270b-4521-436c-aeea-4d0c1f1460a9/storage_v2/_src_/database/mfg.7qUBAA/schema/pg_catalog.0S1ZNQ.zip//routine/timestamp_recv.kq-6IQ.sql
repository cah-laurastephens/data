CREATE FUNCTION timestamp_recv()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamp_recv(internal)
  RETURNS timestamp
AS
$BODY$
timestamp_recv
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

