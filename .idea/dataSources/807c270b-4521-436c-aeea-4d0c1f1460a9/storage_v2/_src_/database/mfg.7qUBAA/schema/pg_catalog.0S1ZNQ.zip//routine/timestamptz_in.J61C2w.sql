CREATE FUNCTION timestamptz_in()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamptz_in(cstring, oid, int4)
  RETURNS timestamptz
AS
$BODY$
timestamptz_in
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

