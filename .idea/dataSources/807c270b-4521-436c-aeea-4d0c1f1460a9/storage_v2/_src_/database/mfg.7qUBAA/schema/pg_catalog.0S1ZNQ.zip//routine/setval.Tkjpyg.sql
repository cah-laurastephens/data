CREATE FUNCTION setval()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.setval(text, int8)
  RETURNS int8
AS
$BODY$
setval
$BODY$
LANGUAGE internal VOLATILE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.setval(text, int8, bool)
  RETURNS int8
AS
$BODY$
setval_and_iscalled
$BODY$
LANGUAGE internal VOLATILE STRICT;
$$;

