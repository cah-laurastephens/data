CREATE FUNCTION text_pattern_ne()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.text_pattern_ne(text, text)
  RETURNS bool
AS
$BODY$
text_pattern_ne
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

