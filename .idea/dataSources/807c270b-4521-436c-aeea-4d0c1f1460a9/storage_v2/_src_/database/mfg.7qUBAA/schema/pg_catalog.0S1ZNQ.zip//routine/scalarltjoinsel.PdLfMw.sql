CREATE FUNCTION scalarltjoinsel()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.scalarltjoinsel(internal, oid, internal, int2)
  RETURNS float8
AS
$BODY$
scalarltjoinsel
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

