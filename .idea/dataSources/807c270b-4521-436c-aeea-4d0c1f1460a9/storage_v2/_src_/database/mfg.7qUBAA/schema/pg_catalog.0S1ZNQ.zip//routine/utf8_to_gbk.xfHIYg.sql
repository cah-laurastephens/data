CREATE FUNCTION utf8_to_gbk()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.utf8_to_gbk(int4, int4, cstring, internal, int4)
  RETURNS void
AS
'246C69626469722F757466385F616E645F67626B', 'utf8_to_gbk'VOLATILE STRICT;
$$;

