CREATE FUNCTION timetz_in()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timetz_in(cstring, oid, int4)
  RETURNS timetz
AS
$BODY$
timetz_in
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

