CREATE FUNCTION tintervalend()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.tintervalend(tinterval)
  RETURNS abstime
AS
$BODY$
tintervalend
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

