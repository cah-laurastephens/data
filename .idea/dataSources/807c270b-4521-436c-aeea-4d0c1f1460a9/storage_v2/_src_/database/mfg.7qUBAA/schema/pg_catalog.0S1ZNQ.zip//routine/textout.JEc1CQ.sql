CREATE FUNCTION textout()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.textout(text)
  RETURNS cstring
AS
$BODY$
textout
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

