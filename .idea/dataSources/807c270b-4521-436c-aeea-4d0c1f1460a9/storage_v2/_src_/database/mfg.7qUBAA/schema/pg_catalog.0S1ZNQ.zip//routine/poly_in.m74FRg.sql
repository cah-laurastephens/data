CREATE FUNCTION poly_in()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.poly_in(cstring)
  RETURNS polygon
AS
$BODY$
poly_in
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

