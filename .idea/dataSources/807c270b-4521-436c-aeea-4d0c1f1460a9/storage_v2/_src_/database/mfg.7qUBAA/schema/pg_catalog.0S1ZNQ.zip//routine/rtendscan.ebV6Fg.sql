CREATE FUNCTION rtendscan()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.rtendscan(internal)
  RETURNS void
AS
$BODY$
rtendscan
$BODY$
LANGUAGE internal VOLATILE STRICT;
$$;

