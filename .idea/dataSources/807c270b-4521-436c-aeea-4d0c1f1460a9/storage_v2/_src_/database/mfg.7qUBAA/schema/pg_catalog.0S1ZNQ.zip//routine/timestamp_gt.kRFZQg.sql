CREATE FUNCTION timestamp_gt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamp_gt(timestamp, timestamp)
  RETURNS bool
AS
$BODY$
timestamp_gt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

