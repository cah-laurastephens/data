CREATE FUNCTION xidout()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.xidout(xid)
  RETURNS cstring
AS
$BODY$
xidout
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

