CREATE FUNCTION unknownout()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.unknownout(unknown)
  RETURNS cstring
AS
$BODY$
unknownout
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

