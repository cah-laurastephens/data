CREATE FUNCTION tintervallenne()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.tintervallenne(tinterval, reltime)
  RETURNS bool
AS
$BODY$
tintervallenne
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

