CREATE FUNCTION upper()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.upper(text)
  RETURNS text
AS
$BODY$
upper
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

