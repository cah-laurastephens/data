CREATE FUNCTION timestamp_ne()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamp_ne(timestamp, timestamp)
  RETURNS bool
AS
$BODY$
timestamp_ne
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

