CREATE FUNCTION tintervallenle()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.tintervallenle(tinterval, reltime)
  RETURNS bool
AS
$BODY$
tintervallenle
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

