CREATE FUNCTION timepl()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timepl(abstime, reltime)
  RETURNS abstime
AS
$BODY$
timepl
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

