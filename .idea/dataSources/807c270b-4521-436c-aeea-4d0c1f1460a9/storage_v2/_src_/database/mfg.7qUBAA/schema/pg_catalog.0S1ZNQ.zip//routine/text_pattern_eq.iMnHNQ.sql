CREATE FUNCTION text_pattern_eq()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.text_pattern_eq(text, text)
  RETURNS bool
AS
$BODY$
text_pattern_eq
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

