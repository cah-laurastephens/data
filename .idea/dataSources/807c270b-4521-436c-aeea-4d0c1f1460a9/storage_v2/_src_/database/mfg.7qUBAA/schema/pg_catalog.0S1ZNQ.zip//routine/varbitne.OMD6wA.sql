CREATE FUNCTION varbitne()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.varbitne(varbit, varbit)
  RETURNS bool
AS
$BODY$
bitne
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

