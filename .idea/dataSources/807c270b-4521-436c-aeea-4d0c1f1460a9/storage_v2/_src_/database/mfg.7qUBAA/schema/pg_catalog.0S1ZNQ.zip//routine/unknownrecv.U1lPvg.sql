CREATE FUNCTION unknownrecv()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.unknownrecv(internal)
  RETURNS unknown
AS
$BODY$
unknownrecv
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

