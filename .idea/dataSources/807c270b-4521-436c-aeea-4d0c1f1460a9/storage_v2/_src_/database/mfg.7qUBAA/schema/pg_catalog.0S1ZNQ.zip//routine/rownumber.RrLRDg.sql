CREATE FUNCTION rownumber()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.rownumber(int8, tid, int8)
  RETURNS int8
AS
$BODY$
ff_rownumber
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

