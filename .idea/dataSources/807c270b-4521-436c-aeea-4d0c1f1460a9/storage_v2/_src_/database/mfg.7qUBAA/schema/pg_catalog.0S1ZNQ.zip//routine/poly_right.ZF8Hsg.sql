CREATE FUNCTION poly_right()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.poly_right(polygon, polygon)
  RETURNS bool
AS
$BODY$
poly_right
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

