CREATE FUNCTION point_recv()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.point_recv(internal)
  RETURNS float8[]
AS
$BODY$
point_recv
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

