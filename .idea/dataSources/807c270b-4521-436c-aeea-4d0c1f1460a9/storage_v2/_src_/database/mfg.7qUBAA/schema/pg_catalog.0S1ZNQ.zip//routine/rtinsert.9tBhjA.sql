CREATE FUNCTION rtinsert()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.rtinsert(internal, internal, internal, internal, internal, internal)
  RETURNS internal
AS
$BODY$
rtinsert
$BODY$
LANGUAGE internal VOLATILE STRICT;
$$;

