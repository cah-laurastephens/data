CREATE FUNCTION timestamptz_smaller()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamptz_smaller(timestamptz, timestamptz)
  RETURNS timestamptz
AS
$BODY$
timestamp_smaller
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

