CREATE FUNCTION tideq()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.tideq(tid, tid)
  RETURNS bool
AS
$BODY$
tideq
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

