CREATE FUNCTION regexnesel()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.regexnesel(internal, oid, internal, int4)
  RETURNS float8
AS
$BODY$
regexnesel
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

