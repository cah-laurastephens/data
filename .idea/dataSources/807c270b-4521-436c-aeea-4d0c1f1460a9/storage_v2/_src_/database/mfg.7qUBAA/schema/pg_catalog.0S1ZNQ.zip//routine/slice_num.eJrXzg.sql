CREATE FUNCTION slice_num()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.slice_num()
  RETURNS int4
AS
$BODY$
ff_slice_num
$BODY$
LANGUAGE internal VOLATILE STRICT;
$$;

