CREATE FUNCTION quote_literal()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.quote_literal(text)
  RETURNS text
AS
$BODY$
quote_literal
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

