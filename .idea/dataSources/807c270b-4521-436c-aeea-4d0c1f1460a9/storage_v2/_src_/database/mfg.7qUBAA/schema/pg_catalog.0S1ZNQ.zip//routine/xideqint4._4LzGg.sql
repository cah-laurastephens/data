CREATE FUNCTION xideqint4()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.xideqint4(xid, int4)
  RETURNS bool
AS
$BODY$
xideq
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

