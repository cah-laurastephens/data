CREATE FUNCTION timestamptz_le_date()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamptz_le_date(timestamptz, date)
  RETURNS bool
AS
$BODY$
timestamptz_le_date
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

