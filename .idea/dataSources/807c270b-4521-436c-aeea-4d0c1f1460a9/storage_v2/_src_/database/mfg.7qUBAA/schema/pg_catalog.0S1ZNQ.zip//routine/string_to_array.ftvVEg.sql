CREATE FUNCTION string_to_array()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.string_to_array(text, text)
  RETURNS text[]
AS
$BODY$
text_to_array
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

