CREATE FUNCTION regoperatorout()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.regoperatorout(regoperator)
  RETURNS cstring
AS
$BODY$
regoperatorout
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

