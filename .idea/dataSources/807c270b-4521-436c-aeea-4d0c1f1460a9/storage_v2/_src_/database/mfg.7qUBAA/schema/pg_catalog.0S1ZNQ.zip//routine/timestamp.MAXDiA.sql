CREATE FUNCTION timestamp()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamp(text)
  RETURNS timestamp
AS
$BODY$
text_timestamp
$BODY$
LANGUAGE internal STABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.timestamp(abstime)
  RETURNS timestamp
AS
$BODY$
abstime_timestamp
$BODY$
LANGUAGE internal STABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.timestamp(bpchar)
  RETURNS timestamp
AS
$BODY$
bpchar_timestamp
$BODY$
LANGUAGE internal STABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.timestamp(date)
  RETURNS timestamp
AS
$BODY$
date_timestamp
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.timestamp(timestamptz)
  RETURNS timestamp
AS
$BODY$
timestamptz_timestamp
$BODY$
LANGUAGE internal STABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.timestamp(timestamp, int4)
  RETURNS timestamp
AS
$BODY$
timestamp_scale
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.timestamp(date, time)
  RETURNS timestamp
AS
$BODY$
datetime_timestamp
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

