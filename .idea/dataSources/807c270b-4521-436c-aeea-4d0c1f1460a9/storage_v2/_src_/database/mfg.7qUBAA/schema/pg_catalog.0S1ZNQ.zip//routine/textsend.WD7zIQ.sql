CREATE FUNCTION textsend()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.textsend(text)
  RETURNS bytea
AS
$BODY$
textsend
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

