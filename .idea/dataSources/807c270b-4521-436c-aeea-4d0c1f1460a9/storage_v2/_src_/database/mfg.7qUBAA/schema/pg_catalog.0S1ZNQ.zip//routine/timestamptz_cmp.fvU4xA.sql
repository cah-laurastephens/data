CREATE FUNCTION timestamptz_cmp()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamptz_cmp(timestamptz, timestamptz)
  RETURNS int4
AS
$BODY$
timestamp_cmp
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

