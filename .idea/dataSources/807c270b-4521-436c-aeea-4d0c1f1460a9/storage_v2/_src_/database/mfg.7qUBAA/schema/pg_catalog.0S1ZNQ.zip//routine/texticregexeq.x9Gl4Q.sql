CREATE FUNCTION texticregexeq()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.texticregexeq(text, text)
  RETURNS bool
AS
$BODY$
texticregexeq
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

