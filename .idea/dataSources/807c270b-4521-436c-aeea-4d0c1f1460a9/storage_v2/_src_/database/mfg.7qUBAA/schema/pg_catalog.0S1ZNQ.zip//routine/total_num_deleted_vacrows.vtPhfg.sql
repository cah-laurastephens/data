CREATE FUNCTION total_num_deleted_vacrows()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.total_num_deleted_vacrows(int8)
  RETURNS int8
AS
$BODY$
ff_total_num_deleted_vacrows
$BODY$
LANGUAGE internal VOLATILE STRICT;
$$;

