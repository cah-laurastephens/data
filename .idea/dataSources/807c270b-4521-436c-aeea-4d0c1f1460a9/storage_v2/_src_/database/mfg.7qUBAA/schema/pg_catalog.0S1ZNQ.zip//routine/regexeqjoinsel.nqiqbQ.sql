CREATE FUNCTION regexeqjoinsel()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.regexeqjoinsel(internal, oid, internal, int2)
  RETURNS float8
AS
$BODY$
regexeqjoinsel
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

