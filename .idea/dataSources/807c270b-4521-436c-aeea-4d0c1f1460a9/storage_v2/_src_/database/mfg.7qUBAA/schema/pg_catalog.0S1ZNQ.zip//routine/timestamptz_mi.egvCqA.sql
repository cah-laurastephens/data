CREATE FUNCTION timestamptz_mi()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamptz_mi(timestamptz, timestamptz)
  RETURNS interval
AS
$BODY$
timestamp_mi
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

