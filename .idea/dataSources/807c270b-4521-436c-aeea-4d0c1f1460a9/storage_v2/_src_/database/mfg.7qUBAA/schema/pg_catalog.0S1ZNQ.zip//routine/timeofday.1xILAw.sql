CREATE FUNCTION timeofday()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timeofday()
  RETURNS text
AS
$BODY$
timeofday
$BODY$
LANGUAGE internal VOLATILE STRICT;
$$;

