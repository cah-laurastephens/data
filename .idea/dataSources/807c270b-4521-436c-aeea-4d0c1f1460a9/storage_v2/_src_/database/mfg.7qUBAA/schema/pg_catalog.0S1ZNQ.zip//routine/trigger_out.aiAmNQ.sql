CREATE FUNCTION trigger_out()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.trigger_out(trigger)
  RETURNS cstring
AS
$BODY$
trigger_out
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

