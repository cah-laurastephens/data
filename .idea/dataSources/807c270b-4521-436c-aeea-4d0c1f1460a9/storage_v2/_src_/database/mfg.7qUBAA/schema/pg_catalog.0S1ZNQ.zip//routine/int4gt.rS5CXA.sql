CREATE FUNCTION int4gt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.int4gt(int4, int4)
  RETURNS bool
AS
$BODY$
int4gt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

