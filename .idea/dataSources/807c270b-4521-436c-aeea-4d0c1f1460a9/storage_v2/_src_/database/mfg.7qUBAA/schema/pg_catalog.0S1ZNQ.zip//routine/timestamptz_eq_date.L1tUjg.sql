CREATE FUNCTION timestamptz_eq_date()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamptz_eq_date(timestamptz, date)
  RETURNS bool
AS
$BODY$
timestamptz_eq_date
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

