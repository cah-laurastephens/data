CREATE FUNCTION split_part()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.split_part(text, text, int4)
  RETURNS text
AS
$BODY$
split_text
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

