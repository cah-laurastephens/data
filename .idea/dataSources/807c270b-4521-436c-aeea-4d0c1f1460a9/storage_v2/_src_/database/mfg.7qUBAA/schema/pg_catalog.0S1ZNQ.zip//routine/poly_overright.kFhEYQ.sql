CREATE FUNCTION poly_overright()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.poly_overright(polygon, polygon)
  RETURNS bool
AS
$BODY$
poly_overright
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

