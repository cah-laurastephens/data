CREATE FUNCTION timestamptz_mi_int8()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamptz_mi_int8(timestamptz, int8)
  RETURNS timestamptz
AS
$BODY$
timestamptz_mi_int8
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

