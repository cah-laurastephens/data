CREATE FUNCTION slope()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.slope(float8[], float8[])
  RETURNS float8
AS
$BODY$
point_slope
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

