CREATE FUNCTION rtbeginscan()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.rtbeginscan(internal, internal, internal)
  RETURNS internal
AS
$BODY$
rtbeginscan
$BODY$
LANGUAGE internal VOLATILE STRICT;
$$;

