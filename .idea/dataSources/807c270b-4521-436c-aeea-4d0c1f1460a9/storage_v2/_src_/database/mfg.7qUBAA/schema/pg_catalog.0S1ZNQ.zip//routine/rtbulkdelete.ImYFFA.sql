CREATE FUNCTION rtbulkdelete()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.rtbulkdelete(internal, internal, internal)
  RETURNS internal
AS
$BODY$
rtbulkdelete
$BODY$
LANGUAGE internal VOLATILE STRICT;
$$;

