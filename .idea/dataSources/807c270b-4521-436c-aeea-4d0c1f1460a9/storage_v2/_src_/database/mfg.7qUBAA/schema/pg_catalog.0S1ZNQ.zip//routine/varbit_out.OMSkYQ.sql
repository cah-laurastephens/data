CREATE FUNCTION varbit_out()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.varbit_out(varbit)
  RETURNS cstring
AS
$BODY$
varbit_out
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

