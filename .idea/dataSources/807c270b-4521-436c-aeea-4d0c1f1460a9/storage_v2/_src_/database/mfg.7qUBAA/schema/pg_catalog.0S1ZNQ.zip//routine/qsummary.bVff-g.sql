CREATE FUNCTION qsummary()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.qsummary(int8)
  RETURNS varchar
AS
$BODY$
qsummary_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.qsummary(int2)
  RETURNS varchar
AS
$BODY$
qsummary_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.qsummary(int4)
  RETURNS varchar
AS
$BODY$
qsummary_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.qsummary(float4)
  RETURNS varchar
AS
$BODY$
qsummary_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.qsummary(float8)
  RETURNS varchar
AS
$BODY$
qsummary_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.qsummary(varchar)
  RETURNS varchar
AS
$BODY$
qsummary_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.qsummary(date)
  RETURNS varchar
AS
$BODY$
qsummary_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.qsummary(timestamp)
  RETURNS varchar
AS
$BODY$
qsummary_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.qsummary(timestamptz)
  RETURNS varchar
AS
$BODY$
qsummary_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.qsummary(numeric)
  RETURNS varchar
AS
$BODY$
qsummary_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
$$;

