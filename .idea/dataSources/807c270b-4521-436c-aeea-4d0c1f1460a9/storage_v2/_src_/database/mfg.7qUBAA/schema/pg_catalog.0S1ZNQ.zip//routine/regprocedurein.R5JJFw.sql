CREATE FUNCTION regprocedurein()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.regprocedurein(cstring)
  RETURNS regprocedure
AS
$BODY$
regprocedurein
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

