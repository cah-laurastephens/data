CREATE FUNCTION scalargtjoinsel()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.scalargtjoinsel(internal, oid, internal, int2)
  RETURNS float8
AS
$BODY$
scalargtjoinsel
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

