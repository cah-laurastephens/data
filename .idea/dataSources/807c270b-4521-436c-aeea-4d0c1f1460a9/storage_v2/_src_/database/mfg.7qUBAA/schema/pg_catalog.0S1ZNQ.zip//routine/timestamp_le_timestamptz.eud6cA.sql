CREATE FUNCTION timestamp_le_timestamptz()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamp_le_timestamptz(timestamp, timestamptz)
  RETURNS bool
AS
$BODY$
timestamp_le_timestamptz
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

