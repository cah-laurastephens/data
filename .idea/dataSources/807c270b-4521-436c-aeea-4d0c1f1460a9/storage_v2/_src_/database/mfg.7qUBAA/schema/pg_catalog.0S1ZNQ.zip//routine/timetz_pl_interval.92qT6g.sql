CREATE FUNCTION timetz_pl_interval()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timetz_pl_interval(timetz, interval)
  RETURNS timetz
AS
$BODY$
timetz_pl_interval
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

