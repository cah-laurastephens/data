CREATE FUNCTION timestamptz_lt_date()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamptz_lt_date(timestamptz, date)
  RETURNS bool
AS
$BODY$
timestamptz_lt_date
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

