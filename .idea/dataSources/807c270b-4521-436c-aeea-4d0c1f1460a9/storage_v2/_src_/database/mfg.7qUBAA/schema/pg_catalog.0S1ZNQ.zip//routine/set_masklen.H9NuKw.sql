CREATE FUNCTION set_masklen()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.set_masklen(inet, int4)
  RETURNS inet
AS
$BODY$
inet_set_masklen
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

