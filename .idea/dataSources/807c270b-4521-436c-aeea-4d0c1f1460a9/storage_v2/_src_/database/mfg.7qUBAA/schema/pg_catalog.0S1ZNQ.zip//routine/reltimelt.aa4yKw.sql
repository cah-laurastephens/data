CREATE FUNCTION reltimelt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.reltimelt(reltime, reltime)
  RETURNS bool
AS
$BODY$
reltimelt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

