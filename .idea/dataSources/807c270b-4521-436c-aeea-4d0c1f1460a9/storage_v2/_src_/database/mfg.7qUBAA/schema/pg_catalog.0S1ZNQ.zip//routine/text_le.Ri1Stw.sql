CREATE FUNCTION text_le()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.text_le(text, text)
  RETURNS bool
AS
$BODY$
text_le
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

