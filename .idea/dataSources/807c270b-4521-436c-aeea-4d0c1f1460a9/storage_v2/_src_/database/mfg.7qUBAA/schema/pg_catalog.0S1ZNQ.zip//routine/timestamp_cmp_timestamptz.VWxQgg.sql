CREATE FUNCTION timestamp_cmp_timestamptz()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamp_cmp_timestamptz(timestamp, timestamptz)
  RETURNS int4
AS
$BODY$
timestamp_cmp_timestamptz
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

