CREATE FUNCTION pt_contained_poly()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.pt_contained_poly(float8[], polygon)
  RETURNS bool
AS
$BODY$
pt_contained_poly
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

