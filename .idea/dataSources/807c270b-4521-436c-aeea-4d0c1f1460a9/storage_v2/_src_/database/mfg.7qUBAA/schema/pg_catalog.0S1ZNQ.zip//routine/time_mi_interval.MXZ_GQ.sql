CREATE FUNCTION time_mi_interval()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.time_mi_interval(time, interval)
  RETURNS time
AS
$BODY$
time_mi_interval
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

