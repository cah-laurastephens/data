CREATE FUNCTION var_pop()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.var_pop(float8)
  RETURNS float8
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
$$;

