CREATE FUNCTION rt_poly_union()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.rt_poly_union(polygon, polygon)
  RETURNS polygon
AS
$BODY$
rt_poly_union
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

