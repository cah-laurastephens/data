CREATE FUNCTION smgrout()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.smgrout(smgr)
  RETURNS cstring
AS
$BODY$
smgrout
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

