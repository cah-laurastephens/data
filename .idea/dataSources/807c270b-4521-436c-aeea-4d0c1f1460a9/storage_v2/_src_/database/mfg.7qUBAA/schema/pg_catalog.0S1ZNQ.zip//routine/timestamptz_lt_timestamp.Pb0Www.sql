CREATE FUNCTION timestamptz_lt_timestamp()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamptz_lt_timestamp(timestamptz, timestamp)
  RETURNS bool
AS
$BODY$
timestamptz_lt_timestamp
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

