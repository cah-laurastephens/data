CREATE FUNCTION time_ge()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.time_ge(time, time)
  RETURNS bool
AS
$BODY$
time_ge
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

