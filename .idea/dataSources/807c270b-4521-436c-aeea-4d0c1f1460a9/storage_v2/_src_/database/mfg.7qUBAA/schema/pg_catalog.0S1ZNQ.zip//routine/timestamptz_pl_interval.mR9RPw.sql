CREATE FUNCTION timestamptz_pl_interval()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamptz_pl_interval(timestamptz, interval)
  RETURNS timestamptz
AS
$BODY$
timestamptz_pl_interval
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

