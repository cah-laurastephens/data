CREATE FUNCTION translate()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.translate(text, text, text)
  RETURNS text
AS
$BODY$
translate
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

