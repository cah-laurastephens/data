CREATE FUNCTION regoperrecv()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.regoperrecv(internal)
  RETURNS regoper
AS
$BODY$
regoperrecv
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

