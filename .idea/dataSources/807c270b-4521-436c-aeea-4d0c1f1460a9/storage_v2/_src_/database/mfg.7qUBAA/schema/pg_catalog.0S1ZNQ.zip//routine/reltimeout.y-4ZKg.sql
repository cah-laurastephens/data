CREATE FUNCTION reltimeout()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.reltimeout(reltime)
  RETURNS cstring
AS
$BODY$
reltimeout
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

