CREATE FUNCTION time_eq()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.time_eq(time, time)
  RETURNS bool
AS
$BODY$
time_eq
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

