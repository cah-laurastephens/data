CREATE FUNCTION tintervallengt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.tintervallengt(tinterval, reltime)
  RETURNS bool
AS
$BODY$
tintervallengt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

