CREATE FUNCTION regexp_substr()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.regexp_substr(text, text)
  RETURNS text
AS
$BODY$
select regexp_substr($1, $2, 1, 1, '')
$BODY$
LANGUAGE sql IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.regexp_substr(text, text, int4)
  RETURNS text
AS
$BODY$
select regexp_substr($1, $2, $3, 1, '')
$BODY$
LANGUAGE sql IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.regexp_substr(text, text, int4, int4)
  RETURNS text
AS
$BODY$
select regexp_substr($1, $2, $3, $4, '')
$BODY$
LANGUAGE sql IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.regexp_substr(text, text, int4, int4, text)
  RETURNS text
AS
$BODY$
textregexsubstr
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

