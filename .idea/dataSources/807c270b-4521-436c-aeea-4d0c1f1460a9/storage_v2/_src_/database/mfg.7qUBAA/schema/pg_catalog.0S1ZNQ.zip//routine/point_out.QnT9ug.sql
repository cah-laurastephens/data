CREATE FUNCTION point_out()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.point_out(float8[])
  RETURNS cstring
AS
$BODY$
point_out
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

