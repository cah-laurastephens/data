CREATE FUNCTION point_vert()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.point_vert(float8[], float8[])
  RETURNS bool
AS
$BODY$
point_vert
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

