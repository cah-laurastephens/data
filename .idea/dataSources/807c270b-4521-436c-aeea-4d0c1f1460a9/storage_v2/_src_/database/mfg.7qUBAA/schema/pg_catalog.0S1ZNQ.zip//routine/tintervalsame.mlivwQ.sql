CREATE FUNCTION tintervalsame()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.tintervalsame(tinterval, tinterval)
  RETURNS bool
AS
$BODY$
tintervalsame
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

