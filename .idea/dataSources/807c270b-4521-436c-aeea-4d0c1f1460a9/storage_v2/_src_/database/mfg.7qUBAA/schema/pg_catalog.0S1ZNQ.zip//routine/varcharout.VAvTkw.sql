CREATE FUNCTION varcharout()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.varcharout(varchar)
  RETURNS cstring
AS
$BODY$
varcharout
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

