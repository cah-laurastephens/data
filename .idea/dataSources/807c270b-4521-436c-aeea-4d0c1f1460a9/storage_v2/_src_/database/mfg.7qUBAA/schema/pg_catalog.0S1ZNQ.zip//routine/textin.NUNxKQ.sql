CREATE FUNCTION textin()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.textin(cstring)
  RETURNS text
AS
$BODY$
textin
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

