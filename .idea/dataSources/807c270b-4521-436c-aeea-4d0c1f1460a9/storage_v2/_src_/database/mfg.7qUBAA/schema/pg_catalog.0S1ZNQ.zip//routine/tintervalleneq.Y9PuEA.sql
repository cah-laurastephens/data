CREATE FUNCTION tintervalleneq()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.tintervalleneq(tinterval, reltime)
  RETURNS bool
AS
$BODY$
tintervalleneq
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

