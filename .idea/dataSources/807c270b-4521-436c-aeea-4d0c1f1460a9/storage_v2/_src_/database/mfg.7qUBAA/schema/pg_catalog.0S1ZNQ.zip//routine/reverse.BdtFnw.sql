CREATE FUNCTION reverse()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.reverse(text)
  RETURNS text
AS
$BODY$
reverse
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

