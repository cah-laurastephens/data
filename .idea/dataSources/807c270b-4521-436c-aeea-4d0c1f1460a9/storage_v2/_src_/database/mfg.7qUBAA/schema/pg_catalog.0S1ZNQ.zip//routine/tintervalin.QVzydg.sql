CREATE FUNCTION tintervalin()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.tintervalin(cstring)
  RETURNS tinterval
AS
$BODY$
tintervalin
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

