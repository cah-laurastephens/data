CREATE FUNCTION time_send()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.time_send(time)
  RETURNS bytea
AS
$BODY$
time_send
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

