CREATE FUNCTION regprocin()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.regprocin(cstring)
  RETURNS regproc
AS
$BODY$
regprocin
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

