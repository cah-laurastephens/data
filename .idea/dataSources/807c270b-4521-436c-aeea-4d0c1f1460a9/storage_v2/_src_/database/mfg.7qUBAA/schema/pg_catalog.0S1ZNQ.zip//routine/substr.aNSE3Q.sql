CREATE FUNCTION substr()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.substr(bytea, int4)
  RETURNS bytea
AS
$BODY$
bytea_substr_no_len
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.substr(text, int4)
  RETURNS text
AS
$BODY$
text_substr_no_len
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.substr(bytea, int4, int4)
  RETURNS bytea
AS
$BODY$
bytea_substr
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.substr(text, int4, int4)
  RETURNS text
AS
$BODY$
text_substr
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.substr(bpchar, int4, int4)
  RETURNS bpchar
AS
$BODY$
char_substr
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

