CREATE FUNCTION timetz_ne()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timetz_ne(timetz, timetz)
  RETURNS bool
AS
$BODY$
timetz_ne
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

