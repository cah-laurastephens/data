CREATE FUNCTION tintervalrecv()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.tintervalrecv(internal)
  RETURNS tinterval
AS
$BODY$
tintervalrecv
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

