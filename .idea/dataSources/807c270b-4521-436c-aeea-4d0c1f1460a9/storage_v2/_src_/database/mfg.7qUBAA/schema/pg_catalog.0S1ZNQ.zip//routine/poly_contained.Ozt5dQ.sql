CREATE FUNCTION poly_contained()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.poly_contained(polygon, polygon)
  RETURNS bool
AS
$BODY$
poly_contained
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

