CREATE FUNCTION to_timestamp()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.to_timestamp(text, text)
  RETURNS timestamptz
AS
$BODY$
to_timestamp
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

