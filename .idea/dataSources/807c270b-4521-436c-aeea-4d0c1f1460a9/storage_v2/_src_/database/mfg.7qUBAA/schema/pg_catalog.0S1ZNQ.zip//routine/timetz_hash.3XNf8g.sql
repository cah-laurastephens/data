CREATE FUNCTION timetz_hash()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timetz_hash(timetz)
  RETURNS int4
AS
$BODY$
timetz_hash
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

