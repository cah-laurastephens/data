CREATE FUNCTION poly_same()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.poly_same(polygon, polygon)
  RETURNS bool
AS
$BODY$
poly_same
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

