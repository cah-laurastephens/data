CREATE FUNCTION to_number()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.to_number(text, text)
  RETURNS numeric
AS
$BODY$
numeric_to_number
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

