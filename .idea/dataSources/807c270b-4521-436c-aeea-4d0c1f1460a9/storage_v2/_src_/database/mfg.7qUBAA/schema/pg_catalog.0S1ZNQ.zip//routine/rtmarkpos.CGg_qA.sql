CREATE FUNCTION rtmarkpos()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.rtmarkpos(internal)
  RETURNS void
AS
$BODY$
rtmarkpos
$BODY$
LANGUAGE internal VOLATILE STRICT;
$$;

