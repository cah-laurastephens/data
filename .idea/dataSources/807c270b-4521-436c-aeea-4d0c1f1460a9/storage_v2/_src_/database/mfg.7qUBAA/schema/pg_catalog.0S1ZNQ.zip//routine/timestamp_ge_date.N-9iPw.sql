CREATE FUNCTION timestamp_ge_date()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamp_ge_date(timestamp, date)
  RETURNS bool
AS
$BODY$
timestamp_ge_date
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

