CREATE FUNCTION timestamp_mi()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamp_mi(timestamp, timestamp)
  RETURNS interval
AS
$BODY$
timestamp_mi
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

