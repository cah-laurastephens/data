CREATE FUNCTION tobpchar()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.tobpchar(varchar, int4, bool)
  RETURNS bpchar
AS
$BODY$
varchar2bpchar
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

