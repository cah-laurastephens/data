CREATE FUNCTION timestamp_cmp()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamp_cmp(timestamp, timestamp)
  RETURNS int4
AS
$BODY$
timestamp_cmp
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

