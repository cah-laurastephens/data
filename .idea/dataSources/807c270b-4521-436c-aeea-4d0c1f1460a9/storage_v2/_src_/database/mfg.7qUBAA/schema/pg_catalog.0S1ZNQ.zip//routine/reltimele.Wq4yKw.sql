CREATE FUNCTION reltimele()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.reltimele(reltime, reltime)
  RETURNS bool
AS
$BODY$
reltimele
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

