CREATE FUNCTION poly_contain()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.poly_contain(polygon, polygon)
  RETURNS bool
AS
$BODY$
poly_contain
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

