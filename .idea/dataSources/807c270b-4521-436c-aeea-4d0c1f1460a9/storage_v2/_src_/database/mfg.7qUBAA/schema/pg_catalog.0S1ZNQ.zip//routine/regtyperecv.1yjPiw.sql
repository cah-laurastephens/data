CREATE FUNCTION regtyperecv()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.regtyperecv(internal)
  RETURNS regtype
AS
$BODY$
regtyperecv
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

