CREATE FUNCTION rtgettuple()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.rtgettuple(internal, internal)
  RETURNS bool
AS
$BODY$
rtgettuple
$BODY$
LANGUAGE internal VOLATILE STRICT;
$$;

