CREATE FUNCTION tintervallt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.tintervallt(tinterval, tinterval)
  RETURNS bool
AS
$BODY$
tintervallt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

