CREATE FUNCTION timestamp_eq_date()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamp_eq_date(timestamp, date)
  RETURNS bool
AS
$BODY$
timestamp_eq_date
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

