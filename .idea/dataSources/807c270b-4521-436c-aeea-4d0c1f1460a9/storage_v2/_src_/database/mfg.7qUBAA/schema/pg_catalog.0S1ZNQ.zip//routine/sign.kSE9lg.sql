CREATE FUNCTION sign()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.sign(float8)
  RETURNS float8
AS
$BODY$
dsign
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.sign(numeric)
  RETURNS numeric
AS
$BODY$
numeric_sign
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

