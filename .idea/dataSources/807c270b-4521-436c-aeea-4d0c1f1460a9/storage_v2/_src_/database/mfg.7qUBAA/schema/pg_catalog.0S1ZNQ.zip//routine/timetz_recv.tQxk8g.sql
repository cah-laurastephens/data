CREATE FUNCTION timetz_recv()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timetz_recv(internal)
  RETURNS timetz
AS
$BODY$
timetz_recv
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

