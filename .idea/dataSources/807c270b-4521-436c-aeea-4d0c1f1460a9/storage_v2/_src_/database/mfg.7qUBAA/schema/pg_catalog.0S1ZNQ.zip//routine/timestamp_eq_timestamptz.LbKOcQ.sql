CREATE FUNCTION timestamp_eq_timestamptz()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamp_eq_timestamptz(timestamp, timestamptz)
  RETURNS bool
AS
$BODY$
timestamp_eq_timestamptz
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

