CREATE FUNCTION text_larger()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.text_larger(text, text)
  RETURNS text
AS
$BODY$
text_larger
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

