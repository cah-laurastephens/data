CREATE FUNCTION time_pl_interval()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.time_pl_interval(time, interval)
  RETURNS time
AS
$BODY$
time_pl_interval
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

