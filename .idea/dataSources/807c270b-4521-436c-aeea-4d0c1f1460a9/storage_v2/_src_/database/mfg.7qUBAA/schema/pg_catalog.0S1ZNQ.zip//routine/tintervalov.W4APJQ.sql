CREATE FUNCTION tintervalov()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.tintervalov(tinterval, tinterval)
  RETURNS bool
AS
$BODY$
tintervalov
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

