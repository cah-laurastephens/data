CREATE FUNCTION textregexeq()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.textregexeq(text, text)
  RETURNS bool
AS
$BODY$
textregexeq
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

