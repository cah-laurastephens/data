CREATE FUNCTION regoperatorin()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.regoperatorin(cstring)
  RETURNS regoperator
AS
$BODY$
regoperatorin
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

