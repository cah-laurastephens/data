CREATE FUNCTION timenow()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timenow()
  RETURNS abstime
AS
$BODY$
timenow
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

