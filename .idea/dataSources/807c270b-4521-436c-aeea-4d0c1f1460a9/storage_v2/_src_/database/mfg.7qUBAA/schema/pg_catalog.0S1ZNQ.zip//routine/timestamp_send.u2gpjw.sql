CREATE FUNCTION timestamp_send()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamp_send(timestamp)
  RETURNS bytea
AS
$BODY$
timestamp_send
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

