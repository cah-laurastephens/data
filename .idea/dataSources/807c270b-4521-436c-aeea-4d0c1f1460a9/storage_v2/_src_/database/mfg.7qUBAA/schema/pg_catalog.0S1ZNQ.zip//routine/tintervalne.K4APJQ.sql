CREATE FUNCTION tintervalne()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.tintervalne(tinterval, tinterval)
  RETURNS bool
AS
$BODY$
tintervalne
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

