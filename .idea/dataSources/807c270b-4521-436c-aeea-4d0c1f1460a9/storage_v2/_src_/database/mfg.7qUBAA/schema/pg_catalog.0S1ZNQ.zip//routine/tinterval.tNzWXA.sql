CREATE FUNCTION tinterval()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.tinterval(abstime, abstime)
  RETURNS tinterval
AS
$BODY$
mktinterval
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

