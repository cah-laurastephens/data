CREATE FUNCTION xidrecv()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.xidrecv(internal)
  RETURNS xid
AS
$BODY$
xidrecv
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

