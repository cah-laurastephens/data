CREATE FUNCTION regtypesend()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.regtypesend(regtype)
  RETURNS bytea
AS
$BODY$
regtypesend
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

