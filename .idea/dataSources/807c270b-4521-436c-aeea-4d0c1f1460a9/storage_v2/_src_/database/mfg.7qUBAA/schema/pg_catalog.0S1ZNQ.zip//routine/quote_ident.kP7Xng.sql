CREATE FUNCTION quote_ident()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.quote_ident(text)
  RETURNS text
AS
$BODY$
quote_ident
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

