CREATE FUNCTION text_ge()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.text_ge(text, text)
  RETURNS bool
AS
$BODY$
text_ge
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

