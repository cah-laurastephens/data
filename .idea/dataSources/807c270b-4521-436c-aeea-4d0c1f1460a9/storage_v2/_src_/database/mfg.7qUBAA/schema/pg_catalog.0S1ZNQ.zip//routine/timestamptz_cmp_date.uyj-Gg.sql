CREATE FUNCTION timestamptz_cmp_date()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamptz_cmp_date(timestamptz, date)
  RETURNS int4
AS
$BODY$
timestamptz_cmp_date
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

