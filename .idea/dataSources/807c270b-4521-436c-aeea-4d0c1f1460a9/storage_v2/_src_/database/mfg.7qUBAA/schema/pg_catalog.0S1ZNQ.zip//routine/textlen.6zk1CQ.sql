CREATE FUNCTION textlen()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.textlen(text)
  RETURNS int4
AS
$BODY$
textlen
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

