CREATE FUNCTION unknownin()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.unknownin(cstring)
  RETURNS unknown
AS
$BODY$
unknownin
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

