CREATE FUNCTION positionsel()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.positionsel(internal, oid, internal, int4)
  RETURNS float8
AS
$BODY$
positionsel
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

