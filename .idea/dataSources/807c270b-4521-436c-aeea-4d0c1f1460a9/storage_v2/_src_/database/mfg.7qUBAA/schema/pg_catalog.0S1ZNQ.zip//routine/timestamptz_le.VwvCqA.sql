CREATE FUNCTION timestamptz_le()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamptz_le(timestamptz, timestamptz)
  RETURNS bool
AS
$BODY$
timestamp_le
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

