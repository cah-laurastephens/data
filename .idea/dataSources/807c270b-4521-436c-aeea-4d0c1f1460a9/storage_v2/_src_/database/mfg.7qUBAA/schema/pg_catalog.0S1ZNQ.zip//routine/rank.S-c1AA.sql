CREATE FUNCTION rank()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.rank()
  RETURNS int8
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal VOLATILE STRICT;
$$;

