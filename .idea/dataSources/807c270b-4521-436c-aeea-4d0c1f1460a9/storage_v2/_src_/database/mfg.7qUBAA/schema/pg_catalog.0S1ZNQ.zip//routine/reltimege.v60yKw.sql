CREATE FUNCTION reltimege()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.reltimege(reltime, reltime)
  RETURNS bool
AS
$BODY$
reltimege
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

