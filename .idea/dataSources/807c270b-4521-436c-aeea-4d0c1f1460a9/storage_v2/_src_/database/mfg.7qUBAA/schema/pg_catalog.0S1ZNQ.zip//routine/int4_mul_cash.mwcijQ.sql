CREATE FUNCTION int4_mul_cash()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.int4_mul_cash(int4, money)
  RETURNS money
AS
$BODY$
int4_mul_cash
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

