CREATE FUNCTION varbit_recv()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.varbit_recv(internal)
  RETURNS varbit
AS
$BODY$
varbit_recv
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

