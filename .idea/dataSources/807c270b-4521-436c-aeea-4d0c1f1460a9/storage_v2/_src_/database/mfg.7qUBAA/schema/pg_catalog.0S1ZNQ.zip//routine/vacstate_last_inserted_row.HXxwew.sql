CREATE FUNCTION vacstate_last_inserted_row()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.vacstate_last_inserted_row(int8)
  RETURNS int8
AS
$BODY$
ff_vacstate_last_inserted_row
$BODY$
LANGUAGE internal VOLATILE STRICT;
$$;

