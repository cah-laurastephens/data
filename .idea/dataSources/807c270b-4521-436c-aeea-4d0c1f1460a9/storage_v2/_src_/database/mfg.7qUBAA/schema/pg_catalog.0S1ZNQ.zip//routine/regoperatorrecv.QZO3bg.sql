CREATE FUNCTION regoperatorrecv()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.regoperatorrecv(internal)
  RETURNS regoperator
AS
$BODY$
regoperatorrecv
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

