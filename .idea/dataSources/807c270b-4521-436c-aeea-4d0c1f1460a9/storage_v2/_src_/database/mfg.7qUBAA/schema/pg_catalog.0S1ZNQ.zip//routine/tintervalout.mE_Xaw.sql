CREATE FUNCTION tintervalout()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.tintervalout(tinterval)
  RETURNS cstring
AS
$BODY$
tintervalout
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

