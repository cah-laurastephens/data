CREATE FUNCTION time_recv()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.time_recv(internal)
  RETURNS time
AS
$BODY$
time_recv
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

