CREATE FUNCTION textnlike()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.textnlike(text, text)
  RETURNS bool
AS
$BODY$
textnlike
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

