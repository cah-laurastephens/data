CREATE FUNCTION texticlike()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.texticlike(text, text)
  RETURNS bool
AS
$BODY$
texticlike
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

