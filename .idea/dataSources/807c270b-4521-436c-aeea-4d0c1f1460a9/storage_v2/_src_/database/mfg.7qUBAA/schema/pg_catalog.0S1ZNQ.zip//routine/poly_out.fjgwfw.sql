CREATE FUNCTION poly_out()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.poly_out(polygon)
  RETURNS cstring
AS
$BODY$
poly_out
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

