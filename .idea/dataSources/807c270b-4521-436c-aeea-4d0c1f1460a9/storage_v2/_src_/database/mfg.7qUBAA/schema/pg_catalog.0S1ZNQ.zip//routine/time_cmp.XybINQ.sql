CREATE FUNCTION time_cmp()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.time_cmp(time, time)
  RETURNS int4
AS
$BODY$
time_cmp
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

