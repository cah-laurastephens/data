CREATE FUNCTION timestamp_lt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamp_lt(timestamp, timestamp)
  RETURNS bool
AS
$BODY$
timestamp_lt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

