CREATE FUNCTION sum()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.sum(int8)
  RETURNS int8
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.sum(int2)
  RETURNS int8
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.sum(int4)
  RETURNS int8
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.sum(float4)
  RETURNS float8
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.sum(float8)
  RETURNS float8
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.sum(money)
  RETURNS money
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.sum(interval)
  RETURNS interval
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.sum(numeric)
  RETURNS numeric
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
$$;

