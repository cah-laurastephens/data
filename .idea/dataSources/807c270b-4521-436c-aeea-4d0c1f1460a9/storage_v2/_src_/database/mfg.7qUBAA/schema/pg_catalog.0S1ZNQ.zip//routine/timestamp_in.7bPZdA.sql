CREATE FUNCTION timestamp_in()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamp_in(cstring, oid, int4)
  RETURNS timestamp
AS
$BODY$
timestamp_in
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

