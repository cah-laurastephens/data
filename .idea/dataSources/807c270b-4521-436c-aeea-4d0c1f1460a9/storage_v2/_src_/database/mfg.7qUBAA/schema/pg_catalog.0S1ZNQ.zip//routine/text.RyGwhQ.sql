CREATE FUNCTION text()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.text(char)
  RETURNS text
AS
$BODY$
char_text
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.text(char[])
  RETURNS text
AS
$BODY$
name_text
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.text(int8)
  RETURNS text
AS
$BODY$
int8_text
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.text(int2)
  RETURNS text
AS
$BODY$
int2_text
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.text(int4)
  RETURNS text
AS
$BODY$
int4_text
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.text(oid)
  RETURNS text
AS
$BODY$
oid_text
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.text(float4)
  RETURNS text
AS
$BODY$
float4_text
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.text(float8)
  RETURNS text
AS
$BODY$
float8_text
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.text(macaddr)
  RETURNS text
AS
$BODY$
macaddr_text
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.text(inet)
  RETURNS text
AS
$BODY$
network_show
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.text(bpchar)
  RETURNS text
AS
$BODY$
rtrim1
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.text(date)
  RETURNS text
AS
$BODY$
date_text
$BODY$
LANGUAGE internal STABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.text(time)
  RETURNS text
AS
$BODY$
time_text
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.text(timestamp)
  RETURNS text
AS
$BODY$
timestamp_text
$BODY$
LANGUAGE internal STABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.text(timestamptz)
  RETURNS text
AS
$BODY$
timestamptz_text
$BODY$
LANGUAGE internal STABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.text(interval)
  RETURNS text
AS
$BODY$
interval_text
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.text(timetz)
  RETURNS text
AS
$BODY$
timetz_text
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.text(numeric)
  RETURNS text
AS
$BODY$
numeric_text
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

