CREATE FUNCTION replicate()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.replicate(text, int4)
  RETURNS text
AS
$BODY$
repeat
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

