CREATE FUNCTION time_in()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.time_in(cstring, oid, int4)
  RETURNS time
AS
$BODY$
time_in
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

