CREATE FUNCTION varbitle()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.varbitle(varbit, varbit)
  RETURNS bool
AS
$BODY$
bitle
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

