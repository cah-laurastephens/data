CREATE FUNCTION regoperatorsend()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.regoperatorsend(regoperator)
  RETURNS bytea
AS
$BODY$
regoperatorsend
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

