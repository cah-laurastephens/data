CREATE FUNCTION regclasssend()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.regclasssend(regclass)
  RETURNS bytea
AS
$BODY$
regclasssend
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

