CREATE FUNCTION timezone()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timezone(text, timestamp)
  RETURNS timestamptz
AS
$BODY$
timestamp_zone
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.timezone(interval, timestamp)
  RETURNS timestamptz
AS
$BODY$
timestamp_izone
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.timezone(text, timestamptz)
  RETURNS timestamp
AS
$BODY$
timestamptz_zone
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.timezone(interval, timestamptz)
  RETURNS timestamp
AS
$BODY$
timestamptz_izone
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.timezone(text, timetz)
  RETURNS timetz
AS
$BODY$
timetz_zone
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.timezone(interval, timetz)
  RETURNS timetz
AS
$BODY$
timetz_izone
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

