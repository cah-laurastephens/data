CREATE FUNCTION varbitcmp()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.varbitcmp(varbit, varbit)
  RETURNS int4
AS
$BODY$
bitcmp
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

