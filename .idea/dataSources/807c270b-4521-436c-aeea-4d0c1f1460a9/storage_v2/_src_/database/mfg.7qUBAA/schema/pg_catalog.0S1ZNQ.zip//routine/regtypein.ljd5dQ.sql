CREATE FUNCTION regtypein()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.regtypein(cstring)
  RETURNS regtype
AS
$BODY$
regtypein
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

