CREATE FUNCTION ssl_version()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.ssl_version()
  RETURNS text
AS
$BODY$
ssl_version
$BODY$
LANGUAGE internal IMMUTABLE;
$$;

