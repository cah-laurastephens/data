CREATE FUNCTION record_send()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.record_send(record, oid)
  RETURNS bytea
AS
$BODY$
record_send
$BODY$
LANGUAGE internal VOLATILE STRICT;
$$;

