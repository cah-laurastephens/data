CREATE FUNCTION varbitlt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.varbitlt(varbit, varbit)
  RETURNS bool
AS
$BODY$
bitlt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

