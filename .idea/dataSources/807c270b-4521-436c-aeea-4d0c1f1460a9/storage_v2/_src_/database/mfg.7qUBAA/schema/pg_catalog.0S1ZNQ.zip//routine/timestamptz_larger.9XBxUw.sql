CREATE FUNCTION timestamptz_larger()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamptz_larger(timestamptz, timestamptz)
  RETURNS timestamptz
AS
$BODY$
timestamp_larger
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

