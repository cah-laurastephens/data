CREATE FUNCTION rt_poly_inter()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.rt_poly_inter(polygon, polygon)
  RETURNS void
AS
$BODY$
rt_poly_inter
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

