CREATE FUNCTION xidin()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.xidin(cstring)
  RETURNS xid
AS
$BODY$
xidin
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

