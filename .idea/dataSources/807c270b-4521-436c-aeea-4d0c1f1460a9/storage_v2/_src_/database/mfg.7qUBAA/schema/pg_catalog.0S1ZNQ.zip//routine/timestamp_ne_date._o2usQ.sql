CREATE FUNCTION timestamp_ne_date()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamp_ne_date(timestamp, date)
  RETURNS bool
AS
$BODY$
timestamp_ne_date
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

