CREATE FUNCTION tintervalle()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.tintervalle(tinterval, tinterval)
  RETURNS bool
AS
$BODY$
tintervalle
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

