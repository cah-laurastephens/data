CREATE FUNCTION text_pattern_le()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.text_pattern_le(text, text)
  RETURNS bool
AS
$BODY$
text_pattern_le
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

