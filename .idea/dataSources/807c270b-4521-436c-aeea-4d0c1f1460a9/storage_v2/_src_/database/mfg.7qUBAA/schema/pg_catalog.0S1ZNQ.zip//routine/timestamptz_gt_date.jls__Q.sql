CREATE FUNCTION timestamptz_gt_date()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamptz_gt_date(timestamptz, date)
  RETURNS bool
AS
$BODY$
timestamptz_gt_date
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

