CREATE FUNCTION int4ge()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.int4ge(int4, int4)
  RETURNS bool
AS
$BODY$
int4ge
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

