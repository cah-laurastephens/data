CREATE FUNCTION rt_box_size()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.rt_box_size(point[], internal)
  RETURNS void
AS
$BODY$
rt_box_size
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

