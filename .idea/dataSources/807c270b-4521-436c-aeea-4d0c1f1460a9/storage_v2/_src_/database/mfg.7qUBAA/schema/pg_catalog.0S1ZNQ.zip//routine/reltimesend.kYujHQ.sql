CREATE FUNCTION reltimesend()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.reltimesend(reltime)
  RETURNS bytea
AS
$BODY$
reltimesend
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

