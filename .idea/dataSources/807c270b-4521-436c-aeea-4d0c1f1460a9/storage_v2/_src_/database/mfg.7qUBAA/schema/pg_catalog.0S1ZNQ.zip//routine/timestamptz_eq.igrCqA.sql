CREATE FUNCTION timestamptz_eq()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamptz_eq(timestamptz, timestamptz)
  RETURNS bool
AS
$BODY$
timestamp_eq
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

