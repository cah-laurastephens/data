CREATE FUNCTION similar_escape()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.similar_escape(text, text)
  RETURNS text
AS
$BODY$
similar_escape
$BODY$
LANGUAGE internal IMMUTABLE;
$$;

