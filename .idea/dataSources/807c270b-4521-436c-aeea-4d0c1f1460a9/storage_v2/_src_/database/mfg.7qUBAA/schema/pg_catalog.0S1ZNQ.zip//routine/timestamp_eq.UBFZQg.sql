CREATE FUNCTION timestamp_eq()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamp_eq(timestamp, timestamp)
  RETURNS bool
AS
$BODY$
timestamp_eq
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

