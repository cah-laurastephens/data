CREATE FUNCTION rtbuild()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.rtbuild(internal, internal, internal)
  RETURNS void
AS
$BODY$
rtbuild
$BODY$
LANGUAGE internal VOLATILE STRICT;
$$;

