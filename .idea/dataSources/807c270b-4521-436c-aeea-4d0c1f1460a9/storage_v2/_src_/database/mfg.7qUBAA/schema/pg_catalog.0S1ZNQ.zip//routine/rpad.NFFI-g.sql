CREATE FUNCTION rpad()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.rpad(text, int4)
  RETURNS text
AS
$BODY$
select pg_catalog.rpad($1, $2, ' ')
$BODY$
LANGUAGE sql IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.rpad(text, int4, text)
  RETURNS text
AS
$BODY$
rpad
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

