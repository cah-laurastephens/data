CREATE FUNCTION reltimeeq()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.reltimeeq(reltime, reltime)
  RETURNS bool
AS
$BODY$
reltimeeq
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

