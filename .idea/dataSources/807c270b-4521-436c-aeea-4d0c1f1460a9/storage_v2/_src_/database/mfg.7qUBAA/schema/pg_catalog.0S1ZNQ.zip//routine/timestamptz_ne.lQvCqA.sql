CREATE FUNCTION timestamptz_ne()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamptz_ne(timestamptz, timestamptz)
  RETURNS bool
AS
$BODY$
timestamp_ne
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

