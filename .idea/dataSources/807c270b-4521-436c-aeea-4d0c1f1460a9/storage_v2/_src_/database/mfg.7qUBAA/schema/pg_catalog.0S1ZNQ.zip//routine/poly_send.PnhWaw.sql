CREATE FUNCTION poly_send()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.poly_send(polygon)
  RETURNS bytea
AS
$BODY$
poly_send
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

