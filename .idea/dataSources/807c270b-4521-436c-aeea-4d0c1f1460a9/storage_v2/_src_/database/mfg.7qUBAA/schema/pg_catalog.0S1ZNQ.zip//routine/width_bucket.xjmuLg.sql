CREATE FUNCTION width_bucket()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.width_bucket(numeric, numeric, numeric, int4)
  RETURNS int4
AS
$BODY$
width_bucket_numeric
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

