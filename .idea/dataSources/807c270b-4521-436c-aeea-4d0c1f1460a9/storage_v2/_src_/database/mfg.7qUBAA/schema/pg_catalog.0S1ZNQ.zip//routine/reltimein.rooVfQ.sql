CREATE FUNCTION reltimein()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.reltimein(cstring)
  RETURNS reltime
AS
$BODY$
reltimein
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

