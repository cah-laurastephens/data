CREATE FUNCTION record_out()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.record_out(record, oid)
  RETURNS cstring
AS
$BODY$
record_out
$BODY$
LANGUAGE internal VOLATILE STRICT;
$$;

