CREATE FUNCTION tidrecv()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.tidrecv(internal)
  RETURNS tid
AS
$BODY$
tidrecv
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

