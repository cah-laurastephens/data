CREATE FUNCTION int4and()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.int4and(int4, int4)
  RETURNS int4
AS
$BODY$
int4and
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

