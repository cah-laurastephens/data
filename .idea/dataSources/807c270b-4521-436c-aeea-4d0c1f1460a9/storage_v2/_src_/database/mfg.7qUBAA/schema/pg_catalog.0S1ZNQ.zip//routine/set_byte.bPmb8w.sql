CREATE FUNCTION set_byte()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.set_byte(bytea, int4, int4)
  RETURNS bytea
AS
$BODY$
byteaSetByte
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

