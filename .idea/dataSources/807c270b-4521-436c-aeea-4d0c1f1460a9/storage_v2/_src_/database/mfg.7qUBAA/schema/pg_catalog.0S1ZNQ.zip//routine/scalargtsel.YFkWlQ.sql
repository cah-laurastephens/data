CREATE FUNCTION scalargtsel()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.scalargtsel(internal, oid, internal, int4)
  RETURNS float8
AS
$BODY$
scalargtsel
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

