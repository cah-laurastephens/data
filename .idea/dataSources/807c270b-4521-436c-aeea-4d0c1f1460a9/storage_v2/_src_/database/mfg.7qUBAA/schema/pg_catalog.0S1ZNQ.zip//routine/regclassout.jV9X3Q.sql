CREATE FUNCTION regclassout()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.regclassout(regclass)
  RETURNS cstring
AS
$BODY$
regclassout
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

