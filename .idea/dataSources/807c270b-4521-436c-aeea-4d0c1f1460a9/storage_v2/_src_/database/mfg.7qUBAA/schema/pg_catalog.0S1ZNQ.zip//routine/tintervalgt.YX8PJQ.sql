CREATE FUNCTION tintervalgt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.tintervalgt(tinterval, tinterval)
  RETURNS bool
AS
$BODY$
tintervalgt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

