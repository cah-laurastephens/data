CREATE FUNCTION repeat()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.repeat(text, int4)
  RETURNS text
AS
$BODY$
repeat
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

