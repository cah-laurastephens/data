CREATE FUNCTION width()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.width(point[])
  RETURNS float8
AS
$BODY$
box_width
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

