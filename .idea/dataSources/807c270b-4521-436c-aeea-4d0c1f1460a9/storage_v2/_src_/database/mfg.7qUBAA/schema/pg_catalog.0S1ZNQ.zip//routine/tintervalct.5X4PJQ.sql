CREATE FUNCTION tintervalct()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.tintervalct(tinterval, tinterval)
  RETURNS bool
AS
$BODY$
tintervalct
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

