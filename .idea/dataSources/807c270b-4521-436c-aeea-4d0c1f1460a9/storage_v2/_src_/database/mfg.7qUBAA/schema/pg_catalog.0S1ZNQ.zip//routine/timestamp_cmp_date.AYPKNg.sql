CREATE FUNCTION timestamp_cmp_date()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamp_cmp_date(timestamp, date)
  RETURNS int4
AS
$BODY$
timestamp_cmp_date
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

