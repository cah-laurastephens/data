CREATE FUNCTION set_bit()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.set_bit(bytea, int4, int4)
  RETURNS bytea
AS
$BODY$
byteaSetBit
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

