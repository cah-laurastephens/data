CREATE FUNCTION varcharsend()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.varcharsend(varchar)
  RETURNS bytea
AS
$BODY$
varcharsend
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

