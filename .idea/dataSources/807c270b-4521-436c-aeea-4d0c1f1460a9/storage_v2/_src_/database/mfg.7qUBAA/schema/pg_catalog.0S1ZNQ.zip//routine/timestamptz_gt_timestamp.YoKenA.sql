CREATE FUNCTION timestamptz_gt_timestamp()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamptz_gt_timestamp(timestamptz, timestamp)
  RETURNS bool
AS
$BODY$
timestamptz_gt_timestamp
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

