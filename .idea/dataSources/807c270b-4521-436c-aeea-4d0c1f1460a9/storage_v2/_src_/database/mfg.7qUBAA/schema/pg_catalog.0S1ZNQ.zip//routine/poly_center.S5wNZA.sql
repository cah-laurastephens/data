CREATE FUNCTION poly_center()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.poly_center(polygon)
  RETURNS float8[]
AS
$BODY$
poly_center
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

