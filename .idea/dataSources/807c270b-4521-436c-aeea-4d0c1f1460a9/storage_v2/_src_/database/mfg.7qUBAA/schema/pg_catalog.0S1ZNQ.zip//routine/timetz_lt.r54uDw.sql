CREATE FUNCTION timetz_lt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timetz_lt(timetz, timetz)
  RETURNS bool
AS
$BODY$
timetz_lt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

