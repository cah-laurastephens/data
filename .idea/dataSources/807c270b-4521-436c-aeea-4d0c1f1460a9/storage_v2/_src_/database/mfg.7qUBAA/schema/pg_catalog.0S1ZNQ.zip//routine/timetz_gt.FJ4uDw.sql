CREATE FUNCTION timetz_gt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timetz_gt(timetz, timetz)
  RETURNS bool
AS
$BODY$
timetz_gt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

