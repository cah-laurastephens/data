CREATE FUNCTION timestamptz_recv()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamptz_recv(internal)
  RETURNS timestamptz
AS
$BODY$
timestamptz_recv
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

