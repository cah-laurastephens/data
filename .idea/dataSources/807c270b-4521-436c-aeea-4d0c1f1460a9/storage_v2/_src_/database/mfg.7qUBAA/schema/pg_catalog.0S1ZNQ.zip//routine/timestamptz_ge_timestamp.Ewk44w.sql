CREATE FUNCTION timestamptz_ge_timestamp()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamptz_ge_timestamp(timestamptz, timestamp)
  RETURNS bool
AS
$BODY$
timestamptz_ge_timestamp
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

