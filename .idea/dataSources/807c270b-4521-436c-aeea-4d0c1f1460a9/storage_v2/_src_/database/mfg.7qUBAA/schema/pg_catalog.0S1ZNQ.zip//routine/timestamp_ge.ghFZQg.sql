CREATE FUNCTION timestamp_ge()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamp_ge(timestamp, timestamp)
  RETURNS bool
AS
$BODY$
timestamp_ge
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

