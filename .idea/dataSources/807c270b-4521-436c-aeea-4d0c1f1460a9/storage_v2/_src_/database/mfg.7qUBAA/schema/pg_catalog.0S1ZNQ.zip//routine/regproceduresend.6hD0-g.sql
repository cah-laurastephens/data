CREATE FUNCTION regproceduresend()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.regproceduresend(regprocedure)
  RETURNS bytea
AS
$BODY$
regproceduresend
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

