CREATE FUNCTION record_recv()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.record_recv(internal, oid)
  RETURNS record
AS
$BODY$
record_recv
$BODY$
LANGUAGE internal VOLATILE STRICT;
$$;

