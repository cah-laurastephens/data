CREATE FUNCTION timestamp_le_date()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamp_le_date(timestamp, date)
  RETURNS bool
AS
$BODY$
timestamp_le_date
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

