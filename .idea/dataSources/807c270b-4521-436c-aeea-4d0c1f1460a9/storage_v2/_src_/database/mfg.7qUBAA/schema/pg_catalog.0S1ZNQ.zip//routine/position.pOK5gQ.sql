CREATE FUNCTION position()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.position(bytea, bytea)
  RETURNS int4
AS
$BODY$
byteapos
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.position(text, text)
  RETURNS int4
AS
$BODY$
textpos
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.position(bit, bit)
  RETURNS int4
AS
$BODY$
bitposition
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

