CREATE FUNCTION timestamptz_ge()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamptz_ge(timestamptz, timestamptz)
  RETURNS bool
AS
$BODY$
timestamp_ge
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

