CREATE FUNCTION "_pg_keysequal"(smallint[], smallint[])
  RETURNS boolean
  IMMUTABLE
  LANGUAGE SQL
AS $$
select information_schema._pg_keyissubset($1, $2) and information_schema._pg_keyissubset($2, $1)
$$;

