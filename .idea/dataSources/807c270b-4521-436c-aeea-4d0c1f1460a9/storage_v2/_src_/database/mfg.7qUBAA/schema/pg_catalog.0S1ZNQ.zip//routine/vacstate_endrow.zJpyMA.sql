CREATE FUNCTION vacstate_endrow()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.vacstate_endrow(int8)
  RETURNS int8
AS
$BODY$
ff_vacstate_endrow
$BODY$
LANGUAGE internal VOLATILE STRICT;
$$;

