CREATE FUNCTION point_right()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.point_right(float8[], float8[])
  RETURNS bool
AS
$BODY$
point_right
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

