CREATE FUNCTION trunc()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.trunc(float8)
  RETURNS float8
AS
$BODY$
dtrunc
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.trunc(macaddr)
  RETURNS macaddr
AS
$BODY$
macaddr_trunc
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.trunc(timestamp)
  RETURNS date
AS
$BODY$
timestamp_date
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.trunc(numeric)
  RETURNS numeric
AS
$BODY$
select pg_catalog.trunc($1,0)
$BODY$
LANGUAGE sql IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.trunc(numeric, int4)
  RETURNS numeric
AS
$BODY$
numeric_trunc
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.trunc(float8, numeric)
  RETURNS float8
AS
$BODY$
truncate_float8_numeric
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

