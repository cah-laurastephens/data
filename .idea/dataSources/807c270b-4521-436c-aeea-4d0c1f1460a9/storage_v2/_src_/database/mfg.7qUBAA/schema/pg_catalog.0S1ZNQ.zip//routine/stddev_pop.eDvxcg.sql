CREATE FUNCTION stddev_pop()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.stddev_pop(float8)
  RETURNS float8
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
$$;

