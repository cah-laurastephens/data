CREATE FUNCTION textregexne()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.textregexne(text, text)
  RETURNS bool
AS
$BODY$
textregexne
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

