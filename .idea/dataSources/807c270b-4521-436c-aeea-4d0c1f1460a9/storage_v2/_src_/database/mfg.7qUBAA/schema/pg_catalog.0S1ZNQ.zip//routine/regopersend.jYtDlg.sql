CREATE FUNCTION regopersend()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.regopersend(regoper)
  RETURNS bytea
AS
$BODY$
regopersend
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

