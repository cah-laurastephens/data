CREATE FUNCTION radius()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.radius(circle)
  RETURNS float8
AS
$BODY$
circle_radius
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

