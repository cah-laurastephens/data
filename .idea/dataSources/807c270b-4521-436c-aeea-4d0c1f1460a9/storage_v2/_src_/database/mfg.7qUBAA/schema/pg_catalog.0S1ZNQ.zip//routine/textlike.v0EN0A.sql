CREATE FUNCTION textlike()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.textlike(text, text)
  RETURNS bool
AS
$BODY$
textlike
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

