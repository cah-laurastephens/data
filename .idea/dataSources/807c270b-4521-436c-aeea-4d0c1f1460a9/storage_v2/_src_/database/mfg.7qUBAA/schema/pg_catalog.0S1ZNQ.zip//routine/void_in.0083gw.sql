CREATE FUNCTION void_in()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.void_in(cstring)
  RETURNS void
AS
$BODY$
void_in
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

