CREATE FUNCTION smgrin()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.smgrin(cstring)
  RETURNS smgr
AS
$BODY$
smgrin
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

