CREATE FUNCTION return_approx_percentile()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.return_approx_percentile(varchar, float8)
  RETURNS int4
AS
$BODY$
return_approx_percentile
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

