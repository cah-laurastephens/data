CREATE FUNCTION int4_sum()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.int4_sum(int8, int4)
  RETURNS int8
AS
$BODY$
int4_sum
$BODY$
LANGUAGE internal IMMUTABLE;
$$;

