CREATE FUNCTION regprocout()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.regprocout(regproc)
  RETURNS cstring
AS
$BODY$
regprocout
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

