CREATE FUNCTION varbit()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.varbit(varbit, int4, bool)
  RETURNS varbit
AS
$BODY$
varbit
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

