CREATE FUNCTION round()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.round(float8)
  RETURNS float8
AS
$BODY$
dround
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.round(numeric)
  RETURNS numeric
AS
$BODY$
select pg_catalog.round($1,0)
$BODY$
LANGUAGE sql IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.round(numeric, int4)
  RETURNS numeric
AS
$BODY$
numeric_round
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.round(float8, numeric)
  RETURNS float8
AS
$BODY$
round_float8_numeric
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

