CREATE FUNCTION sjis_to_euc_jp()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.sjis_to_euc_jp(int4, int4, cstring, internal, int4)
  RETURNS void
AS
'246C69626469722F6575635F6A705F616E645F736A6973', 'sjis_to_euc_jp'VOLATILE STRICT;
$$;

