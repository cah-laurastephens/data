CREATE FUNCTION time()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.time(text)
  RETURNS time
AS
$BODY$
text_time
$BODY$
LANGUAGE internal STABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.time(abstime)
  RETURNS time
AS
$BODY$
select cast(cast($1 as timestamp without time zone) as time)
$BODY$
LANGUAGE sql STABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.time(timestamp)
  RETURNS time
AS
$BODY$
timestamp_time
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.time(timestamptz)
  RETURNS time
AS
$BODY$
timestamptz_time
$BODY$
LANGUAGE internal STABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.time(interval)
  RETURNS time
AS
$BODY$
interval_time
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.time(timetz)
  RETURNS time
AS
$BODY$
timetz_time
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.time(time, int4)
  RETURNS time
AS
$BODY$
time_scale
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

