CREATE FUNCTION varbitgt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.varbitgt(varbit, varbit)
  RETURNS bool
AS
$BODY$
bitgt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

