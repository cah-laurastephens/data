CREATE FUNCTION reltimegt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.reltimegt(reltime, reltime)
  RETURNS bool
AS
$BODY$
reltimegt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

