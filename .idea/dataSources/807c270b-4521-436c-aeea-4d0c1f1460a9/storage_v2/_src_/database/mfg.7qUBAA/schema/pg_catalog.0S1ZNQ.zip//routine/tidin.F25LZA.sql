CREATE FUNCTION tidin()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.tidin(cstring)
  RETURNS tid
AS
$BODY$
tidin
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

