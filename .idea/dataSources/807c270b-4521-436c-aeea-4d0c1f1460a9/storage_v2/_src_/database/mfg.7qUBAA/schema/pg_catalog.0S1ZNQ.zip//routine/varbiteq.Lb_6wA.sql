CREATE FUNCTION varbiteq()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.varbiteq(varbit, varbit)
  RETURNS bool
AS
$BODY$
biteq
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

