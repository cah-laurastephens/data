CREATE FUNCTION rtrestrpos()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.rtrestrpos(internal)
  RETURNS void
AS
$BODY$
rtrestrpos
$BODY$
LANGUAGE internal VOLATILE STRICT;
$$;

