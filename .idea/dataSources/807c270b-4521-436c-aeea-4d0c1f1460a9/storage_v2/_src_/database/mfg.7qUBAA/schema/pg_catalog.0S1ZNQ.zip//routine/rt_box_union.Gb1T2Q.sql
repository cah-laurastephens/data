CREATE FUNCTION rt_box_union()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.rt_box_union(point[], point[])
  RETURNS point[]
AS
$BODY$
rt_box_union
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

