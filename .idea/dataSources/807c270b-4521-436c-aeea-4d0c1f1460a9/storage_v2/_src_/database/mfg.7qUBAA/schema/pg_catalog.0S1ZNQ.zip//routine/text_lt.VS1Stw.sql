CREATE FUNCTION text_lt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.text_lt(text, text)
  RETURNS bool
AS
$BODY$
text_lt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

