CREATE FUNCTION regclassrecv()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.regclassrecv(internal)
  RETURNS regclass
AS
$BODY$
regclassrecv
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

