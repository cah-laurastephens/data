CREATE FUNCTION tintervallenge()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.tintervallenge(tinterval, reltime)
  RETURNS bool
AS
$BODY$
tintervallenge
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

