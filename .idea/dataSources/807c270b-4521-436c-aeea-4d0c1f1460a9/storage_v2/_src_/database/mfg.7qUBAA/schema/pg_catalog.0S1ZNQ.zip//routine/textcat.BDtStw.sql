CREATE FUNCTION textcat()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.textcat(text, text)
  RETURNS text
AS
$BODY$
textcat
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

