CREATE FUNCTION varbit_send()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.varbit_send(varbit)
  RETURNS bytea
AS
$BODY$
varbit_send
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

