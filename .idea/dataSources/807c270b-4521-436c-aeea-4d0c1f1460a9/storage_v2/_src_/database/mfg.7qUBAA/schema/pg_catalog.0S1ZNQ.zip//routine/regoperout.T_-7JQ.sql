CREATE FUNCTION regoperout()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.regoperout(regoper)
  RETURNS cstring
AS
$BODY$
regoperout
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

