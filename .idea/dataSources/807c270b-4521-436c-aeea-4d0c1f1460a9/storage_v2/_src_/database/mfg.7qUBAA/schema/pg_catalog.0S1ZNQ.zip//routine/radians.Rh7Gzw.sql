CREATE FUNCTION radians()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.radians(float8)
  RETURNS float8
AS
$BODY$
radians
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

