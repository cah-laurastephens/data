CREATE FUNCTION timetz_mi_interval()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timetz_mi_interval(timetz, interval)
  RETURNS timetz
AS
$BODY$
timetz_mi_interval
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

