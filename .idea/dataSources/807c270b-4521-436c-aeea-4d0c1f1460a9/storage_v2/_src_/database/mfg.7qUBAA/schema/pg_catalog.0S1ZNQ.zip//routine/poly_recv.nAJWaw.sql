CREATE FUNCTION poly_recv()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.poly_recv(internal)
  RETURNS polygon
AS
$BODY$
poly_recv
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

