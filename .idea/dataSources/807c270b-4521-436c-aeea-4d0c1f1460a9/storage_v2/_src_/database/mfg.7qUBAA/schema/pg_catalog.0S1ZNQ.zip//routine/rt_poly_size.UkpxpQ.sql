CREATE FUNCTION rt_poly_size()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.rt_poly_size(polygon, internal)
  RETURNS void
AS
$BODY$
rt_poly_size
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

