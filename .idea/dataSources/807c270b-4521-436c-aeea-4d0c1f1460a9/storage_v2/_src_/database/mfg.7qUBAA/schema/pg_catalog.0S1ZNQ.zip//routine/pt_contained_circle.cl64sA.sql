CREATE FUNCTION pt_contained_circle()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.pt_contained_circle(float8[], circle)
  RETURNS bool
AS
$BODY$
pt_contained_circle
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

