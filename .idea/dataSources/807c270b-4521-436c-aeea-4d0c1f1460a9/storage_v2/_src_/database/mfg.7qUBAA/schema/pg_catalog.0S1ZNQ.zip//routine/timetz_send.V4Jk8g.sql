CREATE FUNCTION timetz_send()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timetz_send(timetz)
  RETURNS bytea
AS
$BODY$
timetz_send
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

