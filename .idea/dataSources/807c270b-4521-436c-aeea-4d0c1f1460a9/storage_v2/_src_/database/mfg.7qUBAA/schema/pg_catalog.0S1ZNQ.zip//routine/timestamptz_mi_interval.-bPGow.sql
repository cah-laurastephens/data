CREATE FUNCTION timestamptz_mi_interval()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamptz_mi_interval(timestamptz, interval)
  RETURNS timestamptz
AS
$BODY$
timestamptz_mi_interval
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

