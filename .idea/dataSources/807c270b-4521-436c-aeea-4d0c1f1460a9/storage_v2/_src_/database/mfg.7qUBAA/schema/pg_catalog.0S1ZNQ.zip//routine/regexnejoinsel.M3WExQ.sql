CREATE FUNCTION regexnejoinsel()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.regexnejoinsel(internal, oid, internal, int2)
  RETURNS float8
AS
$BODY$
regexnejoinsel
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

