CREATE FUNCTION timestamp_smaller()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamp_smaller(timestamp, timestamp)
  RETURNS timestamp
AS
$BODY$
timestamp_smaller
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

