CREATE FUNCTION timestamp_pl_int8()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamp_pl_int8(timestamp, int8)
  RETURNS timestamp
AS
$BODY$
timestamp_pl_int8
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

