CREATE FUNCTION poly_npoints()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.poly_npoints(polygon)
  RETURNS int4
AS
$BODY$
poly_npoints
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

