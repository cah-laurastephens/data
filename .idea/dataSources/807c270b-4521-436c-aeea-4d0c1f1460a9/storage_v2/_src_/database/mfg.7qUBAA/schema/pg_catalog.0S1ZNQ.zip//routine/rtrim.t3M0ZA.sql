CREATE FUNCTION rtrim()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.rtrim(text)
  RETURNS text
AS
$BODY$
rtrim1
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.rtrim(text, text)
  RETURNS text
AS
$BODY$
rtrim
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

