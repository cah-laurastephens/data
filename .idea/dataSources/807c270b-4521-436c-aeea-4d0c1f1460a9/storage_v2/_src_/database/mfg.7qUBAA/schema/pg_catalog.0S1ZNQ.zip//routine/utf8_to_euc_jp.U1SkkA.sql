CREATE FUNCTION utf8_to_euc_jp()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.utf8_to_euc_jp(int4, int4, cstring, internal, int4)
  RETURNS void
AS
'246C69626469722F757466385F616E645F6575635F6A70', 'utf8_to_euc_jp'VOLATILE STRICT;
$$;

