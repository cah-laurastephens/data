CREATE FUNCTION to_ascii()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.to_ascii(text)
  RETURNS text
AS
$BODY$
to_ascii_default
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.to_ascii(text, char[])
  RETURNS text
AS
$BODY$
to_ascii_encname
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.to_ascii(text, int4)
  RETURNS text
AS
$BODY$
to_ascii_enc
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

