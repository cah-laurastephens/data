CREATE FUNCTION trigger_in()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.trigger_in(cstring)
  RETURNS trigger
AS
$BODY$
trigger_in
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

