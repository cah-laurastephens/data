CREATE FUNCTION varcharin()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.varcharin(cstring, oid, int4)
  RETURNS varchar
AS
$BODY$
varcharin
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

