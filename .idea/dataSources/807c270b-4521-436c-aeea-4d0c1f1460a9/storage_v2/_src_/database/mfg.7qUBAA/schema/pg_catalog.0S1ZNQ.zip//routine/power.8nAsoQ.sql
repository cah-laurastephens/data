CREATE FUNCTION power()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.power(float8, float8)
  RETURNS float8
AS
$BODY$
dpow
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

