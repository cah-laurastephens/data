CREATE FUNCTION set_config()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.set_config(text, text, bool)
  RETURNS text
AS
$BODY$
set_config_by_name
$BODY$
LANGUAGE internal VOLATILE;
$$;

