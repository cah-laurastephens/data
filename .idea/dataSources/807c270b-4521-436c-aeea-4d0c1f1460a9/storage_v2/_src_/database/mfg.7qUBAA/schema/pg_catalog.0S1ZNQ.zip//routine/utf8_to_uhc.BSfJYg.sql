CREATE FUNCTION utf8_to_uhc()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.utf8_to_uhc(int4, int4, cstring, internal, int4)
  RETURNS void
AS
'246C69626469722F757466385F616E645F756863', 'utf8_to_uhc'VOLATILE STRICT;
$$;

