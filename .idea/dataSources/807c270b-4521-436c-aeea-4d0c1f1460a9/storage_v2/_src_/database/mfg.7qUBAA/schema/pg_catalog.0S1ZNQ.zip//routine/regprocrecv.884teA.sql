CREATE FUNCTION regprocrecv()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.regprocrecv(internal)
  RETURNS regproc
AS
$BODY$
regprocrecv
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

