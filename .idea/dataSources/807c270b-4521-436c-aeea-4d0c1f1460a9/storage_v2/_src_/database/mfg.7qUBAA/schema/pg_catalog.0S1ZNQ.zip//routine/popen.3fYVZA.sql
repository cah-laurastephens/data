CREATE FUNCTION popen()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.popen(path)
  RETURNS path
AS
$BODY$
path_open
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

