CREATE FUNCTION time_gt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.time_gt(time, time)
  RETURNS bool
AS
$BODY$
time_gt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

