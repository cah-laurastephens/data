CREATE FUNCTION time_out()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.time_out(time)
  RETURNS cstring
AS
$BODY$
time_out
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

