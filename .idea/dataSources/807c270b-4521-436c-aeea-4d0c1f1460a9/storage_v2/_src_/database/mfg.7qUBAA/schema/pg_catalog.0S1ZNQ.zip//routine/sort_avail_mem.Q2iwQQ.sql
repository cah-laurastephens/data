CREATE FUNCTION sort_avail_mem()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.sort_avail_mem()
  RETURNS int8
AS
$BODY$
ff_sort_avail_mem
$BODY$
LANGUAGE internal VOLATILE STRICT;
$$;

