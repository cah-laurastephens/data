CREATE FUNCTION timemi()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timemi(abstime, reltime)
  RETURNS abstime
AS
$BODY$
timemi
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

