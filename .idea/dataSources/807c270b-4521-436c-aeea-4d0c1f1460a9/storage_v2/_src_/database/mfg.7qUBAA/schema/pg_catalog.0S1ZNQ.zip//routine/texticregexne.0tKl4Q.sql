CREATE FUNCTION texticregexne()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.texticregexne(text, text)
  RETURNS bool
AS
$BODY$
texticregexne
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

