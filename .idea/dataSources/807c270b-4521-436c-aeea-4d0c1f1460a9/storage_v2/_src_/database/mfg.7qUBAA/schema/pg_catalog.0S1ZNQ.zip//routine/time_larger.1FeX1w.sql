CREATE FUNCTION time_larger()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.time_larger(time, time)
  RETURNS time
AS
$BODY$
time_larger
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

