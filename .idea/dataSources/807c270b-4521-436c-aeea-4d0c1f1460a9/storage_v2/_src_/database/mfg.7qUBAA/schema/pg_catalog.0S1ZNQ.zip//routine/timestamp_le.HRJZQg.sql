CREATE FUNCTION timestamp_le()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamp_le(timestamp, timestamp)
  RETURNS bool
AS
$BODY$
timestamp_le
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

