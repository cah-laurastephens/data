CREATE FUNCTION substring()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.substring(bytea, int4)
  RETURNS bytea
AS
$BODY$
bytea_substr_no_len
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.substring(text, int4)
  RETURNS text
AS
$BODY$
text_substr_no_len
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.substring(bit, int4)
  RETURNS bit
AS
$BODY$
select pg_catalog.substring($1, $2, -1)
$BODY$
LANGUAGE sql IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.substring(text, text)
  RETURNS text
AS
$BODY$
substringregexp
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.substring(bytea, int4, int4)
  RETURNS bytea
AS
$BODY$
bytea_substr
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.substring(text, int4, int4)
  RETURNS text
AS
$BODY$
text_substr
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.substring(bit, int4, int4)
  RETURNS bit
AS
$BODY$
bitsubstr
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.substring(text, text, text)
  RETURNS text
AS
$BODY$
select pg_catalog.substring($1, pg_catalog.similar_escape($2, $3))
$BODY$
LANGUAGE sql IMMUTABLE STRICT;
$$;

