CREATE FUNCTION rt_box_inter()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.rt_box_inter(point[], point[])
  RETURNS void
AS
$BODY$
rt_box_inter
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

