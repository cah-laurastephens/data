CREATE FUNCTION rtcostestimate()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.rtcostestimate(internal, internal, internal, internal, internal, internal, internal, internal)
  RETURNS void
AS
$BODY$
rtcostestimate
$BODY$
LANGUAGE internal VOLATILE STRICT;
$$;

