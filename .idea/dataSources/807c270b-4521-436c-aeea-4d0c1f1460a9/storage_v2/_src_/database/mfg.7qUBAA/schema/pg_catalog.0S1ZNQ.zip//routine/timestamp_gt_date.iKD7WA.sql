CREATE FUNCTION timestamp_gt_date()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamp_gt_date(timestamp, date)
  RETURNS bool
AS
$BODY$
timestamp_gt_date
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

