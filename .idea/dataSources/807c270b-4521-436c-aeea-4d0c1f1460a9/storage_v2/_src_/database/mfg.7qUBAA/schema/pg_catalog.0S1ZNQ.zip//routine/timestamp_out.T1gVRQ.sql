CREATE FUNCTION timestamp_out()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamp_out(timestamp)
  RETURNS cstring
AS
$BODY$
timestamp_out
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

