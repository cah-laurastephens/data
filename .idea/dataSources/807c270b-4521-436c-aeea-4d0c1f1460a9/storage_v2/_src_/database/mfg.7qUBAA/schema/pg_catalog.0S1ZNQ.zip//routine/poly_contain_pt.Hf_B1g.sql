CREATE FUNCTION poly_contain_pt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.poly_contain_pt(polygon, float8[])
  RETURNS bool
AS
$BODY$
poly_contain_pt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

