CREATE FUNCTION time_ne()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.time_ne(time, time)
  RETURNS bool
AS
$BODY$
time_ne
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

