CREATE FUNCTION variance()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.variance(float8)
  RETURNS float8
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
$$;

