CREATE FUNCTION timestamptz_send()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamptz_send(timestamptz)
  RETURNS bytea
AS
$BODY$
timestamptz_send
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

