CREATE FUNCTION regoperin()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.regoperin(cstring)
  RETURNS regoper
AS
$BODY$
regoperin
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

