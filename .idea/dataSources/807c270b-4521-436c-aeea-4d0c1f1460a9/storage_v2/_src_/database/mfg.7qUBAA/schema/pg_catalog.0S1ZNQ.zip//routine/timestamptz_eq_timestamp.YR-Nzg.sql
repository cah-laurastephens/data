CREATE FUNCTION timestamptz_eq_timestamp()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamptz_eq_timestamp(timestamptz, timestamp)
  RETURNS bool
AS
$BODY$
timestamptz_eq_timestamp
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

