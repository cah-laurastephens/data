CREATE FUNCTION timestamp_ne_timestamptz()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamp_ne_timestamptz(timestamp, timestamptz)
  RETURNS bool
AS
$BODY$
timestamp_ne_timestamptz
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

