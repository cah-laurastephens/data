CREATE FUNCTION timetz_le()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timetz_le(timetz, timetz)
  RETURNS bool
AS
$BODY$
timetz_le
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

