CREATE FUNCTION timetz()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timetz(text)
  RETURNS timetz
AS
$BODY$
text_timetz
$BODY$
LANGUAGE internal STABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.timetz(time)
  RETURNS timetz
AS
$BODY$
time_timetz
$BODY$
LANGUAGE internal STABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.timetz(timestamptz)
  RETURNS timetz
AS
$BODY$
timestamptz_timetz
$BODY$
LANGUAGE internal STABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.timetz(timetz, int4)
  RETURNS timetz
AS
$BODY$
timetz_scale
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

