CREATE FUNCTION unknownsend()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.unknownsend(unknown)
  RETURNS bytea
AS
$BODY$
unknownsend
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

