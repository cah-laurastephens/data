CREATE FUNCTION rtrescan()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.rtrescan(internal, internal)
  RETURNS void
AS
$BODY$
rtrescan
$BODY$
LANGUAGE internal VOLATILE STRICT;
$$;

