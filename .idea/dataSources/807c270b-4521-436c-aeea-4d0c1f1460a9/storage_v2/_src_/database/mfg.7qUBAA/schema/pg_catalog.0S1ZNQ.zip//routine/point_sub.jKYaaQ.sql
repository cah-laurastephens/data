CREATE FUNCTION point_sub()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.point_sub(float8[], float8[])
  RETURNS float8[]
AS
$BODY$
point_sub
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

