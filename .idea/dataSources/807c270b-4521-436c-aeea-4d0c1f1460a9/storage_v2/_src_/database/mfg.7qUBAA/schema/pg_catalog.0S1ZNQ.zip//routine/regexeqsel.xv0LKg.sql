CREATE FUNCTION regexeqsel()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.regexeqsel(internal, oid, internal, int4)
  RETURNS float8
AS
$BODY$
regexeqsel
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

