CREATE FUNCTION text_smaller()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.text_smaller(text, text)
  RETURNS text
AS
$BODY$
text_smaller
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

