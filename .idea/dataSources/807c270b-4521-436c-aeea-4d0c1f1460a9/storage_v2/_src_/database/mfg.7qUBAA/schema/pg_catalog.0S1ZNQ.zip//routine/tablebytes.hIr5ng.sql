CREATE FUNCTION tablebytes()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.tablebytes(int8)
  RETURNS int8
AS
$BODY$
ff_tablebytes
$BODY$
LANGUAGE internal VOLATILE STRICT;
$$;

