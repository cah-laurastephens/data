CREATE FUNCTION strtol()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.strtol(varchar, int4)
  RETURNS int8
AS
$BODY$
str_to_l
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

