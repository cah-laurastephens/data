CREATE FUNCTION timestamp_larger()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamp_larger(timestamp, timestamp)
  RETURNS timestamp
AS
$BODY$
timestamp_larger
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

