CREATE FUNCTION smgrne()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.smgrne(smgr, smgr)
  RETURNS bool
AS
$BODY$
smgrne
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

