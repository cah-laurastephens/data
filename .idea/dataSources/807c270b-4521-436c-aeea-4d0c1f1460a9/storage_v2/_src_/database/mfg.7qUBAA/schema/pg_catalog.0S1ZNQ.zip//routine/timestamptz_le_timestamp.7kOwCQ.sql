CREATE FUNCTION timestamptz_le_timestamp()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamptz_le_timestamp(timestamptz, timestamp)
  RETURNS bool
AS
$BODY$
timestamptz_le_timestamp
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

