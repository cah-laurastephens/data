CREATE FUNCTION timestamptz_gt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamptz_gt(timestamptz, timestamptz)
  RETURNS bool
AS
$BODY$
timestamp_gt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

