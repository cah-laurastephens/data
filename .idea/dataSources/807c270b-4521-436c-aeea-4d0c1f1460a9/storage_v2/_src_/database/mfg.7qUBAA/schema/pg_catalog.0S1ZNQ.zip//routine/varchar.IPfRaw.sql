CREATE FUNCTION varchar()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.varchar(char[])
  RETURNS varchar
AS
$BODY$
name_text
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.varchar(varchar, int4, bool)
  RETURNS varchar
AS
$BODY$
varchar
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

