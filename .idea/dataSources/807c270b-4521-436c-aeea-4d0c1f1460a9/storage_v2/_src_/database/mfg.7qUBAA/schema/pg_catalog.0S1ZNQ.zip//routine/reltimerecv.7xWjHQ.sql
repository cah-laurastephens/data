CREATE FUNCTION reltimerecv()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.reltimerecv(internal)
  RETURNS reltime
AS
$BODY$
reltimerecv
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

