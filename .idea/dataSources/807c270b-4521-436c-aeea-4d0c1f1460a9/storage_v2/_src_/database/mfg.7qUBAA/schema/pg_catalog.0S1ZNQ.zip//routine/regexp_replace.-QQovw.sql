CREATE FUNCTION regexp_replace()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.regexp_replace(text, text)
  RETURNS text
AS
$BODY$
select regexp_replace($1, $2, '')
$BODY$
LANGUAGE sql IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.regexp_replace(text, text, text)
  RETURNS text
AS
$BODY$
select regexp_replace($1, $2, $3, 1)
$BODY$
LANGUAGE sql IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.regexp_replace(text, text, text, int4)
  RETURNS text
AS
$BODY$
regexp_replace
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

