CREATE FUNCTION smgreq()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.smgreq(smgr, smgr)
  RETURNS bool
AS
$BODY$
smgreq
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

