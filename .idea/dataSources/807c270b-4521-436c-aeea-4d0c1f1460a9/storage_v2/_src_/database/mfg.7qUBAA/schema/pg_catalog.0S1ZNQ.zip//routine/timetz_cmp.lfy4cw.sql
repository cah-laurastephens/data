CREATE FUNCTION timetz_cmp()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timetz_cmp(timetz, timetz)
  RETURNS int4
AS
$BODY$
timetz_cmp
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

