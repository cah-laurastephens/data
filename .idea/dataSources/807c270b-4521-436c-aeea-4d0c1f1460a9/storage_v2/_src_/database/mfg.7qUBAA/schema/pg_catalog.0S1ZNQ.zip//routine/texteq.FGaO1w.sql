CREATE FUNCTION texteq()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.texteq(text, text)
  RETURNS bool
AS
$BODY$
texteq
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

