CREATE FUNCTION varcharrecv()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.varcharrecv(internal)
  RETURNS varchar
AS
$BODY$
varcharrecv
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

