CREATE FUNCTION timetz_larger()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timetz_larger(timetz, timetz)
  RETURNS timetz
AS
$BODY$
timetz_larger
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

