CREATE FUNCTION timedate_pl()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timedate_pl(time, date)
  RETURNS timestamp
AS
$BODY$
select ($2 + $1)
$BODY$
LANGUAGE sql IMMUTABLE STRICT;
$$;

