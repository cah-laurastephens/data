CREATE FUNCTION timestamptz()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamptz(text)
  RETURNS timestamptz
AS
$BODY$
text_timestamptz
$BODY$
LANGUAGE internal STABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.timestamptz(abstime)
  RETURNS timestamptz
AS
$BODY$
abstime_timestamptz
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.timestamptz(bpchar)
  RETURNS timestamptz
AS
$BODY$
bpchar_timestamptz
$BODY$
LANGUAGE internal STABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.timestamptz(date)
  RETURNS timestamptz
AS
$BODY$
date_timestamptz
$BODY$
LANGUAGE internal STABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.timestamptz(timestamp)
  RETURNS timestamptz
AS
$BODY$
timestamp_timestamptz
$BODY$
LANGUAGE internal STABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.timestamptz(timestamptz, int4)
  RETURNS timestamptz
AS
$BODY$
timestamptz_scale
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.timestamptz(date, time)
  RETURNS timestamptz
AS
$BODY$
select cast(($1 + $2) as timestamp with time zone)
$BODY$
LANGUAGE sql STABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.timestamptz(date, timetz)
  RETURNS timestamptz
AS
$BODY$
datetimetz_timestamptz
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

