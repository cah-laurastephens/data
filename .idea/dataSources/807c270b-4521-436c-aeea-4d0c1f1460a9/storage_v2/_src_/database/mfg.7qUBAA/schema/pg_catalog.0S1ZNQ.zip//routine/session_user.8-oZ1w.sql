CREATE FUNCTION "session_user"()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog."session_user"()
  RETURNS char[]
AS
$BODY$
session_user
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

