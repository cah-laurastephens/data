CREATE FUNCTION remaining_vacrows()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.remaining_vacrows(int8)
  RETURNS int8
AS
$BODY$
ff_remaining_vacrows
$BODY$
LANGUAGE internal VOLATILE STRICT;
$$;

