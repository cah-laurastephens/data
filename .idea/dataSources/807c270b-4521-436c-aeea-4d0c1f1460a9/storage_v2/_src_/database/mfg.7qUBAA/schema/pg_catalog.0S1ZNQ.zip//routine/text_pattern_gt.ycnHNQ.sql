CREATE FUNCTION text_pattern_gt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.text_pattern_gt(text, text)
  RETURNS bool
AS
$BODY$
text_pattern_gt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

