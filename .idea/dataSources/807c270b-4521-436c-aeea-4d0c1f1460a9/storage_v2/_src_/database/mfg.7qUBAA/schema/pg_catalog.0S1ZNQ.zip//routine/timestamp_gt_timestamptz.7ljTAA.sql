CREATE FUNCTION timestamp_gt_timestamptz()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamp_gt_timestamptz(timestamp, timestamptz)
  RETURNS bool
AS
$BODY$
timestamp_gt_timestamptz
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

