CREATE FUNCTION timestamptz_ge_date()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamptz_ge_date(timestamptz, date)
  RETURNS bool
AS
$BODY$
timestamptz_ge_date
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

