CREATE FUNCTION "right"()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog."right"(text, int4)
  RETURNS text
AS
$BODY$
xen_right
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

