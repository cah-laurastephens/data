CREATE FUNCTION tidsend()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.tidsend(tid)
  RETURNS bytea
AS
$BODY$
tidsend
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

