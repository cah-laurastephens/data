CREATE FUNCTION time_smaller()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.time_smaller(time, time)
  RETURNS time
AS
$BODY$
time_smaller
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

