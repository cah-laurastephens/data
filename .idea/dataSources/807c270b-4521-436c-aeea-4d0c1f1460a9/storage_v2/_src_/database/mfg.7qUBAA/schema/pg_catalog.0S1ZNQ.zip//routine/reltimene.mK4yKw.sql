CREATE FUNCTION reltimene()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.reltimene(reltime, reltime)
  RETURNS bool
AS
$BODY$
reltimene
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

