CREATE FUNCTION tintervalstart()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.tintervalstart(tinterval)
  RETURNS abstime
AS
$BODY$
tintervalstart
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

