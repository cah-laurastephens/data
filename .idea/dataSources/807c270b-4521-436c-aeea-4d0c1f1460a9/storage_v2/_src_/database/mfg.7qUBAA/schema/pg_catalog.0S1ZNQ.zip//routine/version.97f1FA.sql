CREATE FUNCTION version()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.version()
  RETURNS text
AS
$BODY$
pgsql_version
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

