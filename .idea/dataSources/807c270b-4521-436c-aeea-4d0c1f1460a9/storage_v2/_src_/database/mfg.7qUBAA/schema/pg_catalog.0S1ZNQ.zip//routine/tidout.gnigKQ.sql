CREATE FUNCTION tidout()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.tidout(tid)
  RETURNS cstring
AS
$BODY$
tidout
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

