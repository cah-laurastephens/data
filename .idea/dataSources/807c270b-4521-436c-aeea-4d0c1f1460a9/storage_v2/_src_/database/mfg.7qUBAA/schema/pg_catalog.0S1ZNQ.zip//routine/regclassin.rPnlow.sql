CREATE FUNCTION regclassin()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.regclassin(cstring)
  RETURNS regclass
AS
$BODY$
regclassin
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

