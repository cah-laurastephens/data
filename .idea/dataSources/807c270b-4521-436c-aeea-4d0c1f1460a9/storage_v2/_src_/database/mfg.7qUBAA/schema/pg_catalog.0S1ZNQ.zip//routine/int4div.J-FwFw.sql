CREATE FUNCTION int4div()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.int4div(int4, int4)
  RETURNS int4
AS
$BODY$
int4div
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

