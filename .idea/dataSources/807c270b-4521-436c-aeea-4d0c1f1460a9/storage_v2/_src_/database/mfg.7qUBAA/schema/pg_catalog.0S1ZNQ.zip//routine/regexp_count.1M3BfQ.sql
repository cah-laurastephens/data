CREATE FUNCTION regexp_count()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.regexp_count(text, text)
  RETURNS int4
AS
$BODY$
select regexp_count($1, $2, 1)
$BODY$
LANGUAGE sql IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.regexp_count(text, text, int4)
  RETURNS int4
AS
$BODY$
regexp_count
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

