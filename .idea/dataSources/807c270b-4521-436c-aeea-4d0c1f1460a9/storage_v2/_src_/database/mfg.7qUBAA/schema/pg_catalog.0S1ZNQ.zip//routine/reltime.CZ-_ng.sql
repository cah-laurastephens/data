CREATE FUNCTION reltime()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.reltime(interval)
  RETURNS reltime
AS
$BODY$
interval_reltime
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

