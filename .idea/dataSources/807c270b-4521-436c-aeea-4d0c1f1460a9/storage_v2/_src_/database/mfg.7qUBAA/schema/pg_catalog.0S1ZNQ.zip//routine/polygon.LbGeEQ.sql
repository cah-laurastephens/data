CREATE FUNCTION polygon()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.polygon(path)
  RETURNS polygon
AS
$BODY$
path_poly
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.polygon(point[])
  RETURNS polygon
AS
$BODY$
box_poly
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.polygon(circle)
  RETURNS polygon
AS
$BODY$
select pg_catalog.polygon(12, $1)
$BODY$
LANGUAGE sql IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.polygon(int4, circle)
  RETURNS polygon
AS
$BODY$
circle_poly
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

