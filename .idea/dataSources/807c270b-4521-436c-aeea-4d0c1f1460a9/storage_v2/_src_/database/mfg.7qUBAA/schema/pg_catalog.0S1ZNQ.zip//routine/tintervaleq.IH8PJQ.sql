CREATE FUNCTION tintervaleq()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.tintervaleq(tinterval, tinterval)
  RETURNS bool
AS
$BODY$
tintervaleq
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

