CREATE FUNCTION regprocedureout()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.regprocedureout(regprocedure)
  RETURNS cstring
AS
$BODY$
regprocedureout
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

