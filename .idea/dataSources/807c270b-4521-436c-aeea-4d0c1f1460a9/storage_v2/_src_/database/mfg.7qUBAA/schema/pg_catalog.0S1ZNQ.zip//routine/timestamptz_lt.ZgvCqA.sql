CREATE FUNCTION timestamptz_lt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamptz_lt(timestamptz, timestamptz)
  RETURNS bool
AS
$BODY$
timestamp_lt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

