CREATE FUNCTION tintervallenlt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.tintervallenlt(tinterval, reltime)
  RETURNS bool
AS
$BODY$
tintervallenlt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

