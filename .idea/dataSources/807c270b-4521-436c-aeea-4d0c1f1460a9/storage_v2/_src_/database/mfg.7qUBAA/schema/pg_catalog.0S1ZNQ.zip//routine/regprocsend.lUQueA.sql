CREATE FUNCTION regprocsend()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.regprocsend(regproc)
  RETURNS bytea
AS
$BODY$
regprocsend
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

