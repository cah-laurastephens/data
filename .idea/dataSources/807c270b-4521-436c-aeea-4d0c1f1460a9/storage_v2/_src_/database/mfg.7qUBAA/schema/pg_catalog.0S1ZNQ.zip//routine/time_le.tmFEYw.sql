CREATE FUNCTION time_le()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.time_le(time, time)
  RETURNS bool
AS
$BODY$
time_le
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

