CREATE FUNCTION textrecv()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.textrecv(internal)
  RETURNS text
AS
$BODY$
textrecv
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

