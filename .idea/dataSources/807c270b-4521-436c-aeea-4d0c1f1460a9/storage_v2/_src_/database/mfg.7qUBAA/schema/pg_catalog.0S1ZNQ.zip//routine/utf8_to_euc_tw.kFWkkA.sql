CREATE FUNCTION utf8_to_euc_tw()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.utf8_to_euc_tw(int4, int4, cstring, internal, int4)
  RETURNS void
AS
'246C69626469722F757466385F616E645F6575635F7477', 'utf8_to_euc_tw'VOLATILE STRICT;
$$;

