CREATE FUNCTION to_date()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.to_date(text, text)
  RETURNS date
AS
$BODY$
to_date
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

