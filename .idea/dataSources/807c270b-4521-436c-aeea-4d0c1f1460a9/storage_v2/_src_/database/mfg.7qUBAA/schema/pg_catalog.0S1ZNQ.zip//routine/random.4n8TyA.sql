CREATE FUNCTION random()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.random()
  RETURNS float8
AS
$BODY$
drandom
$BODY$
LANGUAGE internal VOLATILE STRICT;
$$;

