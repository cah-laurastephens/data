CREATE FUNCTION poly_overleft()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.poly_overleft(polygon, polygon)
  RETURNS bool
AS
$BODY$
poly_overleft
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

