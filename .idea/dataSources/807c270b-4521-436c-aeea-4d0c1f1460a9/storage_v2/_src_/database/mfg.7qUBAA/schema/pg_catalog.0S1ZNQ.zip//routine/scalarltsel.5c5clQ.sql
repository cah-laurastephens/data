CREATE FUNCTION scalarltsel()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.scalarltsel(internal, oid, internal, int4)
  RETURNS float8
AS
$BODY$
scalarltsel
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

