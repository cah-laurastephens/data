CREATE FUNCTION timetz_ge()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timetz_ge(timetz, timetz)
  RETURNS bool
AS
$BODY$
timetz_ge
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

