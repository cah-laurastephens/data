CREATE FUNCTION regexp_instr()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.regexp_instr(text, text)
  RETURNS int4
AS
$BODY$
select regexp_instr($1, $2, 1, 1, 0, '')
$BODY$
LANGUAGE sql IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.regexp_instr(text, text, int4)
  RETURNS int4
AS
$BODY$
select regexp_instr($1, $2, $3, 1, 0, '')
$BODY$
LANGUAGE sql IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.regexp_instr(text, text, int4, int4)
  RETURNS int4
AS
$BODY$
select regexp_instr($1, $2, $3, $4, 0, '')
$BODY$
LANGUAGE sql IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.regexp_instr(text, text, int4, int4, int4)
  RETURNS int4
AS
$BODY$
select regexp_instr($1, $2, $3, $4, $5, '')
$BODY$
LANGUAGE sql IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.regexp_instr(text, text, int4, int4, int4, text)
  RETURNS int4
AS
$BODY$
regexp_instr
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

