CREATE FUNCTION replace()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.replace(text, text, text)
  RETURNS text
AS
$BODY$
replace_text
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

