CREATE FUNCTION positionjoinsel()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.positionjoinsel(internal, oid, internal, int2)
  RETURNS float8
AS
$BODY$
positionjoinsel
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

