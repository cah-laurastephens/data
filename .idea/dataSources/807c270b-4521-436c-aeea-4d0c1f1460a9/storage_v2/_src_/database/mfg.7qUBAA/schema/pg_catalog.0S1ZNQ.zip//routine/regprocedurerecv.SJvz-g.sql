CREATE FUNCTION regprocedurerecv()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.regprocedurerecv(internal)
  RETURNS regprocedure
AS
$BODY$
regprocedurerecv
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

