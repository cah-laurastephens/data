CREATE FUNCTION sortbytes()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.sortbytes()
  RETURNS int8
AS
$BODY$
ff_sortbytes
$BODY$
LANGUAGE internal VOLATILE STRICT;
$$;

