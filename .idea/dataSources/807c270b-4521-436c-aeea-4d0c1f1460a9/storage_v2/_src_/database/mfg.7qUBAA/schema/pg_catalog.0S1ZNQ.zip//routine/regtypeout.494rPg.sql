CREATE FUNCTION regtypeout()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.regtypeout(regtype)
  RETURNS cstring
AS
$BODY$
regtypeout
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

