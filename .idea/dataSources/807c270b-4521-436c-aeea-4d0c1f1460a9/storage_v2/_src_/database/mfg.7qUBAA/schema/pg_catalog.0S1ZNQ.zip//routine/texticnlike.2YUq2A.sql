CREATE FUNCTION texticnlike()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.texticnlike(text, text)
  RETURNS bool
AS
$BODY$
texticnlike
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

