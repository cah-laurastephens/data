CREATE FUNCTION total_num_deleted_vacrows_reclaimed()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.total_num_deleted_vacrows_reclaimed(int8)
  RETURNS int8
AS
$BODY$
ff_total_num_deleted_vacrows_reclaimed
$BODY$
LANGUAGE internal VOLATILE STRICT;
$$;

