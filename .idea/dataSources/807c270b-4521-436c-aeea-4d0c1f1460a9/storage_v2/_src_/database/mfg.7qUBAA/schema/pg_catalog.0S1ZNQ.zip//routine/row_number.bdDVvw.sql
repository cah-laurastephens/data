CREATE FUNCTION row_number()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.row_number()
  RETURNS int8
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal VOLATILE STRICT;
$$;

