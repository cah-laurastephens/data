CREATE FUNCTION "_pg_datetime_precision"(typid oid, typmod integer)
  RETURNS integer
  IMMUTABLE
  LANGUAGE SQL
AS $$
SELECT
  CASE WHEN $2 = -1 /* default typmod */
       THEN null
       WHEN $1 IN (1083, 1114, 1184, 1266) /* time, timestamp, same + tz */
       THEN $2
       WHEN $1 IN (1186) /* interval */
       THEN $2 & 65535
       ELSE null
  END
$$;

