CREATE FUNCTION timestamp_mi_interval()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamp_mi_interval(timestamp, interval)
  RETURNS timestamp
AS
$BODY$
timestamp_mi_interval
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

