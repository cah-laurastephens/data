CREATE FUNCTION poly_left()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.poly_left(polygon, polygon)
  RETURNS bool
AS
$BODY$
poly_left
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

