CREATE FUNCTION timetz_smaller()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timetz_smaller(timetz, timetz)
  RETURNS timetz
AS
$BODY$
timetz_smaller
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

