CREATE FUNCTION varbit_in()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.varbit_in(cstring, oid, int4)
  RETURNS varbit
AS
$BODY$
varbit_in
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

