CREATE FUNCTION timestamptz_ne_timestamp()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamptz_ne_timestamp(timestamptz, timestamp)
  RETURNS bool
AS
$BODY$
timestamptz_ne_timestamp
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

