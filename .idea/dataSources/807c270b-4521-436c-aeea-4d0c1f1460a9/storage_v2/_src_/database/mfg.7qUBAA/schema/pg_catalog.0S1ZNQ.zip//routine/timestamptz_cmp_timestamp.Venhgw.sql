CREATE FUNCTION timestamptz_cmp_timestamp()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamptz_cmp_timestamp(timestamptz, timestamp)
  RETURNS int4
AS
$BODY$
timestamptz_cmp_timestamp
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

