CREATE FUNCTION tintervalrel()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.tintervalrel(tinterval)
  RETURNS reltime
AS
$BODY$
tintervalrel
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

