CREATE FUNCTION timestamp_lt_date()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timestamp_lt_date(timestamp, date)
  RETURNS bool
AS
$BODY$
timestamp_lt_date
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

