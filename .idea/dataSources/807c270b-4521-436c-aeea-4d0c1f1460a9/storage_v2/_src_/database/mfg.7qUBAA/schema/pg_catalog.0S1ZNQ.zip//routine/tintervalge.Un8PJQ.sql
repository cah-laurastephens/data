CREATE FUNCTION tintervalge()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.tintervalge(tinterval, tinterval)
  RETURNS bool
AS
$BODY$
tintervalge
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

