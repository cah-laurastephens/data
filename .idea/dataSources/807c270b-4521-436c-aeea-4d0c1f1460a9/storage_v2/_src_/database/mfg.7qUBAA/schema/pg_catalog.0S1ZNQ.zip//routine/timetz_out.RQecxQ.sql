CREATE FUNCTION timetz_out()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.timetz_out(timetz)
  RETURNS cstring
AS
$BODY$
timetz_out
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

