CREATE FUNCTION textne()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.textne(text, text)
  RETURNS bool
AS
$BODY$
textne
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

