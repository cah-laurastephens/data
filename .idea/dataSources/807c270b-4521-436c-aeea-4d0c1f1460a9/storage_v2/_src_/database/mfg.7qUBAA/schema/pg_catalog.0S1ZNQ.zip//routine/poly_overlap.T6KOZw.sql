CREATE FUNCTION poly_overlap()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.poly_overlap(polygon, polygon)
  RETURNS bool
AS
$BODY$
poly_overlap
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

