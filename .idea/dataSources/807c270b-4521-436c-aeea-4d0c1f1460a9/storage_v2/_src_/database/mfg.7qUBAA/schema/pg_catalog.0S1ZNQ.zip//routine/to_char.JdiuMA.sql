CREATE FUNCTION to_char()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.to_char(bool, text)
  RETURNS text
AS
$BODY$
int4_to_char
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.to_char(int8, text)
  RETURNS text
AS
$BODY$
int8_to_char
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.to_char(int4, text)
  RETURNS text
AS
$BODY$
int4_to_char
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.to_char(float4, text)
  RETURNS text
AS
$BODY$
float4_to_char
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.to_char(float8, text)
  RETURNS text
AS
$BODY$
float8_to_char
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.to_char(timestamp, text)
  RETURNS text
AS
$BODY$
timestamp_to_char
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.to_char(timestamptz, text)
  RETURNS text
AS
$BODY$
timestamptz_to_char
$BODY$
LANGUAGE internal STABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.to_char(interval, text)
  RETURNS text
AS
$BODY$
interval_to_char
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.to_char(numeric, text)
  RETURNS text
AS
$BODY$
numeric_to_char
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

