CREATE FUNCTION record_in()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.record_in(cstring, oid)
  RETURNS record
AS
$BODY$
record_in
$BODY$
LANGUAGE internal VOLATILE STRICT;
$$;

