CREATE FUNCTION time_lt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.time_lt(time, time)
  RETURNS bool
AS
$BODY$
time_lt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

