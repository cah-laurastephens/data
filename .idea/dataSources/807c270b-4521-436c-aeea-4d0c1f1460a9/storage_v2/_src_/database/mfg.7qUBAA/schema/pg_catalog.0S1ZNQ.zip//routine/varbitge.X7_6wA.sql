CREATE FUNCTION varbitge()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.varbitge(varbit, varbit)
  RETURNS bool
AS
$BODY$
bitge
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

