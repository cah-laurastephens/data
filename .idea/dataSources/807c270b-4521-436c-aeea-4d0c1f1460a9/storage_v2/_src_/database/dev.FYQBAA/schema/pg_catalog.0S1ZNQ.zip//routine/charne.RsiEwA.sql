CREATE FUNCTION charne()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.charne(char, char)
  RETURNS bool
AS
$BODY$
charne
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

