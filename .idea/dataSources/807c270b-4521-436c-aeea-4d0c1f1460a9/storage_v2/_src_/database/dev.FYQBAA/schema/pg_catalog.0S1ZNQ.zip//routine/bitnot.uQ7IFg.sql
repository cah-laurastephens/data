CREATE FUNCTION bitnot()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.bitnot(bit)
  RETURNS bit
AS
$BODY$
bitnot
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

