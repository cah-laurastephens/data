CREATE FUNCTION charindex()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.charindex(text, text)
  RETURNS int4
AS
$BODY$
charindex
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

