CREATE FUNCTION float48ge()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.float48ge(float4, float8)
  RETURNS bool
AS
$BODY$
float48ge
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

