CREATE FUNCTION cash_eq()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.cash_eq(money, money)
  RETURNS bool
AS
$BODY$
cash_eq
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

