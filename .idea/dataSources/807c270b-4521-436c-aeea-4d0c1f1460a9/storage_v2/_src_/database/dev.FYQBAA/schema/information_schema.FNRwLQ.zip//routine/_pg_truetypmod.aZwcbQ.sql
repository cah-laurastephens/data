CREATE FUNCTION "_pg_truetypmod"()
AS $$
CREATE OR REPLACE FUNCTION information_schema._pg_truetypmod(pg_attribute, pg_type)
  RETURNS int4
AS
$BODY$
SELECT CASE WHEN $2.typtype = 'd' THEN $2.typtypmod ELSE $1.atttypmod END
$BODY$
LANGUAGE sql IMMUTABLE STRICT;
$$;

