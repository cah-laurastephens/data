CREATE FUNCTION box()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.box(polygon)
  RETURNS point[]
AS
$BODY$
poly_box
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.box(circle)
  RETURNS point[]
AS
$BODY$
circle_box
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.box(float8[], float8[])
  RETURNS point[]
AS
$BODY$
points_box
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

