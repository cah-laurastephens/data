CREATE FUNCTION bit_send()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.bit_send(bit)
  RETURNS bytea
AS
$BODY$
bit_send
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

