CREATE FUNCTION bit_length()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.bit_length(bytea)
  RETURNS int4
AS
$BODY$
select pg_catalog.octet_length($1) * 8
$BODY$
LANGUAGE sql IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.bit_length(text)
  RETURNS int4
AS
$BODY$
select pg_catalog.octet_length($1) * 8
$BODY$
LANGUAGE sql IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.bit_length(bit)
  RETURNS int4
AS
$BODY$
select pg_catalog.length($1)
$BODY$
LANGUAGE sql IMMUTABLE STRICT;
$$;

