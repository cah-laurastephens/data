CREATE FUNCTION circle_send()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.circle_send(circle)
  RETURNS bytea
AS
$BODY$
circle_send
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

