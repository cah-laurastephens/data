CREATE FUNCTION array_coerce()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.array_coerce(anyarray)
  RETURNS anyarray
AS
$BODY$
array_type_coerce
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

