CREATE FUNCTION bpchar_pattern_le()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.bpchar_pattern_le(bpchar, bpchar)
  RETURNS bool
AS
$BODY$
text_pattern_le
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

