CREATE FUNCTION boolle()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.boolle(bool, bool)
  RETURNS bool
AS
$BODY$
boolle
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

