CREATE FUNCTION cash_recv()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.cash_recv(internal)
  RETURNS money
AS
$BODY$
cash_recv
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

