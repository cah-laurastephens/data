CREATE FUNCTION "_pg_keysequal"()
AS $$
CREATE OR REPLACE FUNCTION information_schema._pg_keysequal(int2[], int2[])
  RETURNS bool
AS
$BODY$
select information_schema._pg_keyissubset($1, $2) and information_schema._pg_keyissubset($2, $1)
$BODY$
LANGUAGE sql IMMUTABLE STRICT;
$$;

