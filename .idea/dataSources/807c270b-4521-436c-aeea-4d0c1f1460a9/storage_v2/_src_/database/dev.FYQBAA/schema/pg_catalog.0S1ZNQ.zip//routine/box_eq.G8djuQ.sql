CREATE FUNCTION box_eq()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.box_eq(point[], point[])
  RETURNS bool
AS
$BODY$
box_eq
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

