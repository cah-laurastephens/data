CREATE FUNCTION btint42cmp()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.btint42cmp(int4, int2)
  RETURNS int4
AS
$BODY$
btint42cmp
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

