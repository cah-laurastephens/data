CREATE FUNCTION euc_tw_to_big5()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.euc_tw_to_big5(int4, int4, cstring, internal, int4)
  RETURNS void
AS
'246C69626469722F6575635F74775F616E645F62696735', 'euc_tw_to_big5'VOLATILE STRICT;
$$;

