CREATE FUNCTION flatfile_update_trigger()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.flatfile_update_trigger()
  RETURNS trigger
AS
$BODY$
flatfile_update_trigger
$BODY$
LANGUAGE internal VOLATILE STRICT;
$$;

