CREATE FUNCTION aclremove()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.aclremove(aclitem[], aclitem)
  RETURNS aclitem[]
AS
$BODY$
aclremove
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

