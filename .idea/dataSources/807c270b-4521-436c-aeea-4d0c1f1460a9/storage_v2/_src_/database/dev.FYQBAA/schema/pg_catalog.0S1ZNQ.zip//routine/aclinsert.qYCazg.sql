CREATE FUNCTION aclinsert()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.aclinsert(aclitem[], aclitem)
  RETURNS aclitem[]
AS
$BODY$
aclinsert
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

