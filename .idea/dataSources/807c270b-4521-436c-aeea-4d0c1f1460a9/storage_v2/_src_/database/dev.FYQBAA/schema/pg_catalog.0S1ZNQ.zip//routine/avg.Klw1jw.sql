CREATE FUNCTION avg()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.avg(int8)
  RETURNS int8
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.avg(int2)
  RETURNS int8
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.avg(int4)
  RETURNS int8
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.avg(float4)
  RETURNS float8
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.avg(float8)
  RETURNS float8
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.avg(interval)
  RETURNS interval
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.avg(numeric)
  RETURNS numeric
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
$$;

