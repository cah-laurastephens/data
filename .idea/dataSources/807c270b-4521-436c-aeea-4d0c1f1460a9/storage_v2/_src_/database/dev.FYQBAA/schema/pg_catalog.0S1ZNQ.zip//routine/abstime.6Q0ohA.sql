CREATE FUNCTION abstime()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.abstime(timestamp)
  RETURNS abstime
AS
$BODY$
timestamp_abstime
$BODY$
LANGUAGE internal STABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.abstime(timestamptz)
  RETURNS abstime
AS
$BODY$
timestamptz_abstime
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

