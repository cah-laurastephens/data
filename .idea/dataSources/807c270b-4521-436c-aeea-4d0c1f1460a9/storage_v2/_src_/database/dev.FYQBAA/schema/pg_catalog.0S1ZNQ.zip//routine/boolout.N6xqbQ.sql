CREATE FUNCTION boolout()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.boolout(bool)
  RETURNS cstring
AS
$BODY$
boolout
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

