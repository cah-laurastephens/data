CREATE FUNCTION bpchar_pattern_gt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.bpchar_pattern_gt(bpchar, bpchar)
  RETURNS bool
AS
$BODY$
text_pattern_gt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

