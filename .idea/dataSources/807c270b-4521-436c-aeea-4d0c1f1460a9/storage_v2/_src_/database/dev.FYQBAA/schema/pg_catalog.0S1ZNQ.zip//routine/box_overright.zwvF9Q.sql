CREATE FUNCTION box_overright()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.box_overright(point[], point[])
  RETURNS bool
AS
$BODY$
box_overright
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

