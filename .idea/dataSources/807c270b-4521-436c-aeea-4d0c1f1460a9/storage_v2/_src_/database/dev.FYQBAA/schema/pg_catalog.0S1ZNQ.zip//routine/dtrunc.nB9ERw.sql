CREATE FUNCTION dtrunc()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.dtrunc(float8)
  RETURNS float8
AS
$BODY$
dtrunc
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

