CREATE FUNCTION boolge()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.boolge(bool, bool)
  RETURNS bool
AS
$BODY$
boolge
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

