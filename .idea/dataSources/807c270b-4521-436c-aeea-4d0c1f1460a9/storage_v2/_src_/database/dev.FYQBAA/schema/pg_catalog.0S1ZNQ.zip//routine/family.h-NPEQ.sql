CREATE FUNCTION family()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.family(inet)
  RETURNS int4
AS
$BODY$
network_family
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

