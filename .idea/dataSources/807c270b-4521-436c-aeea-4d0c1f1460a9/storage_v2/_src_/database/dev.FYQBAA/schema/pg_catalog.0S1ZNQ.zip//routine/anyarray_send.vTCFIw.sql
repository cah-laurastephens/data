CREATE FUNCTION anyarray_send()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.anyarray_send(anyarray)
  RETURNS bytea
AS
$BODY$
anyarray_send
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

