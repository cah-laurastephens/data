CREATE FUNCTION abstimesend()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.abstimesend(abstime)
  RETURNS bytea
AS
$BODY$
abstimesend
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

