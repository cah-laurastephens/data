CREATE FUNCTION dist_pl()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.dist_pl(float8[], float8[])
  RETURNS float8
AS
$BODY$
dist_pl
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

