CREATE FUNCTION box_recv()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.box_recv(internal)
  RETURNS point[]
AS
$BODY$
box_recv
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

