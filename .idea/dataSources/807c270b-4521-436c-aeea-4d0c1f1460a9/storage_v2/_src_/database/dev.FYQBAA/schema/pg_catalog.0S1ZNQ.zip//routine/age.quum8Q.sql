CREATE FUNCTION age()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.age(xid)
  RETURNS int4
AS
$BODY$
xid_age
$BODY$
LANGUAGE internal STABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.age(timestamp)
  RETURNS interval
AS
$BODY$
select pg_catalog.age(cast(current_date as timestamp without time zone), $1)
$BODY$
LANGUAGE sql STABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.age(timestamptz)
  RETURNS interval
AS
$BODY$
select pg_catalog.age(cast(current_date as timestamp with time zone), $1)
$BODY$
LANGUAGE sql STABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.age(timestamp, timestamp)
  RETURNS interval
AS
$BODY$
timestamp_age
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.age(timestamptz, timestamptz)
  RETURNS interval
AS
$BODY$
timestamptz_age
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

