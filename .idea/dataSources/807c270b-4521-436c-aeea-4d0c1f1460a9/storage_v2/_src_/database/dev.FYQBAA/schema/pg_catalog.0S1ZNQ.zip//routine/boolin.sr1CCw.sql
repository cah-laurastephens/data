CREATE FUNCTION boolin()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.boolin(cstring)
  RETURNS bool
AS
$BODY$
boolin
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

