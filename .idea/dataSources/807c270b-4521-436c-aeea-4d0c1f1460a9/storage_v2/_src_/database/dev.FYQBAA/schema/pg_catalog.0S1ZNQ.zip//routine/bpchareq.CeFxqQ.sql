CREATE FUNCTION bpchareq()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.bpchareq(bpchar, bpchar)
  RETURNS bool
AS
$BODY$
bpchareq
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

