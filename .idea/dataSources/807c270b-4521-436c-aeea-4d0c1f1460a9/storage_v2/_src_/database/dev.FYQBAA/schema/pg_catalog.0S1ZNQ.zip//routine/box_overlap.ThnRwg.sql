CREATE FUNCTION box_overlap()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.box_overlap(point[], point[])
  RETURNS bool
AS
$BODY$
box_overlap
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

