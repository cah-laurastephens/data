CREATE FUNCTION delete_xid_column()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.delete_xid_column(int4)
  RETURNS int4
AS
$BODY$
ff_delete_xid_column
$BODY$
LANGUAGE internal VOLATILE STRICT;
$$;

