CREATE FUNCTION abstimele()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.abstimele(abstime, abstime)
  RETURNS bool
AS
$BODY$
abstimele
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

