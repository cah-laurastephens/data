CREATE FUNCTION date()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.date(text)
  RETURNS date
AS
$BODY$
text_date
$BODY$
LANGUAGE internal STABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.date(abstime)
  RETURNS date
AS
$BODY$
abstime_date
$BODY$
LANGUAGE internal STABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.date(bpchar)
  RETURNS date
AS
$BODY$
bpchar_date
$BODY$
LANGUAGE internal STABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.date(timestamp)
  RETURNS date
AS
$BODY$
timestamp_date
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.date(timestamptz)
  RETURNS date
AS
$BODY$
timestamptz_date
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

