CREATE FUNCTION abstimein()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.abstimein(cstring)
  RETURNS abstime
AS
$BODY$
abstimein
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

