CREATE FUNCTION date_cmp()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.date_cmp(date, date)
  RETURNS int4
AS
$BODY$
date_cmp
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

