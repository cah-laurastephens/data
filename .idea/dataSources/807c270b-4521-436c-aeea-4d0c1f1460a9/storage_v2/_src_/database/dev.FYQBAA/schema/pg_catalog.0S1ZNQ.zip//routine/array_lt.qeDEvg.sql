CREATE FUNCTION array_lt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.array_lt(anyarray, anyarray)
  RETURNS bool
AS
$BODY$
array_lt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

