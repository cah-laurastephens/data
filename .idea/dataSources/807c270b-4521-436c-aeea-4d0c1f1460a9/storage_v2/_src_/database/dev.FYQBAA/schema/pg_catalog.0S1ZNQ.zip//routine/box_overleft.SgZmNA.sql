CREATE FUNCTION box_overleft()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.box_overleft(point[], point[])
  RETURNS bool
AS
$BODY$
box_overleft
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

