CREATE FUNCTION date_part_year()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.date_part_year(date)
  RETURNS int4
AS
$BODY$
date_part_year
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

