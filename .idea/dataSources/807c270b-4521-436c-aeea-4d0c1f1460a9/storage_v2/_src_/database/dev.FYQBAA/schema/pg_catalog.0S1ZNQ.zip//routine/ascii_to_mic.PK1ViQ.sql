CREATE FUNCTION ascii_to_mic()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.ascii_to_mic(int4, int4, cstring, internal, int4)
  RETURNS void
AS
'246C69626469722F61736369695F616E645F6D6963', 'ascii_to_mic'VOLATILE STRICT;
$$;

