CREATE FUNCTION date_le_timestamp()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.date_le_timestamp(date, timestamp)
  RETURNS bool
AS
$BODY$
date_le_timestamp
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

