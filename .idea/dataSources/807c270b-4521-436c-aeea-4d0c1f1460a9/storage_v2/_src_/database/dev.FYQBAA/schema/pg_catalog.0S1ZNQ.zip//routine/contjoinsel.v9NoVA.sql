CREATE FUNCTION contjoinsel()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.contjoinsel(internal, oid, internal, int2)
  RETURNS float8
AS
$BODY$
contjoinsel
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

