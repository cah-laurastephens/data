CREATE FUNCTION btrescan()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.btrescan(internal, internal)
  RETURNS void
AS
$BODY$
btrescan
$BODY$
LANGUAGE internal VOLATILE STRICT;
$$;

