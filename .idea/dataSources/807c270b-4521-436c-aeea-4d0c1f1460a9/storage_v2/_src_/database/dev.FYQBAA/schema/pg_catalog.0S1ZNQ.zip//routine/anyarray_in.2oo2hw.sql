CREATE FUNCTION anyarray_in()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.anyarray_in(cstring)
  RETURNS anyarray
AS
$BODY$
anyarray_in
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

