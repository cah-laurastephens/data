CREATE FUNCTION circle_left()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.circle_left(circle, circle)
  RETURNS bool
AS
$BODY$
circle_left
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

