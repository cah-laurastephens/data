CREATE FUNCTION cstring_send()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.cstring_send(cstring)
  RETURNS bytea
AS
$BODY$
cstring_send
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

