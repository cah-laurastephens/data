CREATE FUNCTION close_lb()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.close_lb(float8[], point[])
  RETURNS float8[]
AS
$BODY$
close_lb
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

