CREATE FUNCTION abstimelt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.abstimelt(abstime, abstime)
  RETURNS bool
AS
$BODY$
abstimelt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

