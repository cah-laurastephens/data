CREATE FUNCTION euc_jp_to_mic()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.euc_jp_to_mic(int4, int4, cstring, internal, int4)
  RETURNS void
AS
'246C69626469722F6575635F6A705F616E645F736A6973', 'euc_jp_to_mic'VOLATILE STRICT;
$$;

