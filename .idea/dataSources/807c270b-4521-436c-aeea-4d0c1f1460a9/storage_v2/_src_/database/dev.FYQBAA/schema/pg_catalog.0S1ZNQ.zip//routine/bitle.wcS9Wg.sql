CREATE FUNCTION bitle()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.bitle(bit, bit)
  RETURNS bool
AS
$BODY$
bitle
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

