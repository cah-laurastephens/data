CREATE FUNCTION date_diff()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.date_diff(text, timestamp, timestamp)
  RETURNS int8
AS
$BODY$
date_diff
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

