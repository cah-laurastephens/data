CREATE FUNCTION btint82cmp()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.btint82cmp(int8, int2)
  RETURNS int4
AS
$BODY$
btint82cmp
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

