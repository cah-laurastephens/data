CREATE FUNCTION "RI_FKey_cascade_del"()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.RI_FKey_cascade_del()
  RETURNS trigger
AS
$BODY$
RI_FKey_cascade_del
$BODY$
LANGUAGE internal VOLATILE STRICT;
$$;

