CREATE FUNCTION abstimerecv()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.abstimerecv(internal)
  RETURNS abstime
AS
$BODY$
abstimerecv
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

