CREATE FUNCTION btfloat8cmp()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.btfloat8cmp(float8, float8)
  RETURNS int4
AS
$BODY$
btfloat8cmp
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

