CREATE FUNCTION byteasend()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.byteasend(bytea)
  RETURNS bytea
AS
$BODY$
byteasend
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

