CREATE FUNCTION btint48cmp()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.btint48cmp(int4, int8)
  RETURNS int4
AS
$BODY$
btint48cmp
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

