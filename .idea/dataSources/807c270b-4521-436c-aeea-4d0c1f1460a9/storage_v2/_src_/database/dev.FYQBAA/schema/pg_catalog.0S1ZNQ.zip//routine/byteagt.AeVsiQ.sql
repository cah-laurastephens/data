CREATE FUNCTION byteagt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.byteagt(bytea, bytea)
  RETURNS bool
AS
$BODY$
byteagt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

