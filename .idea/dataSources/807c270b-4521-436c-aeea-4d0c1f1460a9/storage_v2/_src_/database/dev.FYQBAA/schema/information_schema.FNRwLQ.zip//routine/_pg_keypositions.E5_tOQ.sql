CREATE FUNCTION "_pg_keypositions"()
AS $$
CREATE OR REPLACE FUNCTION information_schema._pg_keypositions()
  RETURNS SETOF int4
AS
$BODY$
select g.s
        from generate_series(1,current_setting('max_index_keys')::int,1)
        as g(s)
$BODY$
LANGUAGE sql IMMUTABLE;
$$;

