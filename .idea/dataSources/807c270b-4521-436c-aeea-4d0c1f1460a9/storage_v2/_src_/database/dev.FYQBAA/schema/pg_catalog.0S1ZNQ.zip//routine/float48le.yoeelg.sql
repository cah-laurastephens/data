CREATE FUNCTION float48le()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.float48le(float4, float8)
  RETURNS bool
AS
$BODY$
float48le
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

