CREATE FUNCTION cidr_send()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.cidr_send(cidr)
  RETURNS bytea
AS
$BODY$
cidr_send
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

