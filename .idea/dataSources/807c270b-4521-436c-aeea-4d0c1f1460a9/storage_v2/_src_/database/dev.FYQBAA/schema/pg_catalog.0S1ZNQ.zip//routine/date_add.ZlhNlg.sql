CREATE FUNCTION date_add()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.date_add(text, int8, timestamp)
  RETURNS timestamp
AS
$BODY$
date_add
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

