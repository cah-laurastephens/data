CREATE FUNCTION box_in()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.box_in(cstring)
  RETURNS point[]
AS
$BODY$
box_in
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

