CREATE FUNCTION broadcast()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.broadcast(inet)
  RETURNS inet
AS
$BODY$
network_broadcast
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

