CREATE FUNCTION float48div()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.float48div(float4, float8)
  RETURNS float8
AS
$BODY$
float48div
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

