CREATE FUNCTION any_in()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.any_in(cstring)
  RETURNS any
AS
$BODY$
any_in
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

