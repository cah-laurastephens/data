CREATE FUNCTION box_lt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.box_lt(point[], point[])
  RETURNS bool
AS
$BODY$
box_lt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

