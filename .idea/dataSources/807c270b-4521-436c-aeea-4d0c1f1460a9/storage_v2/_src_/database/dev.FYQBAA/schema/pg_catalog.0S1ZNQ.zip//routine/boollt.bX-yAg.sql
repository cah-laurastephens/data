CREATE FUNCTION boollt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.boollt(bool, bool)
  RETURNS bool
AS
$BODY$
boollt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

