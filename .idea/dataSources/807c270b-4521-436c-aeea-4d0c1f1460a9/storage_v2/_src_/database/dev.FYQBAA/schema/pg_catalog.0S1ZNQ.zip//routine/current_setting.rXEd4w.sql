CREATE FUNCTION current_setting()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.current_setting(text)
  RETURNS text
AS
$BODY$
show_config_by_name
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

