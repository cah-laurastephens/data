CREATE FUNCTION btfloat84cmp()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.btfloat84cmp(float8, float4)
  RETURNS int4
AS
$BODY$
btfloat84cmp
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

