CREATE FUNCTION dist_pc()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.dist_pc(float8[], circle)
  RETURNS float8
AS
$BODY$
dist_pc
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

