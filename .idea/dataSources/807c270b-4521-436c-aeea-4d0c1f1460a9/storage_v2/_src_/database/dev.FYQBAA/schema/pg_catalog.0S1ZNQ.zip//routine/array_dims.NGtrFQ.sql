CREATE FUNCTION array_dims()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.array_dims(anyarray)
  RETURNS text
AS
$BODY$
array_dims
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

