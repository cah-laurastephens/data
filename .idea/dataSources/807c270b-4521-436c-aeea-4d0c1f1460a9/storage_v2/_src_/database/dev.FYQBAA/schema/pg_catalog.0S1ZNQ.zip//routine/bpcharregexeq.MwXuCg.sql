CREATE FUNCTION bpcharregexeq()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.bpcharregexeq(bpchar, text)
  RETURNS bool
AS
$BODY$
textregexeq
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

