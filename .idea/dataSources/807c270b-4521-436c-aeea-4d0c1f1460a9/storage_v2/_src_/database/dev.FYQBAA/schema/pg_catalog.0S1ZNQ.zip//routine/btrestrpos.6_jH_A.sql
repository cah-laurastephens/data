CREATE FUNCTION btrestrpos()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.btrestrpos(internal)
  RETURNS void
AS
$BODY$
btrestrpos
$BODY$
LANGUAGE internal VOLATILE STRICT;
$$;

