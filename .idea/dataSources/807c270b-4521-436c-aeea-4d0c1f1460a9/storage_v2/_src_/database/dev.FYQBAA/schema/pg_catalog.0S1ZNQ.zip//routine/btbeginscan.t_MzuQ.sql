CREATE FUNCTION btbeginscan()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.btbeginscan(internal, internal, internal)
  RETURNS internal
AS
$BODY$
btbeginscan
$BODY$
LANGUAGE internal VOLATILE STRICT;
$$;

