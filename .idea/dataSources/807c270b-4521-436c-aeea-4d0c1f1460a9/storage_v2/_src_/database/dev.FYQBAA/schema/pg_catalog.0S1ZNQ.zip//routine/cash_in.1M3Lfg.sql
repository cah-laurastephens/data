CREATE FUNCTION cash_in()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.cash_in(cstring)
  RETURNS money
AS
$BODY$
cash_in
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

