CREATE FUNCTION aclitemin()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.aclitemin(cstring)
  RETURNS aclitem
AS
$BODY$
aclitemin
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

