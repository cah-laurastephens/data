CREATE FUNCTION eqsel()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.eqsel(internal, oid, internal, int4)
  RETURNS float8
AS
$BODY$
eqsel
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

