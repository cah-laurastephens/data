CREATE FUNCTION box_intersect()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.box_intersect(point[], point[])
  RETURNS point[]
AS
$BODY$
box_intersect
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

