CREATE FUNCTION bitshiftright()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.bitshiftright(bit, int4)
  RETURNS bit
AS
$BODY$
bitshiftright
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

