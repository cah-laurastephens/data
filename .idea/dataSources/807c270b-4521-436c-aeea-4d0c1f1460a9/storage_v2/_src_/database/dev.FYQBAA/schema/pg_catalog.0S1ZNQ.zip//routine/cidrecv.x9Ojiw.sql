CREATE FUNCTION cidrecv()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.cidrecv(internal)
  RETURNS cid
AS
$BODY$
cidrecv
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

