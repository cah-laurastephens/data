CREATE FUNCTION datetimetz_pl()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.datetimetz_pl(date, timetz)
  RETURNS timestamptz
AS
$BODY$
datetimetz_timestamptz
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

