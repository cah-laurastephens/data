CREATE FUNCTION dcbrt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.dcbrt(float8)
  RETURNS float8
AS
$BODY$
dcbrt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

