CREATE FUNCTION box_same()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.box_same(point[], point[])
  RETURNS bool
AS
$BODY$
box_same
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

