CREATE FUNCTION array_cat()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.array_cat(anyarray, anyarray)
  RETURNS anyarray
AS
$BODY$
array_cat
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

