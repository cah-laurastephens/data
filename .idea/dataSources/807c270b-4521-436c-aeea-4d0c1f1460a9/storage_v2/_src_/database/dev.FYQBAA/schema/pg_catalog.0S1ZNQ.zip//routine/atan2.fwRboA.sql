CREATE FUNCTION atan2()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.atan2(float8, float8)
  RETURNS float8
AS
$BODY$
datan2
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

