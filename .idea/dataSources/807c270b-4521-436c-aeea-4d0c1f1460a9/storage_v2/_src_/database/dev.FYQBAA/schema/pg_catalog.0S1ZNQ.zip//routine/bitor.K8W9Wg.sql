CREATE FUNCTION bitor()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.bitor(bit, bit)
  RETURNS bit
AS
$BODY$
bitor
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

