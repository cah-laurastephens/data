CREATE FUNCTION contains()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.contains(text, text)
  RETURNS bool
AS
$BODY$
xen_contains
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.contains(bpchar, text)
  RETURNS bool
AS
$BODY$
xen_contains
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

