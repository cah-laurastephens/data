CREATE FUNCTION bool_or()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.bool_or(bool)
  RETURNS bool
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
$$;

