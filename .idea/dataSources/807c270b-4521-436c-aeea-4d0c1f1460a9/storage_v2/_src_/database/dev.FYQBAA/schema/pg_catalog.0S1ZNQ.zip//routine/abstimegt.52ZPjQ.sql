CREATE FUNCTION abstimegt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.abstimegt(abstime, abstime)
  RETURNS bool
AS
$BODY$
abstimegt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

