CREATE FUNCTION datetime_pl()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.datetime_pl(date, time)
  RETURNS timestamp
AS
$BODY$
datetime_timestamp
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

