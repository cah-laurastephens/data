CREATE FUNCTION btname_pattern_cmp()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.btname_pattern_cmp(char[], char[])
  RETURNS int4
AS
$BODY$
btname_pattern_cmp
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

