CREATE FUNCTION dist_pb()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.dist_pb(float8[], point[])
  RETURNS float8
AS
$BODY$
dist_pb
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

