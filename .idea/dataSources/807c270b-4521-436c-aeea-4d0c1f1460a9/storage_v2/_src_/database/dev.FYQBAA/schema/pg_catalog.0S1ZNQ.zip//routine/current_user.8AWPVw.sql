CREATE FUNCTION "current_user"()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog."current_user"()
  RETURNS bpchar
AS
$BODY$
current_user
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

