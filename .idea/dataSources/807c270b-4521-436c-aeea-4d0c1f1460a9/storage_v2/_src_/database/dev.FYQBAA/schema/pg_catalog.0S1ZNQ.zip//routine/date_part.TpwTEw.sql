CREATE FUNCTION date_part()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.date_part(text, abstime)
  RETURNS float8
AS
$BODY$
select pg_catalog.date_part($1, cast($2 as timestamp with time zone))
$BODY$
LANGUAGE sql STABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.date_part(text, reltime)
  RETURNS float8
AS
$BODY$
select pg_catalog.date_part($1, cast($2 as pg_catalog.interval))
$BODY$
LANGUAGE sql STABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.date_part(text, date)
  RETURNS int4
AS
$BODY$
date_part
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.date_part(text, time)
  RETURNS float8
AS
$BODY$
time_part
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.date_part(text, timestamp)
  RETURNS int4
AS
$BODY$
datetime_part
$BODY$
LANGUAGE internal STABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.date_part(text, timestamptz)
  RETURNS float8
AS
$BODY$
timestamptz_part
$BODY$
LANGUAGE internal STABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.date_part(text, interval)
  RETURNS float8
AS
$BODY$
interval_part
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.date_part(text, timetz)
  RETURNS float8
AS
$BODY$
timetz_part
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

