CREATE FUNCTION charge()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.charge(char, char)
  RETURNS bool
AS
$BODY$
charge
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

