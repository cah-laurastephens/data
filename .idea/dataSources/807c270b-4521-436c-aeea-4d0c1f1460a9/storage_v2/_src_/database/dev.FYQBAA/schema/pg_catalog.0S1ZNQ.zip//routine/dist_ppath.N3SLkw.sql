CREATE FUNCTION dist_ppath()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.dist_ppath(float8[], path)
  RETURNS float8
AS
$BODY$
dist_ppath
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

