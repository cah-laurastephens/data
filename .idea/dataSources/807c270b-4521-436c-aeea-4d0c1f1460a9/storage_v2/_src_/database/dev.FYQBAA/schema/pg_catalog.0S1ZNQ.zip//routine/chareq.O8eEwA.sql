CREATE FUNCTION chareq()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.chareq(char, char)
  RETURNS bool
AS
$BODY$
chareq
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

