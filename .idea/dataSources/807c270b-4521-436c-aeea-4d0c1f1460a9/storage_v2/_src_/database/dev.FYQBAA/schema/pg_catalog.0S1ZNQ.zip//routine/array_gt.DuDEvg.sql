CREATE FUNCTION array_gt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.array_gt(anyarray, anyarray)
  RETURNS bool
AS
$BODY$
array_gt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

