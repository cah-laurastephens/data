CREATE FUNCTION dist_ps()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.dist_ps(float8[], point[])
  RETURNS float8
AS
$BODY$
dist_ps
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

