CREATE FUNCTION dist_sb()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.dist_sb(point[], point[])
  RETURNS float8
AS
$BODY$
dist_sb
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

