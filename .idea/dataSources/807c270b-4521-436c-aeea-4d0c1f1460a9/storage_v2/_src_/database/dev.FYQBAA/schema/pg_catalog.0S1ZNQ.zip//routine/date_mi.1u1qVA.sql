CREATE FUNCTION date_mi()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.date_mi(date, date)
  RETURNS int4
AS
$BODY$
date_mi
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

