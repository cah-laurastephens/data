CREATE FUNCTION bool_and()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.bool_and(bool)
  RETURNS bool
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
$$;

