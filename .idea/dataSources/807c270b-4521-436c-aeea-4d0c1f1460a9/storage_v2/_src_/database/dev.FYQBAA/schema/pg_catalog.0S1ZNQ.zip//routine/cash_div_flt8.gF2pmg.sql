CREATE FUNCTION cash_div_flt8()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.cash_div_flt8(money, float8)
  RETURNS money
AS
$BODY$
cash_div_flt8
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

