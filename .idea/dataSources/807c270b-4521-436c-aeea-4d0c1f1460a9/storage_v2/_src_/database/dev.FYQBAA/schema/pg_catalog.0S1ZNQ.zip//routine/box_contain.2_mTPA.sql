CREATE FUNCTION box_contain()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.box_contain(point[], point[])
  RETURNS bool
AS
$BODY$
box_contain
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

