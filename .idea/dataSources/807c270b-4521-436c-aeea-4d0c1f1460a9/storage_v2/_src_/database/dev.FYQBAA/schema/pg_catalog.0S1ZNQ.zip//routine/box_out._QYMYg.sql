CREATE FUNCTION box_out()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.box_out(point[])
  RETURNS cstring
AS
$BODY$
box_out
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

