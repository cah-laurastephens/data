CREATE FUNCTION degrees()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.degrees(float8)
  RETURNS float8
AS
$BODY$
degrees
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

