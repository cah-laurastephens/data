CREATE FUNCTION circle_contained()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.circle_contained(circle, circle)
  RETURNS bool
AS
$BODY$
circle_contained
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

