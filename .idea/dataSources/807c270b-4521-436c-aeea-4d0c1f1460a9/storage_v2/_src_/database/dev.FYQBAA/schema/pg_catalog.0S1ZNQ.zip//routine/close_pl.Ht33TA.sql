CREATE FUNCTION close_pl()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.close_pl(float8[], float8[])
  RETURNS float8[]
AS
$BODY$
close_pl
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

