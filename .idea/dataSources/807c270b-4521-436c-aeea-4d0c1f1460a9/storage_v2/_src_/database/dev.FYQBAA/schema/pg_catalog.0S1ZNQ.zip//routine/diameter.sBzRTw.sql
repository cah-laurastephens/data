CREATE FUNCTION diameter()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.diameter(circle)
  RETURNS float8
AS
$BODY$
circle_diameter
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

