CREATE FUNCTION array_out()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.array_out(anyarray)
  RETURNS cstring
AS
$BODY$
array_out
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

