CREATE FUNCTION close_ls()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.close_ls(float8[], point[])
  RETURNS float8[]
AS
$BODY$
close_ls
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

