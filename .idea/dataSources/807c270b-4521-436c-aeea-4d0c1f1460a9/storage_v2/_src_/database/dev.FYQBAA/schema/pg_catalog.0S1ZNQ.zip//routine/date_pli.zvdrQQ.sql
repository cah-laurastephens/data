CREATE FUNCTION date_pli()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.date_pli(date, int4)
  RETURNS date
AS
$BODY$
date_pli
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

