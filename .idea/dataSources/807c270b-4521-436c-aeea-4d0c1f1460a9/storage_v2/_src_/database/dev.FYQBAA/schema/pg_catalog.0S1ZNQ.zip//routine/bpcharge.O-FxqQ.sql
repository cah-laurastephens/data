CREATE FUNCTION bpcharge()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.bpcharge(bpchar, bpchar)
  RETURNS bool
AS
$BODY$
bpcharge
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

