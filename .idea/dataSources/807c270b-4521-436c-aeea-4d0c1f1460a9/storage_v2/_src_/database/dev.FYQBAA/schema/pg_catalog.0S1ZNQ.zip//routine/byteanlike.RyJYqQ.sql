CREATE FUNCTION byteanlike()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.byteanlike(bytea, bytea)
  RETURNS bool
AS
$BODY$
byteanlike
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

