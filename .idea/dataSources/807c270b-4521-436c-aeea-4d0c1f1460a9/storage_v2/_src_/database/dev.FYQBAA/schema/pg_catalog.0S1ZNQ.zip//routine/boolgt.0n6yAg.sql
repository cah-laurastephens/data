CREATE FUNCTION boolgt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.boolgt(bool, bool)
  RETURNS bool
AS
$BODY$
boolgt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

