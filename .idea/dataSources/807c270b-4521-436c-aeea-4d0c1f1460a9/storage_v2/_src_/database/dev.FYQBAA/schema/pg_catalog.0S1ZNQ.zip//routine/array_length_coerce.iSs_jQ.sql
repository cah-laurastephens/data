CREATE FUNCTION array_length_coerce()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.array_length_coerce(anyarray, int4, bool)
  RETURNS anyarray
AS
$BODY$
array_length_coerce
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

