CREATE FUNCTION cash_mi()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.cash_mi(money, money)
  RETURNS money
AS
$BODY$
cash_mi
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

