CREATE FUNCTION circle_distance()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.circle_distance(circle, circle)
  RETURNS float8
AS
$BODY$
circle_distance
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

