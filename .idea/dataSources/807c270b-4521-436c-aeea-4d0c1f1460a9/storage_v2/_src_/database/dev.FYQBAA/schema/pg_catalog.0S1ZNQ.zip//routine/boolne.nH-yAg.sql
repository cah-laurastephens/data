CREATE FUNCTION boolne()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.boolne(bool, bool)
  RETURNS bool
AS
$BODY$
boolne
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

