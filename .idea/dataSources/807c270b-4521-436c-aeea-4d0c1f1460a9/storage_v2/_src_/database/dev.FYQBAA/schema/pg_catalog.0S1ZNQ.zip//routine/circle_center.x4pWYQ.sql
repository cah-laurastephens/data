CREATE FUNCTION circle_center()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.circle_center(circle)
  RETURNS float8[]
AS
$BODY$
circle_center
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

