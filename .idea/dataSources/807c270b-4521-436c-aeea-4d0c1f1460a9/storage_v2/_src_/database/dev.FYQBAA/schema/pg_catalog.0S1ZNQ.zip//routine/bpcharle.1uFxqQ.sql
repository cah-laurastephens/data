CREATE FUNCTION bpcharle()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.bpcharle(bpchar, bpchar)
  RETURNS bool
AS
$BODY$
bpcharle
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

