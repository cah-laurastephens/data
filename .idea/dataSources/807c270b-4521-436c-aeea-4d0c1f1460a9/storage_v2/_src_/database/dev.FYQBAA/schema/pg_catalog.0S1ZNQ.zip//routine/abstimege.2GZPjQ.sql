CREATE FUNCTION abstimege()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.abstimege(abstime, abstime)
  RETURNS bool
AS
$BODY$
abstimege
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

