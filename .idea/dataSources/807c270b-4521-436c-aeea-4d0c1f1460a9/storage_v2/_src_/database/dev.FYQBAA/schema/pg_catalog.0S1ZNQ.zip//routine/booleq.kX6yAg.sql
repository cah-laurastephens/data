CREATE FUNCTION booleq()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.booleq(bool, bool)
  RETURNS bool
AS
$BODY$
booleq
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

