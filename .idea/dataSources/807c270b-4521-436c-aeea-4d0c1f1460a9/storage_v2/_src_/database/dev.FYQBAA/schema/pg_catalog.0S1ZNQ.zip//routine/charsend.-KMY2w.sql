CREATE FUNCTION charsend()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.charsend(char)
  RETURNS bytea
AS
$BODY$
charsend
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

