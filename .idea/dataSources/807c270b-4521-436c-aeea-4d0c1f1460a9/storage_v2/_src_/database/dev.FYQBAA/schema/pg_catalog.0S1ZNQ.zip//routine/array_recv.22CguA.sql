CREATE FUNCTION array_recv()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.array_recv(internal, oid)
  RETURNS anyarray
AS
$BODY$
array_recv
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

