CREATE FUNCTION boolor_statefunc()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.boolor_statefunc(bool, bool)
  RETURNS bool
AS
$BODY$
boolor_statefunc
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

