CREATE FUNCTION "RI_FKey_restrict_upd"()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.RI_FKey_restrict_upd()
  RETURNS trigger
AS
$BODY$
RI_FKey_restrict_upd
$BODY$
LANGUAGE internal VOLATILE STRICT;
$$;

