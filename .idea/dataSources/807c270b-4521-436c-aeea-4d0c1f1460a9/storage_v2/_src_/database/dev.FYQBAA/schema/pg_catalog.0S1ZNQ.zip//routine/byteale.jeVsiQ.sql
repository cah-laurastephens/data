CREATE FUNCTION byteale()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.byteale(bytea, bytea)
  RETURNS bool
AS
$BODY$
byteale
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

