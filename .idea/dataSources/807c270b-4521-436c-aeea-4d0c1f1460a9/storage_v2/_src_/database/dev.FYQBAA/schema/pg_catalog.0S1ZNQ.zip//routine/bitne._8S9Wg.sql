CREATE FUNCTION bitne()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.bitne(bit, bit)
  RETURNS bool
AS
$BODY$
bitne
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

