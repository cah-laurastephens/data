CREATE FUNCTION box_add()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.box_add(point[], float8[])
  RETURNS point[]
AS
$BODY$
box_add
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

