CREATE FUNCTION array_ge()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.array_ge(anyarray, anyarray)
  RETURNS bool
AS
$BODY$
array_ge
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

