CREATE FUNCTION box_right()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.box_right(point[], point[])
  RETURNS bool
AS
$BODY$
box_right
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

