CREATE FUNCTION cashsmaller()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.cashsmaller(money, money)
  RETURNS money
AS
$BODY$
cashsmaller
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

