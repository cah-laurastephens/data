CREATE FUNCTION btgettuple()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.btgettuple(internal, internal)
  RETURNS bool
AS
$BODY$
btgettuple
$BODY$
LANGUAGE internal VOLATILE STRICT;
$$;

