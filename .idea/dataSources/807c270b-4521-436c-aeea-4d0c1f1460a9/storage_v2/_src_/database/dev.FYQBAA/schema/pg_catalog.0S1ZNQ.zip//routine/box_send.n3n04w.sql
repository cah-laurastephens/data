CREATE FUNCTION box_send()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.box_send(point[])
  RETURNS bytea
AS
$BODY$
box_send
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

