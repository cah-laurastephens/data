CREATE FUNCTION convert_using()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.convert_using(text, text)
  RETURNS text
AS
$BODY$
pg_convert_using
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

