CREATE FUNCTION area()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.area(path)
  RETURNS float8
AS
$BODY$
path_area
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.area(point[])
  RETURNS float8
AS
$BODY$
box_area
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.area(circle)
  RETURNS float8
AS
$BODY$
circle_area
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

