CREATE FUNCTION circle_same()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.circle_same(circle, circle)
  RETURNS bool
AS
$BODY$
circle_same
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

