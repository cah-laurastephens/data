CREATE FUNCTION "_pg_char_octet_length"()
AS $$
CREATE OR REPLACE FUNCTION information_schema._pg_char_octet_length(typid oid, typmod int4)
  RETURNS int4
AS
$BODY$
SELECT
  CASE WHEN $1 IN (25, 1042, 1043) /* text, char, varchar */
       THEN CAST(2^30 AS integer)
       ELSE null
  END
$BODY$
LANGUAGE sql IMMUTABLE STRICT;
$$;

