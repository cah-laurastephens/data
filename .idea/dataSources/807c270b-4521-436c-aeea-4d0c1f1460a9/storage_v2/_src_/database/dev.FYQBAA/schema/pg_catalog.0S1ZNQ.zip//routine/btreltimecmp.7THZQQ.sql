CREATE FUNCTION btreltimecmp()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.btreltimecmp(reltime, reltime)
  RETURNS int4
AS
$BODY$
btreltimecmp
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

