CREATE FUNCTION btboolcmp()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.btboolcmp(bool, bool)
  RETURNS int4
AS
$BODY$
btboolcmp
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

