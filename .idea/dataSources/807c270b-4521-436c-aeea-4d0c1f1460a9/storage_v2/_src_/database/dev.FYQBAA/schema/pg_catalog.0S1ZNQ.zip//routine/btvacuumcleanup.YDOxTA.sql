CREATE FUNCTION btvacuumcleanup()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.btvacuumcleanup(internal, internal, internal)
  RETURNS internal
AS
$BODY$
btvacuumcleanup
$BODY$
LANGUAGE internal VOLATILE STRICT;
$$;

