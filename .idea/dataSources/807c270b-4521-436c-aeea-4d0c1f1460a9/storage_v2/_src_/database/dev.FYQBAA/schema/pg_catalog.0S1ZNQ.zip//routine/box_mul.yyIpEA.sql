CREATE FUNCTION box_mul()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.box_mul(point[], float8[])
  RETURNS point[]
AS
$BODY$
box_mul
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

