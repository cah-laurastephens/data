CREATE FUNCTION bitcat()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.bitcat(bit, bit)
  RETURNS bit
AS
$BODY$
bitcat
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

