CREATE FUNCTION array_lower()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.array_lower(anyarray, int4)
  RETURNS int4
AS
$BODY$
array_lower
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

