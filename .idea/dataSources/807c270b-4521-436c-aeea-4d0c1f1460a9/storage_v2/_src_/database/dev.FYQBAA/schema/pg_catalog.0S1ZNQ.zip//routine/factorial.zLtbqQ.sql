CREATE FUNCTION factorial()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.factorial(int8)
  RETURNS numeric
AS
$BODY$
numeric_fac
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

