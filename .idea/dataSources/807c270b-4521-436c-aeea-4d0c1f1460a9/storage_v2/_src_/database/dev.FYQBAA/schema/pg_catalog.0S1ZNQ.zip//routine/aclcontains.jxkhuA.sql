CREATE FUNCTION aclcontains()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.aclcontains(aclitem[], aclitem)
  RETURNS bool
AS
$BODY$
aclcontains
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

