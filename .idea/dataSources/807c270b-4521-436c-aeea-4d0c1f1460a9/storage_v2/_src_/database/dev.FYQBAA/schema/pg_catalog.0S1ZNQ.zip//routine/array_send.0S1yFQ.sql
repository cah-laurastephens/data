CREATE FUNCTION array_send()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.array_send(anyarray)
  RETURNS bytea
AS
$BODY$
array_send
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

