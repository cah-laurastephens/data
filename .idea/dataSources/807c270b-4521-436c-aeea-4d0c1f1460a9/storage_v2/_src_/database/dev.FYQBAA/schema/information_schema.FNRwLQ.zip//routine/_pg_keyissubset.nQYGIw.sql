CREATE FUNCTION "_pg_keyissubset"()
AS $$
CREATE OR REPLACE FUNCTION information_schema._pg_keyissubset(int2[], int2[])
  RETURNS bool
AS
$BODY$
select $1[1] is null or ($1[1] = any ($2) and coalesce(information_schema._pg_keyissubset($1[2:pg_catalog.array_upper($1,1)], $2), true))
$BODY$
LANGUAGE sql IMMUTABLE STRICT;
$$;

