CREATE FUNCTION btint24cmp()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.btint24cmp(int2, int4)
  RETURNS int4
AS
$BODY$
btint24cmp
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

