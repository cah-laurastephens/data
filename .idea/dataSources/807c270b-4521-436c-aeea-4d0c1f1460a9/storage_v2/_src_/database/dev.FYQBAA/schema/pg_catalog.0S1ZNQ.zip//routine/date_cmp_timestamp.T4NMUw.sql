CREATE FUNCTION date_cmp_timestamp()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.date_cmp_timestamp(date, timestamp)
  RETURNS int4
AS
$BODY$
date_cmp_timestamp
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

