CREATE FUNCTION "current_user_id"()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.current_user_id()
  RETURNS int4
AS
$BODY$
current_user_id
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

