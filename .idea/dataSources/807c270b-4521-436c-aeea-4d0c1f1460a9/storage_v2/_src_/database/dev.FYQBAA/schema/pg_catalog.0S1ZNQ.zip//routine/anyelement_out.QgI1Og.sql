CREATE FUNCTION anyelement_out()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.anyelement_out(anyelement)
  RETURNS cstring
AS
$BODY$
anyelement_out
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

