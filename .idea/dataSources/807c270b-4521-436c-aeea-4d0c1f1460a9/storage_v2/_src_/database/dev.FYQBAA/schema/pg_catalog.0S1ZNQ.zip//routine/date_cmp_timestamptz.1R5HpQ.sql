CREATE FUNCTION date_cmp_timestamptz()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.date_cmp_timestamptz(date, timestamptz)
  RETURNS int4
AS
$BODY$
date_cmp_timestamptz
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

