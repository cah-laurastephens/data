CREATE FUNCTION array_upper()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.array_upper(anyarray, int4)
  RETURNS int4
AS
$BODY$
array_upper
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

