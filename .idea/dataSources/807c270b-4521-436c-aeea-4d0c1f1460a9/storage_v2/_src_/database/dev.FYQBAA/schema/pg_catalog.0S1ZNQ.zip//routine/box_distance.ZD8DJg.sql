CREATE FUNCTION box_distance()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.box_distance(point[], point[])
  RETURNS float8
AS
$BODY$
box_distance
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

