CREATE FUNCTION diagonal()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.diagonal(point[])
  RETURNS point[]
AS
$BODY$
box_diagonal
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

