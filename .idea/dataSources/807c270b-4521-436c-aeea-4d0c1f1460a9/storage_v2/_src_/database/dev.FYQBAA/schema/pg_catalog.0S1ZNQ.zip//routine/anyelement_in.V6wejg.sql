CREATE FUNCTION anyelement_in()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.anyelement_in(cstring)
  RETURNS anyelement
AS
$BODY$
anyelement_in
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

