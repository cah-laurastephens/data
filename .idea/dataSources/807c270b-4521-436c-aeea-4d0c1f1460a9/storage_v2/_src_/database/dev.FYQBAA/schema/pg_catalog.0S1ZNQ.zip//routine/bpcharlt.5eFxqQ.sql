CREATE FUNCTION bpcharlt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.bpcharlt(bpchar, bpchar)
  RETURNS bool
AS
$BODY$
bpcharlt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

