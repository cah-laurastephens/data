CREATE FUNCTION circle_contain()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.circle_contain(circle, circle)
  RETURNS bool
AS
$BODY$
circle_contain
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

