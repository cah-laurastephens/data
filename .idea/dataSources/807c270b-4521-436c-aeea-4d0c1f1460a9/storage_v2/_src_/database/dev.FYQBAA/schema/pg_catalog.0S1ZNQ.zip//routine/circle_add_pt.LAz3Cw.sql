CREATE FUNCTION circle_add_pt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.circle_add_pt(circle, float8[])
  RETURNS circle
AS
$BODY$
circle_add_pt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

