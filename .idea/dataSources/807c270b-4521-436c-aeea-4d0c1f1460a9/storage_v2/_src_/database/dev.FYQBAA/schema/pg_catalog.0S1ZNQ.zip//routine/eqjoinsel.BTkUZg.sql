CREATE FUNCTION eqjoinsel()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.eqjoinsel(internal, oid, internal, int2)
  RETURNS float8
AS
$BODY$
eqjoinsel
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

