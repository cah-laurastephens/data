CREATE FUNCTION count()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.count(any)
  RETURNS int8
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
$$;

