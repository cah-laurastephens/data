CREATE FUNCTION array_le()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.array_le(anyarray, anyarray)
  RETURNS bool
AS
$BODY$
array_le
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

