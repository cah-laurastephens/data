CREATE FUNCTION cash_div_flt4()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.cash_div_flt4(money, float4)
  RETURNS money
AS
$BODY$
cash_div_flt4
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

