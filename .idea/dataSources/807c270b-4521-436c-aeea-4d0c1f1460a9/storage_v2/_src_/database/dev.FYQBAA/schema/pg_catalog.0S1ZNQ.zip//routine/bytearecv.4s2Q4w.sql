CREATE FUNCTION bytearecv()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.bytearecv(internal)
  RETURNS bytea
AS
$BODY$
bytearecv
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

