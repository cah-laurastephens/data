CREATE FUNCTION anyarray_recv()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.anyarray_recv(internal)
  RETURNS anyarray
AS
$BODY$
anyarray_recv
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

