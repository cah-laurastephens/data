CREATE FUNCTION btint84cmp()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.btint84cmp(int8, int4)
  RETURNS int4
AS
$BODY$
btint84cmp
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

