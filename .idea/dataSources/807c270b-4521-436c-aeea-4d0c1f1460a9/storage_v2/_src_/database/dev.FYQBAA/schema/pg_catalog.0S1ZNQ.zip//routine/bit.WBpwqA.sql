CREATE FUNCTION bit()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.bit(int8, int4)
  RETURNS bit
AS
$BODY$
bitfromint8
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.bit(int4, int4)
  RETURNS bit
AS
$BODY$
bitfromint4
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.bit(bit, int4, bool)
  RETURNS bit
AS
$BODY$
bit
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

