CREATE FUNCTION bttextcmp()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.bttextcmp(text, text)
  RETURNS int4
AS
$BODY$
bttextcmp
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

