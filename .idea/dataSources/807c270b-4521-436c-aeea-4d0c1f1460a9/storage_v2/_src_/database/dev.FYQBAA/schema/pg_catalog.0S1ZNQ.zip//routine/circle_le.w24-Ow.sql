CREATE FUNCTION circle_le()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.circle_le(circle, circle)
  RETURNS bool
AS
$BODY$
circle_le
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

