CREATE FUNCTION abbrev()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.abbrev(inet)
  RETURNS text
AS
$BODY$
network_abbrev
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

