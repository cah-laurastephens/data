CREATE FUNCTION date_ne_timestamp()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.date_ne_timestamp(date, timestamp)
  RETURNS bool
AS
$BODY$
date_ne_timestamp
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

