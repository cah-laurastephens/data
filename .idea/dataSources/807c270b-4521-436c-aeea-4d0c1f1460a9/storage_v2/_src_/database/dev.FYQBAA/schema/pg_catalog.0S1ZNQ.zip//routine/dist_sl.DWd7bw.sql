CREATE FUNCTION dist_sl()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.dist_sl(point[], float8[])
  RETURNS float8
AS
$BODY$
dist_sl
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

