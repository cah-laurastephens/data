CREATE FUNCTION ceil()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.ceil(float8)
  RETURNS float8
AS
$BODY$
dceil
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.ceil(numeric)
  RETURNS numeric
AS
$BODY$
numeric_ceil
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

