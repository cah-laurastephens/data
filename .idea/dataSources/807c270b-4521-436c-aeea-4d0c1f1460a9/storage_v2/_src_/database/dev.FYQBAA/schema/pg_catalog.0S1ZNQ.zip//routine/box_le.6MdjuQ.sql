CREATE FUNCTION box_le()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.box_le(point[], point[])
  RETURNS bool
AS
$BODY$
box_le
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

