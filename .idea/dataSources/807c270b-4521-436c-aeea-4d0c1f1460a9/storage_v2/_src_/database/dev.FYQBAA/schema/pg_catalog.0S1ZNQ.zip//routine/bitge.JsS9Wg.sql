CREATE FUNCTION bitge()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.bitge(bit, bit)
  RETURNS bool
AS
$BODY$
bitge
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

