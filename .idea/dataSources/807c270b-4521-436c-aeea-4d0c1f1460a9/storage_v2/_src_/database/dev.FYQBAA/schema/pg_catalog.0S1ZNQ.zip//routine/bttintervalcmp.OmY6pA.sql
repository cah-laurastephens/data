CREATE FUNCTION bttintervalcmp()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.bttintervalcmp(tinterval, tinterval)
  RETURNS int4
AS
$BODY$
bttintervalcmp
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

