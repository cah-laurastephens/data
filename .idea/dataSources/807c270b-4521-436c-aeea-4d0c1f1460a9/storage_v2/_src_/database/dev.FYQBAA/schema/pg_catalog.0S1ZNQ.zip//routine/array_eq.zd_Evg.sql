CREATE FUNCTION array_eq()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.array_eq(anyarray, anyarray)
  RETURNS bool
AS
$BODY$
array_eq
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

