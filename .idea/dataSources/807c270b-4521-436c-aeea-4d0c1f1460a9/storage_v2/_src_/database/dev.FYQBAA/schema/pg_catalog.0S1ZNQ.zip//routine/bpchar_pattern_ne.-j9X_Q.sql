CREATE FUNCTION bpchar_pattern_ne()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.bpchar_pattern_ne(bpchar, bpchar)
  RETURNS bool
AS
$BODY$
text_pattern_ne
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

