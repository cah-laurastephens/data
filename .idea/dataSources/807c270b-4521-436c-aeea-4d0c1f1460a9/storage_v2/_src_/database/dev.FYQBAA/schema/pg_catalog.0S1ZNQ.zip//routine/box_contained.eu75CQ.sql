CREATE FUNCTION box_contained()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.box_contained(point[], point[])
  RETURNS bool
AS
$BODY$
box_contained
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

