CREATE FUNCTION cidr_out()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.cidr_out(cidr)
  RETURNS cstring
AS
$BODY$
cidr_out
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

