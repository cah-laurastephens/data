CREATE FUNCTION dsqrt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.dsqrt(float8)
  RETURNS float8
AS
$BODY$
dsqrt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

