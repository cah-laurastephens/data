CREATE FUNCTION date_mi_interval()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.date_mi_interval(date, interval)
  RETURNS timestamp
AS
$BODY$
date_mi_interval
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

