CREATE FUNCTION float48eq()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.float48eq(float4, float8)
  RETURNS bool
AS
$BODY$
float48eq
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

