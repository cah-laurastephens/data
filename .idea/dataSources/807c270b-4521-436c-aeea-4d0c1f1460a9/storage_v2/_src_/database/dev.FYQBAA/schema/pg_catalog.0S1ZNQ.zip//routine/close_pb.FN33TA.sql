CREATE FUNCTION close_pb()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.close_pb(float8[], point[])
  RETURNS float8[]
AS
$BODY$
close_pb
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

