CREATE FUNCTION bitcmp()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.bitcmp(bit, bit)
  RETURNS int4
AS
$BODY$
bitcmp
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

