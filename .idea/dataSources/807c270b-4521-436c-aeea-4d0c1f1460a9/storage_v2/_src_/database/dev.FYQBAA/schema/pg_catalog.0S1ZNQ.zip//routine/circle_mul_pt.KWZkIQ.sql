CREATE FUNCTION circle_mul_pt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.circle_mul_pt(circle, float8[])
  RETURNS circle
AS
$BODY$
circle_mul_pt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

