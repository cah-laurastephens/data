CREATE FUNCTION date_send()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.date_send(date)
  RETURNS bytea
AS
$BODY$
date_send
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

