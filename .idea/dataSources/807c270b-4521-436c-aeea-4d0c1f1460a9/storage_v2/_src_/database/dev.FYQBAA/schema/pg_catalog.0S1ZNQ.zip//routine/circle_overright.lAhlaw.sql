CREATE FUNCTION circle_overright()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.circle_overright(circle, circle)
  RETURNS bool
AS
$BODY$
circle_overright
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

