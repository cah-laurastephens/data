CREATE FUNCTION "RI_FKey_setnull_upd"()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.RI_FKey_setnull_upd()
  RETURNS trigger
AS
$BODY$
RI_FKey_setnull_upd
$BODY$
LANGUAGE internal VOLATILE STRICT;
$$;

