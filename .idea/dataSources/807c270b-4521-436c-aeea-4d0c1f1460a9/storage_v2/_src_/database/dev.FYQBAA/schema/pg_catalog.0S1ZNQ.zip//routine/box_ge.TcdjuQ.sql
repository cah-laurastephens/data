CREATE FUNCTION box_ge()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.box_ge(point[], point[])
  RETURNS bool
AS
$BODY$
box_ge
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

