CREATE FUNCTION box_center()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.box_center(point[])
  RETURNS float8[]
AS
$BODY$
box_center
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

