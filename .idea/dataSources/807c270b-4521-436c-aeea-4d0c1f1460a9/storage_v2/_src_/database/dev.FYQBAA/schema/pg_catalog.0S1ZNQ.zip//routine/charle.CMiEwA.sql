CREATE FUNCTION charle()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.charle(char, char)
  RETURNS bool
AS
$BODY$
charle
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

