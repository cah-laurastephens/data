CREATE FUNCTION charrecv()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.charrecv(internal)
  RETURNS char
AS
$BODY$
charrecv
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

