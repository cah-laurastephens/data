CREATE FUNCTION bit_recv()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.bit_recv(internal)
  RETURNS bit
AS
$BODY$
bit_recv
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

