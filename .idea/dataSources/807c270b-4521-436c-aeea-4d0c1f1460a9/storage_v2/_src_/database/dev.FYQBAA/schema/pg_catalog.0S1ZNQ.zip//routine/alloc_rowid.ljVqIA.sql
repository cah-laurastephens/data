CREATE FUNCTION alloc_rowid()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.alloc_rowid(int4)
  RETURNS int8
AS
$BODY$
ff_alloc_rowid
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

