CREATE FUNCTION bit_out()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.bit_out(bit)
  RETURNS cstring
AS
$BODY$
bit_out
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

