CREATE FUNCTION bit_and()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.bit_and(int8)
  RETURNS int8
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.bit_and(int2)
  RETURNS int2
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.bit_and(int4)
  RETURNS int4
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.bit_and(bit)
  RETURNS bit
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
$$;

