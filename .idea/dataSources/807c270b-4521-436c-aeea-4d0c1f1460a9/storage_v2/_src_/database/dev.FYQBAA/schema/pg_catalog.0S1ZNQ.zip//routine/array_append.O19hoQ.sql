CREATE FUNCTION array_append()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.array_append(anyarray, anyelement)
  RETURNS anyarray
AS
$BODY$
array_push
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

