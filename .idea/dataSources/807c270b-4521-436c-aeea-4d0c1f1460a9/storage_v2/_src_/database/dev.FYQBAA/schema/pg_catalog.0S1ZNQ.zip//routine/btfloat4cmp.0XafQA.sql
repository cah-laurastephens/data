CREATE FUNCTION btfloat4cmp()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.btfloat4cmp(float4, float4)
  RETURNS int4
AS
$BODY$
btfloat4cmp
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

