CREATE FUNCTION bpchar()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.bpchar(char)
  RETURNS bpchar
AS
$BODY$
char_bpchar
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.bpchar(char[])
  RETURNS bpchar
AS
$BODY$
name_bpchar
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.bpchar(int8)
  RETURNS bpchar
AS
$BODY$
int8_bpchar
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.bpchar(int2)
  RETURNS bpchar
AS
$BODY$
int2_bpchar
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.bpchar(int4)
  RETURNS bpchar
AS
$BODY$
int4_bpchar
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.bpchar(float4)
  RETURNS bpchar
AS
$BODY$
float4_bpchar
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.bpchar(float8)
  RETURNS bpchar
AS
$BODY$
float8_bpchar
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.bpchar(bpchar)
  RETURNS interval
AS
$BODY$
bpchar_interval
$BODY$
LANGUAGE internal STABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.bpchar(date)
  RETURNS bpchar
AS
$BODY$
date_bpchar
$BODY$
LANGUAGE internal STABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.bpchar(timestamp)
  RETURNS bpchar
AS
$BODY$
timestamp_bpchar
$BODY$
LANGUAGE internal STABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.bpchar(timestamptz)
  RETURNS bpchar
AS
$BODY$
timestamptz_bpchar
$BODY$
LANGUAGE internal STABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.bpchar(interval)
  RETURNS bpchar
AS
$BODY$
interval_bpchar
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.bpchar(numeric)
  RETURNS bpchar
AS
$BODY$
numeric_bpchar
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.bpchar(bpchar, int4, bool)
  RETURNS bpchar
AS
$BODY$
bpchar
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

