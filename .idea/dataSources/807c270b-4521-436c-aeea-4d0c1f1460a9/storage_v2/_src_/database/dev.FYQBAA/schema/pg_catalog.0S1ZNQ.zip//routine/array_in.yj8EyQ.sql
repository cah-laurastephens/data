CREATE FUNCTION array_in()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.array_in(cstring, oid, int4)
  RETURNS anyarray
AS
$BODY$
array_in
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

