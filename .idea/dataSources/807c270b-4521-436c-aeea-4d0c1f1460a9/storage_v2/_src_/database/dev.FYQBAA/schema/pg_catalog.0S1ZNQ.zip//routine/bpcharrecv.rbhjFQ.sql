CREATE FUNCTION bpcharrecv()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.bpcharrecv(internal)
  RETURNS bpchar
AS
$BODY$
bpcharrecv
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

