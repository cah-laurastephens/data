CREATE FUNCTION dround()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.dround(float8)
  RETURNS float8
AS
$BODY$
dround
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

