CREATE FUNCTION date_ge_timestamp()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.date_ge_timestamp(date, timestamp)
  RETURNS bool
AS
$BODY$
date_ge_timestamp
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

