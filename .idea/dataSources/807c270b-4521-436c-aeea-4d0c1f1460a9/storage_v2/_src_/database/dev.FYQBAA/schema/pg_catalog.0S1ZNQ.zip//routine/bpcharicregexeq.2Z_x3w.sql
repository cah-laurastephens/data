CREATE FUNCTION bpcharicregexeq()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.bpcharicregexeq(bpchar, text)
  RETURNS bool
AS
$BODY$
texticregexeq
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

