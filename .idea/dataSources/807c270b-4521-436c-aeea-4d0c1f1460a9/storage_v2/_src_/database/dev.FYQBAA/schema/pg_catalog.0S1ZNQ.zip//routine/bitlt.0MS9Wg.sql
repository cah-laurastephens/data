CREATE FUNCTION bitlt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.bitlt(bit, bit)
  RETURNS bool
AS
$BODY$
bitlt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

