CREATE FUNCTION biteq()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.biteq(bit, bit)
  RETURNS bool
AS
$BODY$
biteq
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

