CREATE FUNCTION every()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.every(bool)
  RETURNS bool
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
$$;

