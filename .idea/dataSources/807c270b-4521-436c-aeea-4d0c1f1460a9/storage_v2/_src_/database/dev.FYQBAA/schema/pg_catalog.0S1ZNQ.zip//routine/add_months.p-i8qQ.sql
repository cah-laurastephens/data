CREATE FUNCTION add_months()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.add_months(timestamp, int8)
  RETURNS timestamp
AS
$BODY$
add_months
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

