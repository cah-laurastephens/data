CREATE FUNCTION aclitemeq()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.aclitemeq(aclitem, aclitem)
  RETURNS bool
AS
$BODY$
aclitem_eq
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

