CREATE FUNCTION aclitemout()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.aclitemout(aclitem)
  RETURNS cstring
AS
$BODY$
aclitemout
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

