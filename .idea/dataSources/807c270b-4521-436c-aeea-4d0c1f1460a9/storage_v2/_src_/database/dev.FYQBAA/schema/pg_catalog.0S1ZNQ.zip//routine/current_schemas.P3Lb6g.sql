CREATE FUNCTION current_schemas()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.current_schemas(bool)
  RETURNS name[]
AS
$BODY$
current_schemas
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

