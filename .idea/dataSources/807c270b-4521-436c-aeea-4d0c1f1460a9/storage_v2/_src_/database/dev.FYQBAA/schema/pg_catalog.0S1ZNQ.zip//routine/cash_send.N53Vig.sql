CREATE FUNCTION cash_send()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.cash_send(money)
  RETURNS bytea
AS
$BODY$
cash_send
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

