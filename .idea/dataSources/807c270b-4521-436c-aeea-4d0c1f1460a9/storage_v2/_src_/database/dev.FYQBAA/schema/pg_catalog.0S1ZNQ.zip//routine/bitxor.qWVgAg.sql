CREATE FUNCTION bitxor()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.bitxor(bit, bit)
  RETURNS bit
AS
$BODY$
bitxor
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

