CREATE FUNCTION areajoinsel()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.areajoinsel(internal, oid, internal, int2)
  RETURNS float8
AS
$BODY$
areajoinsel
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

