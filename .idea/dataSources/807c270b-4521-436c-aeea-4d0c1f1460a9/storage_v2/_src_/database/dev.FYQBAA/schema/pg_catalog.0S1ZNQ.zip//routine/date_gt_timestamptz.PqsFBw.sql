CREATE FUNCTION date_gt_timestamptz()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.date_gt_timestamptz(date, timestamptz)
  RETURNS bool
AS
$BODY$
date_gt_timestamptz
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

