CREATE FUNCTION cash_lt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.cash_lt(money, money)
  RETURNS bool
AS
$BODY$
cash_lt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

