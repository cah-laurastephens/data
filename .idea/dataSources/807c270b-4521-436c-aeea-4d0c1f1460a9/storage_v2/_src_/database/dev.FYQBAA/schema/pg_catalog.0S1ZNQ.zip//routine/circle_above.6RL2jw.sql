CREATE FUNCTION circle_above()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.circle_above(circle, circle)
  RETURNS bool
AS
$BODY$
circle_above
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

