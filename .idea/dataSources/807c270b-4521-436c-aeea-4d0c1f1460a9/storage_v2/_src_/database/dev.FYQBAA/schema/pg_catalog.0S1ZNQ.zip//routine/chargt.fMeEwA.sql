CREATE FUNCTION chargt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.chargt(char, char)
  RETURNS bool
AS
$BODY$
chargt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

