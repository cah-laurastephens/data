CREATE FUNCTION dense_rank()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.dense_rank()
  RETURNS int8
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal VOLATILE STRICT;
$$;

