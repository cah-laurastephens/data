CREATE FUNCTION any_out()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.any_out(any)
  RETURNS cstring
AS
$BODY$
any_out
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

