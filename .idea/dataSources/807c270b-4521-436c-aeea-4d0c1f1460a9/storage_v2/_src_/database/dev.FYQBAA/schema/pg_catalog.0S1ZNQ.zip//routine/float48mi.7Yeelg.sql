CREATE FUNCTION float48mi()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.float48mi(float4, float8)
  RETURNS float8
AS
$BODY$
float48mi
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

