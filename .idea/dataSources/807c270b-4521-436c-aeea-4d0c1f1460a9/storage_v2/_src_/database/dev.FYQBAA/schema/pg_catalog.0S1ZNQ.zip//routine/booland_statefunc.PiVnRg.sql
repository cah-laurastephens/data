CREATE FUNCTION booland_statefunc()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.booland_statefunc(bool, bool)
  RETURNS bool
AS
$BODY$
booland_statefunc
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

