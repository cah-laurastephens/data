CREATE FUNCTION box_left()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.box_left(point[], point[])
  RETURNS bool
AS
$BODY$
box_left
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

