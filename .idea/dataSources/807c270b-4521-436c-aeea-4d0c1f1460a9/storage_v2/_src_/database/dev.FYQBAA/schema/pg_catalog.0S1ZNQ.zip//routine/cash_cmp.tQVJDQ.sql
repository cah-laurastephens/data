CREATE FUNCTION cash_cmp()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.cash_cmp(money, money)
  RETURNS int4
AS
$BODY$
cash_cmp
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

