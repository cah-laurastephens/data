CREATE FUNCTION abstimeout()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.abstimeout(abstime)
  RETURNS cstring
AS
$BODY$
abstimeout
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

