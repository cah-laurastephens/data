CREATE FUNCTION anyarray_out()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.anyarray_out(anyarray)
  RETURNS cstring
AS
$BODY$
anyarray_out
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

