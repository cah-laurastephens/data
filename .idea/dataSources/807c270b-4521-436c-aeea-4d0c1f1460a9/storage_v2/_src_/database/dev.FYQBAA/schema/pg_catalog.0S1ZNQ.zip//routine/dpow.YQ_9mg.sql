CREATE FUNCTION dpow()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.dpow(float8, float8)
  RETURNS float8
AS
$BODY$
dpow
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

