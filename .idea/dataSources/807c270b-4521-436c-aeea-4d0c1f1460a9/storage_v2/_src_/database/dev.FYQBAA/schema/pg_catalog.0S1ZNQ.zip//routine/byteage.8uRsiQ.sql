CREATE FUNCTION byteage()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.byteage(bytea, bytea)
  RETURNS bool
AS
$BODY$
byteage
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

