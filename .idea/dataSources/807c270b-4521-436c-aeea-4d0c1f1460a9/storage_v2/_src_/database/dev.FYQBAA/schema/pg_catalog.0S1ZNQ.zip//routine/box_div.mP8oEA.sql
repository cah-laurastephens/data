CREATE FUNCTION box_div()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.box_div(point[], float8[])
  RETURNS point[]
AS
$BODY$
box_div
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

