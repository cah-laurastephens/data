CREATE FUNCTION cash_out()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.cash_out(money)
  RETURNS cstring
AS
$BODY$
cash_out
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

