CREATE FUNCTION float48lt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.float48lt(float4, float8)
  RETURNS bool
AS
$BODY$
float48lt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

