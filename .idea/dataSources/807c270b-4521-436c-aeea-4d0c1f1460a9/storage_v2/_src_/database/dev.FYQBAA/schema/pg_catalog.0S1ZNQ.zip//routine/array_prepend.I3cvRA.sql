CREATE FUNCTION array_prepend()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.array_prepend(anyelement, anyarray)
  RETURNS anyarray
AS
$BODY$
array_push
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

