CREATE FUNCTION dist_lb()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.dist_lb(float8[], point[])
  RETURNS float8
AS
$BODY$
dist_lb
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

