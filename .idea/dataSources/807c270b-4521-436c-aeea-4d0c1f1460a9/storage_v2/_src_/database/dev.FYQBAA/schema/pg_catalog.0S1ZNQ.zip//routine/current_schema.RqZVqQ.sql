CREATE FUNCTION current_schema()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog."current_schema"()
  RETURNS char[]
AS
$BODY$
current_schema
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

