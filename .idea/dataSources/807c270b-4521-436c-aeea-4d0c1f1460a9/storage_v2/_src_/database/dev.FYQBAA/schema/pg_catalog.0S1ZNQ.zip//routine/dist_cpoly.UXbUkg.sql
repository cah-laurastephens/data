CREATE FUNCTION dist_cpoly()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.dist_cpoly(circle, polygon)
  RETURNS float8
AS
$BODY$
dist_cpoly
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

