CREATE FUNCTION circle_overlap()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.circle_overlap(circle, circle)
  RETURNS bool
AS
$BODY$
circle_overlap
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

