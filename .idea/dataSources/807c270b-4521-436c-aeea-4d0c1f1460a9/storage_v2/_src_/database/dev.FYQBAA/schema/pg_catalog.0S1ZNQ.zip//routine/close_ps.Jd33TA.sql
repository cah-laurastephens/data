CREATE FUNCTION close_ps()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.close_ps(float8[], point[])
  RETURNS float8[]
AS
$BODY$
close_ps
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

