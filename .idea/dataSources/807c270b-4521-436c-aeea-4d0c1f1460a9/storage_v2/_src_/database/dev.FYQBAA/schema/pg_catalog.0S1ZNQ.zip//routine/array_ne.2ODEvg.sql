CREATE FUNCTION array_ne()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.array_ne(anyarray, anyarray)
  RETURNS bool
AS
$BODY$
array_ne
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

