CREATE FUNCTION abstimeeq()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.abstimeeq(abstime, abstime)
  RETURNS bool
AS
$BODY$
abstimeeq
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

