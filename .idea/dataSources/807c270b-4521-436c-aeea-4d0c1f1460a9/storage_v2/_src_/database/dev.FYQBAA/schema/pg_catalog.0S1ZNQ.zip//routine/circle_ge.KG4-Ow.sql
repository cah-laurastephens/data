CREATE FUNCTION circle_ge()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.circle_ge(circle, circle)
  RETURNS bool
AS
$BODY$
circle_ge
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

