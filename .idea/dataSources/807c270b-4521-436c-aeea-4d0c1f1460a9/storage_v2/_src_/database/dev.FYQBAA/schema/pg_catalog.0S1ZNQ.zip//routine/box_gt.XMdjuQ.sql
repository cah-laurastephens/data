CREATE FUNCTION box_gt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.box_gt(point[], point[])
  RETURNS bool
AS
$BODY$
box_gt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

