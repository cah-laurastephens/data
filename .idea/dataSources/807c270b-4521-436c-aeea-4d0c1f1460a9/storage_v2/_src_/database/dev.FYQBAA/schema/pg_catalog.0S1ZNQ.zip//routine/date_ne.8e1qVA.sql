CREATE FUNCTION date_ne()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.date_ne(date, date)
  RETURNS bool
AS
$BODY$
date_ne
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

