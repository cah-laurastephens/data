CREATE FUNCTION btbulkdelete()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.btbulkdelete(internal, internal, internal)
  RETURNS internal
AS
$BODY$
btbulkdelete
$BODY$
LANGUAGE internal VOLATILE STRICT;
$$;

