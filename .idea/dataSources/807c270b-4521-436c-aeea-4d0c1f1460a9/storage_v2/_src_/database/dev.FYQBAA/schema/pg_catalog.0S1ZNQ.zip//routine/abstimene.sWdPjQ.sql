CREATE FUNCTION abstimene()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.abstimene(abstime, abstime)
  RETURNS bool
AS
$BODY$
abstimene
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

