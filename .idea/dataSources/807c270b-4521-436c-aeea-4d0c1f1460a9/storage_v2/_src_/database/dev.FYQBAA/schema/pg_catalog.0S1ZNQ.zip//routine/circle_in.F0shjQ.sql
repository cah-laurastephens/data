CREATE FUNCTION circle_in()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.circle_in(cstring)
  RETURNS circle
AS
$BODY$
circle_in
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

