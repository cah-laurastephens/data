CREATE FUNCTION boolrecv()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.boolrecv(internal)
  RETURNS bool
AS
$BODY$
boolrecv
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

