CREATE FUNCTION byteaout()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.byteaout(bytea)
  RETURNS cstring
AS
$BODY$
byteaout
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

