CREATE FUNCTION bitgt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.bitgt(bit, bit)
  RETURNS bool
AS
$BODY$
bitgt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

