CREATE FUNCTION float48gt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.float48gt(float4, float8)
  RETURNS bool
AS
$BODY$
float48gt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

