CREATE FUNCTION bit_in()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.bit_in(cstring, oid, int4)
  RETURNS bit
AS
$BODY$
bit_in
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

