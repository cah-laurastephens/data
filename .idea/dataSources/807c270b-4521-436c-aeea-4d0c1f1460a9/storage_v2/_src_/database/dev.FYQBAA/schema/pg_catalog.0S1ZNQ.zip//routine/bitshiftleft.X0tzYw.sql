CREATE FUNCTION bitshiftleft()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.bitshiftleft(bit, int4)
  RETURNS bit
AS
$BODY$
bitshiftleft
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

