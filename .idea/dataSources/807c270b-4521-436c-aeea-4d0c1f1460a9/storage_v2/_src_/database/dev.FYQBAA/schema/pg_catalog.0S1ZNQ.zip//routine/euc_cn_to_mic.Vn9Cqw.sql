CREATE FUNCTION euc_cn_to_mic()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.euc_cn_to_mic(int4, int4, cstring, internal, int4)
  RETURNS void
AS
'246C69626469722F6575635F636E5F616E645F6D6963', 'euc_cn_to_mic'VOLATILE STRICT;
$$;

