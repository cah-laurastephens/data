CREATE FUNCTION currtid2()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.currtid2(text, tid)
  RETURNS tid
AS
$BODY$
currtid_byrelname
$BODY$
LANGUAGE internal VOLATILE STRICT;
$$;

