CREATE FUNCTION areasel()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.areasel(internal, oid, internal, int4)
  RETURNS float8
AS
$BODY$
areasel
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

