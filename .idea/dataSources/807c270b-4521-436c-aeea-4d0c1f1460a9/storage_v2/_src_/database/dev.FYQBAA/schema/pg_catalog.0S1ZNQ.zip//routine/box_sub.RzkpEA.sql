CREATE FUNCTION box_sub()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.box_sub(point[], float8[])
  RETURNS point[]
AS
$BODY$
box_sub
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

