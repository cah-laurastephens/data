CREATE FUNCTION byteacat()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.byteacat(bytea, bytea)
  RETURNS bytea
AS
$BODY$
byteacat
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

