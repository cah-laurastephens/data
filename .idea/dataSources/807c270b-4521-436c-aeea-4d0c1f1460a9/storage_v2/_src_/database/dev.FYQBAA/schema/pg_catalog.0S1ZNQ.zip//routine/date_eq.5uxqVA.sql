CREATE FUNCTION date_eq()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.date_eq(date, date)
  RETURNS bool
AS
$BODY$
date_eq
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

