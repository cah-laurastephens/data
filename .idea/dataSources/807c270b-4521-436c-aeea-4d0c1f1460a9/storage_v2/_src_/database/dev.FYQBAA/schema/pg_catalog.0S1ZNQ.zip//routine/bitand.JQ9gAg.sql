CREATE FUNCTION bitand()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.bitand(bit, bit)
  RETURNS bit
AS
$BODY$
bitand
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

