CREATE FUNCTION circle_right()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.circle_right(circle, circle)
  RETURNS bool
AS
$BODY$
circle_right
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

