CREATE FUNCTION bttext_pattern_cmp()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.bttext_pattern_cmp(text, text)
  RETURNS int4
AS
$BODY$
bttext_pattern_cmp
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

