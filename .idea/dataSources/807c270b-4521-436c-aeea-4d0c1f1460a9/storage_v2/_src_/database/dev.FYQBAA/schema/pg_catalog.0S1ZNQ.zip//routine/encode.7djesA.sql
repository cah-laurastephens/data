CREATE FUNCTION "encode"()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.encode(bytea, text)
  RETURNS text
AS
$BODY$
binary_encode
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

