CREATE FUNCTION array_to_string()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.array_to_string(anyarray, text)
  RETURNS text
AS
$BODY$
array_to_text
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

