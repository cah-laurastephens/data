CREATE VIEW applicable_roles AS
  SELECT ("current_user"())::information_schema.sql_identifier AS grantee, (g.groname)::information_schema.sql_identifier AS role_name, ('NO'::information_schema.character_data)::information_schema.character_data AS is_grantable FROM pg_group g, pg_user u WHERE ((u.usesysid = ANY (g.grolist)) AND (u.usename = ("current_user"())::name));

