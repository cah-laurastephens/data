CREATE VIEW pg_user_info AS
  SELECT pg_shadow.usename, pg_shadow.usesysid, pg_shadow.usecreatedb, pg_shadow.usesuper, pg_shadow.usecatupd, '********'::character varying AS passwd, pg_shadow.valuntil, pg_shadow.useconfig, CASE WHEN (pse_col1.value = ((- (1)::smallint))::text) THEN 'UNLIMITED'::text ELSE pse_col1.value END AS useconnlimit FROM (pg_shadow LEFT JOIN pg_shadow_extended pse_col1 ON (((pg_shadow.usesysid = pse_col1."sysid") AND (pse_col1.colnum = 1))));

