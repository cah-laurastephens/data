CREATE FUNCTION regexp_instr(text, text)
  RETURNS integer
  IMMUTABLE
  LANGUAGE SQL
AS $$
select regexp_instr($1, $2, 1)
$$;

