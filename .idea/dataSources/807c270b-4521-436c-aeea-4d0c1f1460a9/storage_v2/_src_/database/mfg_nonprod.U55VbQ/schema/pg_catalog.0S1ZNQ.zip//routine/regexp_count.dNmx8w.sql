CREATE FUNCTION regexp_count(text, text)
  RETURNS integer
  IMMUTABLE
  LANGUAGE SQL
AS $$
select regexp_count($1, $2, 1)
$$;

