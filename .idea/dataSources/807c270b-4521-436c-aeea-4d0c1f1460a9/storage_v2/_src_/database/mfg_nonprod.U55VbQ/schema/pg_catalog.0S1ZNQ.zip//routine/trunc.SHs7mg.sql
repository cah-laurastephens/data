CREATE FUNCTION trunc(numeric)
  RETURNS numeric
  IMMUTABLE
  LANGUAGE SQL
AS $$
select pg_catalog.trunc($1,0)
$$;

