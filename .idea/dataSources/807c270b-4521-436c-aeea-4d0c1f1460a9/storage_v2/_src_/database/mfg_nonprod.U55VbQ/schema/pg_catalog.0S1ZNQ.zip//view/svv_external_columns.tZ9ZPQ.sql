CREATE VIEW svv_external_columns AS
  SELECT btrim((stv_external_columns.schemaname)::text) AS schemaname, btrim((stv_external_columns.tablename)::text) AS tablename, btrim((stv_external_columns.columnname)::text) AS columnname, btrim((stv_external_columns.external_type)::text) AS external_type, stv_external_columns.columnnum, stv_external_columns.part_key FROM stv_external_columns ORDER BY btrim((stv_external_columns.schemaname)::text), btrim((stv_external_columns.tablename)::text), stv_external_columns.columnnum;

