CREATE FUNCTION interval_pl_date(interval, date)
  RETURNS timestamp without time zone
  IMMUTABLE
  LANGUAGE SQL
AS $$
select $2 + $1
$$;

