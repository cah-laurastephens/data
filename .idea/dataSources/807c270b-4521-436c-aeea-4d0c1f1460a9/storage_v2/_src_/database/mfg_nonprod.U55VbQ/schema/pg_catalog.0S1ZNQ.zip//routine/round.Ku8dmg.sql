CREATE FUNCTION round(numeric)
  RETURNS numeric
  IMMUTABLE
  LANGUAGE SQL
AS $$
select pg_catalog.round($1,0)
$$;

