CREATE VIEW svv_io_latency_read AS
  SELECT stv_io_latency_read.node, stv_io_latency_read."disk", min(stv_io_latency_read.minval) AS minval, (min(stv_io_latency_read.minval) + derived_table3.max_width) AS maxval, sum(stv_io_latency_read.samples) AS samples FROM (SELECT "max"((stv_io_latency_read.maxval - stv_io_latency_read.minval)) AS max_width FROM stv_io_latency_read) derived_table3, stv_io_latency_read GROUP BY stv_io_latency_read.node, stv_io_latency_read."disk", (stv_io_latency_read.minval / derived_table3.max_width), derived_table3.max_width;

