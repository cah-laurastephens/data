CREATE FUNCTION regexp_replace(text, text)
  RETURNS text
  IMMUTABLE
  LANGUAGE SQL
AS $$
select regexp_replace($1, $2, '')
$$;

