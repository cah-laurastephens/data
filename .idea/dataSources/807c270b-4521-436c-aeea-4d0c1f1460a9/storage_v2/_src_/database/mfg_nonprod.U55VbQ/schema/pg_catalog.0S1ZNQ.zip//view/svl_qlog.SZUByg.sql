CREATE VIEW svl_qlog AS
  SELECT sq.userid, sq.query, sq.xid, sq.pid, sq.starttime, sq.endtime, date_diff('microseconds'::text, sq.starttime, sq.endtime) AS elapsed, sq.aborted, sq."label", "substring"((sq.querytxt)::text, 1, 60) AS "substring", sr.source_query FROM (stl_query sq LEFT JOIN stl_result_cache_history sr ON ((sq.query = sr.cache_hit_query)));

