CREATE FUNCTION "_pg_keypositions"()
  RETURNS integer
  IMMUTABLE
  LANGUAGE SQL
AS $$
select g.s
        from generate_series(1,current_setting('max_index_keys')::int,1)
        as g(s)
$$;

