CREATE FUNCTION substring(bit, integer)
  RETURNS bit
  IMMUTABLE
  LANGUAGE SQL
AS $$
select pg_catalog.substring($1, $2, -1)
$$;

