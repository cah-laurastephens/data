CREATE VIEW svv_io_latency_sync AS
  SELECT stv_io_latency_sync.node, stv_io_latency_sync."disk", min(stv_io_latency_sync.minval) AS minval, (min(stv_io_latency_sync.minval) + derived_table4.max_width) AS maxval, sum(stv_io_latency_sync.samples) AS samples FROM (SELECT "max"((stv_io_latency_sync.maxval - stv_io_latency_sync.minval)) AS max_width FROM stv_io_latency_sync) derived_table4, stv_io_latency_sync GROUP BY stv_io_latency_sync.node, stv_io_latency_sync."disk", (stv_io_latency_sync.minval / derived_table4.max_width), derived_table4.max_width;

