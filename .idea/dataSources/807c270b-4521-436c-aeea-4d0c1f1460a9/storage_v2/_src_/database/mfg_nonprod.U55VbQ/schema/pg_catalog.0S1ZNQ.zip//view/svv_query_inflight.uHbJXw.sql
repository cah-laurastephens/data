CREATE VIEW svv_query_inflight AS
  SELECT b.userid, a.slice, a.query, a.pid, a.starttime, a.suspended, b.text, b."sequence" FROM stv_inflight a, stl_querytext b WHERE (a.query = b.query);

