CREATE VIEW enabled_roles AS
  SELECT (g.groname)::information_schema.sql_identifier AS role_name FROM pg_group g, pg_user u WHERE ((u.usesysid = ANY (g.grolist)) AND (u.usename = ("current_user"())::name));

