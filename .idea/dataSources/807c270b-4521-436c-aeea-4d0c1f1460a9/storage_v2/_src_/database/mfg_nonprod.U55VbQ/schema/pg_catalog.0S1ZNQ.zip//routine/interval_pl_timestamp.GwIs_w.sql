CREATE FUNCTION interval_pl_timestamp(interval, timestamp without time zone)
  RETURNS timestamp without time zone
  IMMUTABLE
  LANGUAGE SQL
AS $$
select $2 + $1
$$;

