CREATE FUNCTION interval_pl_timestamptz(interval, timestamp with time zone)
  RETURNS timestamp with time zone
  STABLE
  LANGUAGE SQL
AS $$
select $2 + $1
$$;

