CREATE VIEW svv_io_latency_write AS
  SELECT stv_io_latency_write.node, stv_io_latency_write."disk", min(stv_io_latency_write.minval) AS minval, (min(stv_io_latency_write.minval) + derived_table5.max_width) AS maxval, sum(stv_io_latency_write.samples) AS samples FROM (SELECT "max"((stv_io_latency_write.maxval - stv_io_latency_write.minval)) AS max_width FROM stv_io_latency_write) derived_table5, stv_io_latency_write GROUP BY stv_io_latency_write.node, stv_io_latency_write."disk", (stv_io_latency_write.minval / derived_table5.max_width), derived_table5.max_width;

