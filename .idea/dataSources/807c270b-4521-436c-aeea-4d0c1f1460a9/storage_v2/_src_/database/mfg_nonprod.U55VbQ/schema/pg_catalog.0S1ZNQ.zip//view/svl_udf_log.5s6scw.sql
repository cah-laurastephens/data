CREATE VIEW svl_udf_log AS
  SELECT stl_udf_log.query, stl_udf_log.message, stl_udf_log.created, stl_udf_log.traceback, stl_udf_log.funcname, stl_udf_log.node, stl_udf_log.slice, stl_udf_log.seq FROM stl_udf_log;

