CREATE FUNCTION int8_pl_timestamptz(bigint, timestamp with time zone)
  RETURNS timestamp with time zone
  IMMUTABLE
  LANGUAGE SQL
AS $$
select $2 + $1
$$;

