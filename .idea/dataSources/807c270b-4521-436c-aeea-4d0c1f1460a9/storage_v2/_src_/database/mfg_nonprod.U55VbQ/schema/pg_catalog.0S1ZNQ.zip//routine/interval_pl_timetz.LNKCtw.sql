CREATE FUNCTION interval_pl_timetz(interval, time with time zone)
  RETURNS time with time zone
  IMMUTABLE
  LANGUAGE SQL
AS $$
select $2 + $1
$$;

