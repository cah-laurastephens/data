CREATE FUNCTION timedate_pl(time without time zone, date)
  RETURNS timestamp without time zone
  IMMUTABLE
  LANGUAGE SQL
AS $$
select ($2 + $1)
$$;

