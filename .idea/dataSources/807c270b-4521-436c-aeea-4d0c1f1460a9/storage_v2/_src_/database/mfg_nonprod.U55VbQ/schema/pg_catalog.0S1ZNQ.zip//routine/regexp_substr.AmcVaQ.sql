CREATE FUNCTION regexp_substr(text, text)
  RETURNS text
  IMMUTABLE
  LANGUAGE SQL
AS $$
select regexp_substr($1, $2, 1)
$$;

