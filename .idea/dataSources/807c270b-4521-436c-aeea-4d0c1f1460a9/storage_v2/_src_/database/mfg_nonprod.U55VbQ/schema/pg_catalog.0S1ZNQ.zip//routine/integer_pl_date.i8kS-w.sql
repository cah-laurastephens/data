CREATE FUNCTION integer_pl_date(integer, date)
  RETURNS date
  IMMUTABLE
  LANGUAGE SQL
AS $$
select $2 + $1
$$;

