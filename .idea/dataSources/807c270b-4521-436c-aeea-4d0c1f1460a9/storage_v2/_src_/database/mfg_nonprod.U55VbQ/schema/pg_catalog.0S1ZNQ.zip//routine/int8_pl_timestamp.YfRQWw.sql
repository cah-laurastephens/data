CREATE FUNCTION int8_pl_timestamp(bigint, timestamp without time zone)
  RETURNS timestamp without time zone
  IMMUTABLE
  LANGUAGE SQL
AS $$
select $2 + $1
$$;

