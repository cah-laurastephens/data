CREATE VIEW svv_external_schemas AS
  SELECT b.esoid, b.eskind, a.nspname AS schemaname, a.nspowner AS esowner, b.esdbname AS databasename, b.esoptions FROM pg_namespace a, pg_external_schema b WHERE (a.oid = b.esoid);

