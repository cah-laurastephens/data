CREATE FUNCTION center()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.center(point[])
  RETURNS float8[]
AS
$BODY$
box_center
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.center(circle)
  RETURNS float8[]
AS
$BODY$
circle_center
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

