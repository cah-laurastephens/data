CREATE FUNCTION interval_avg()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.interval_avg(interval[])
  RETURNS interval
AS
$BODY$
interval_avg
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

