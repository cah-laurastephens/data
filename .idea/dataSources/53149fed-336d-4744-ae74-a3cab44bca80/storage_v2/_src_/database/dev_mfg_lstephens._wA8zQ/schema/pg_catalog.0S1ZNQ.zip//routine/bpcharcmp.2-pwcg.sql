CREATE FUNCTION bpcharcmp()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.bpcharcmp(bpchar, bpchar)
  RETURNS int4
AS
$BODY$
bpcharcmp
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

