CREATE FUNCTION int4xor()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.int4xor(int4, int4)
  RETURNS int4
AS
$BODY$
int4xor
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

