CREATE FUNCTION int4eq()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.int4eq(int4, int4)
  RETURNS bool
AS
$BODY$
int4eq
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

