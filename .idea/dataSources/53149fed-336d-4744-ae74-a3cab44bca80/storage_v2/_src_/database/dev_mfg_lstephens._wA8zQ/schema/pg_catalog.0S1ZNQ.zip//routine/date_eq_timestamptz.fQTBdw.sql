CREATE FUNCTION date_eq_timestamptz()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.date_eq_timestamptz(date, timestamptz)
  RETURNS bool
AS
$BODY$
date_eq_timestamptz
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

