CREATE FUNCTION int8eq()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.int8eq(int8, int8)
  RETURNS bool
AS
$BODY$
int8eq
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

