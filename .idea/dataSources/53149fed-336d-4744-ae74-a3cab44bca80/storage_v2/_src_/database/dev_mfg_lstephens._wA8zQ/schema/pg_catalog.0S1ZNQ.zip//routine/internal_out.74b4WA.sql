CREATE FUNCTION internal_out()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.internal_out(internal)
  RETURNS cstring
AS
$BODY$
internal_out
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

