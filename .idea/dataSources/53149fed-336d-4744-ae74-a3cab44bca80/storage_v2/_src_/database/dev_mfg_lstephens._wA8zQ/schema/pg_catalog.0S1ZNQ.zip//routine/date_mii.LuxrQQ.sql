CREATE FUNCTION date_mii()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.date_mii(date, int4)
  RETURNS date
AS
$BODY$
date_mii
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

