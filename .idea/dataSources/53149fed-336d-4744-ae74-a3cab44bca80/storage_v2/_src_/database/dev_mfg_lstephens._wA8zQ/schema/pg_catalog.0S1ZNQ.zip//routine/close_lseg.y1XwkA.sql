CREATE FUNCTION close_lseg()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.close_lseg(point[], point[])
  RETURNS float8[]
AS
$BODY$
close_lseg
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

