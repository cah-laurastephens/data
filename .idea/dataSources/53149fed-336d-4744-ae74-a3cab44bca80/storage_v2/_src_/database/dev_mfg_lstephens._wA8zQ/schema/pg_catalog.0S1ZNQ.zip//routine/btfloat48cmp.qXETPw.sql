CREATE FUNCTION btfloat48cmp()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.btfloat48cmp(float4, float8)
  RETURNS int4
AS
$BODY$
btfloat48cmp
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

