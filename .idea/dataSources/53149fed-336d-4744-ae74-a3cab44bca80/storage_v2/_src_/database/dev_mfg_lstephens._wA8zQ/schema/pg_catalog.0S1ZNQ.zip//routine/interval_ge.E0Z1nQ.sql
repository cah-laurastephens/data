CREATE FUNCTION interval_ge()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.interval_ge(interval, interval)
  RETURNS bool
AS
$BODY$
interval_ge
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

