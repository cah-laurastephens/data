CREATE FUNCTION interval_out()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.interval_out(interval)
  RETURNS cstring
AS
$BODY$
interval_out
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

