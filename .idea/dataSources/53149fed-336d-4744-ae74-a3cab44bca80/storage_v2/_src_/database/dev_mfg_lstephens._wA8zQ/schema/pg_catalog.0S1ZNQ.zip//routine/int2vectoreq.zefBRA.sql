CREATE FUNCTION int2vectoreq()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.int2vectoreq(int2[], int2[])
  RETURNS bool
AS
$BODY$
int2vectoreq
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

