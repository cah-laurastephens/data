CREATE FUNCTION cash_mul_flt8()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.cash_mul_flt8(money, float8)
  RETURNS money
AS
$BODY$
cash_mul_flt8
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

