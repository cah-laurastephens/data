CREATE FUNCTION byteain()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.byteain(cstring)
  RETURNS bytea
AS
$BODY$
byteain
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

