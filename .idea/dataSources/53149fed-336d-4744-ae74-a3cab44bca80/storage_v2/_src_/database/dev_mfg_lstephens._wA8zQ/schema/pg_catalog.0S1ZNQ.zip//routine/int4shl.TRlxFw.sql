CREATE FUNCTION int4shl()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.int4shl(int4, int4)
  RETURNS int4
AS
$BODY$
int4shl
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

