CREATE FUNCTION interval_recv()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.interval_recv(internal)
  RETURNS interval
AS
$BODY$
interval_recv
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

