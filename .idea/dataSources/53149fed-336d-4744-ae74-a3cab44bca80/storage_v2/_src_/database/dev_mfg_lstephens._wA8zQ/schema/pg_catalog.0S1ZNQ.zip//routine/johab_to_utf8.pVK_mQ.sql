CREATE FUNCTION johab_to_utf8()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.johab_to_utf8(int4, int4, cstring, internal, int4)
  RETURNS void
AS
'246C69626469722F757466385F616E645F6A6F686162', 'johab_to_utf8'VOLATILE STRICT;
$$;

