CREATE FUNCTION circle_contain_pt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.circle_contain_pt(circle, float8[])
  RETURNS bool
AS
$BODY$
circle_contain_pt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

