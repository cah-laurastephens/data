CREATE FUNCTION int8_avg_accum()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.int8_avg_accum(int8[], int8)
  RETURNS int8[]
AS
$BODY$
int8_avg_accum
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

