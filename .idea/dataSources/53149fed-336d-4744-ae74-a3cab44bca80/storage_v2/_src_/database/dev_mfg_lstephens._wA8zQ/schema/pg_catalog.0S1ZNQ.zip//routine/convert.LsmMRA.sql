CREATE FUNCTION convert()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.convert(text, char[])
  RETURNS text
AS
$BODY$
pg_convert
$BODY$
LANGUAGE internal STABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.convert(text, char[], char[])
  RETURNS text
AS
$BODY$
pg_convert2
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

