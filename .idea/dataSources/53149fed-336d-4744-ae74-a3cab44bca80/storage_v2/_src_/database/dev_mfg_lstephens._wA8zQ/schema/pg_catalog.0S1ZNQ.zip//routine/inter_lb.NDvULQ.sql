CREATE FUNCTION inter_lb()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.inter_lb(float8[], point[])
  RETURNS bool
AS
$BODY$
inter_lb
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

