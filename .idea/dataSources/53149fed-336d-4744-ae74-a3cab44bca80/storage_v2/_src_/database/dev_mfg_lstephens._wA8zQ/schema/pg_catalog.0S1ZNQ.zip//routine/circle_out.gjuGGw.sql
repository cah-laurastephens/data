CREATE FUNCTION circle_out()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.circle_out(circle)
  RETURNS cstring
AS
$BODY$
circle_out
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

