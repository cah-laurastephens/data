CREATE FUNCTION character_length()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.character_length(text)
  RETURNS int4
AS
$BODY$
textlen
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.character_length(bpchar)
  RETURNS int4
AS
$BODY$
bpcharlen
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

