CREATE FUNCTION circle_eq()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.circle_eq(circle, circle)
  RETURNS bool
AS
$BODY$
circle_eq
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

