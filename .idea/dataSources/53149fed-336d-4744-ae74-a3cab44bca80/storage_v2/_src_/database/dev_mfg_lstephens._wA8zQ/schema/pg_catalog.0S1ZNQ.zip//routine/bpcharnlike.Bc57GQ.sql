CREATE FUNCTION bpcharnlike()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.bpcharnlike(bpchar, text)
  RETURNS bool
AS
$BODY$
textnlike
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

