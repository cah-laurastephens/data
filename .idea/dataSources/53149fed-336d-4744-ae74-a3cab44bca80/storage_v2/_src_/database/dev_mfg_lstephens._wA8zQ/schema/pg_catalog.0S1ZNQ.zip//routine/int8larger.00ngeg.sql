CREATE FUNCTION int8larger()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.int8larger(int8, int8)
  RETURNS int8
AS
$BODY$
int8larger
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

