CREATE FUNCTION btint4cmp()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.btint4cmp(int4, int4)
  RETURNS int4
AS
$BODY$
btint4cmp
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

