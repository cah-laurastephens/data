CREATE FUNCTION int4_accum()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.int4_accum(numeric[], int4)
  RETURNS numeric[]
AS
$BODY$
int4_accum
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

