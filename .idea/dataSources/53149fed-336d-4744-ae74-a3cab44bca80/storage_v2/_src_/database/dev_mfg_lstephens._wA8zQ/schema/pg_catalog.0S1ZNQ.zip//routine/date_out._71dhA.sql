CREATE FUNCTION date_out()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.date_out(date)
  RETURNS cstring
AS
$BODY$
date_out
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

