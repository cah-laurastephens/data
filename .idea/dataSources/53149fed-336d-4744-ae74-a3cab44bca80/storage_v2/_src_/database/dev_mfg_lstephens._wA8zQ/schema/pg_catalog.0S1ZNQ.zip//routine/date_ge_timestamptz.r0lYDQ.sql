CREATE FUNCTION date_ge_timestamptz()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.date_ge_timestamptz(date, timestamptz)
  RETURNS bool
AS
$BODY$
date_ge_timestamptz
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

