CREATE FUNCTION int8mul()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.int8mul(int8, int8)
  RETURNS int8
AS
$BODY$
int8mul
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

