CREATE FUNCTION int4send()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.int4send(int4)
  RETURNS bytea
AS
$BODY$
int4send
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

