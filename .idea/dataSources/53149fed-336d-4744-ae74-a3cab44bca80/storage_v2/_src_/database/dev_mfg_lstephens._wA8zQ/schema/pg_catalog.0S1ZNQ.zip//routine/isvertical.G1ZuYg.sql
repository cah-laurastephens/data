CREATE FUNCTION isvertical()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.isvertical(point[])
  RETURNS bool
AS
$BODY$
lseg_vertical
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.isvertical(float8[])
  RETURNS bool
AS
$BODY$
line_vertical
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.isvertical(float8[], float8[])
  RETURNS bool
AS
$BODY$
point_vert
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

