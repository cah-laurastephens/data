CREATE FUNCTION cidsend()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.cidsend(cid)
  RETURNS bytea
AS
$BODY$
cidsend
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

