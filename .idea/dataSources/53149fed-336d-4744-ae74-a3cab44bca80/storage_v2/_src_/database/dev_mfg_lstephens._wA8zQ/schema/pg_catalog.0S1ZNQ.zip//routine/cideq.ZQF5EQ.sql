CREATE FUNCTION cideq()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.cideq(cid, cid)
  RETURNS bool
AS
$BODY$
cideq
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

