CREATE FUNCTION interval_in()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.interval_in(cstring, oid, int4)
  RETURNS interval
AS
$BODY$
interval_in
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

