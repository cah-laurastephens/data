CREATE FUNCTION interval_le()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.interval_le(interval, interval)
  RETURNS bool
AS
$BODY$
interval_le
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

