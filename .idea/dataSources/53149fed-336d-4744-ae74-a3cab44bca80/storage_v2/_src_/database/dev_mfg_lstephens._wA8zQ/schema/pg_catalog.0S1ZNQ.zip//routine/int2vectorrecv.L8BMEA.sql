CREATE FUNCTION int2vectorrecv()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.int2vectorrecv(internal)
  RETURNS int2[]
AS
$BODY$
int2vectorrecv
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

