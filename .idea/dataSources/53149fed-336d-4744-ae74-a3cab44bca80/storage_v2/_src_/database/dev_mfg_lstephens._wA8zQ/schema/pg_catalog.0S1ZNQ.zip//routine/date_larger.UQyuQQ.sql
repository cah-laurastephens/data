CREATE FUNCTION date_larger()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.date_larger(date, date)
  RETURNS date
AS
$BODY$
date_larger
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

