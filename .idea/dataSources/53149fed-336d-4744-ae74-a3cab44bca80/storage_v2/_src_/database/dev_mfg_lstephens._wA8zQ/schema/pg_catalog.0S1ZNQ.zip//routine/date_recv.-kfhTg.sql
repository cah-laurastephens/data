CREATE FUNCTION date_recv()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.date_recv(internal)
  RETURNS date
AS
$BODY$
date_recv
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

