CREATE FUNCTION interval_smaller()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.interval_smaller(interval, interval)
  RETURNS interval
AS
$BODY$
interval_smaller
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

