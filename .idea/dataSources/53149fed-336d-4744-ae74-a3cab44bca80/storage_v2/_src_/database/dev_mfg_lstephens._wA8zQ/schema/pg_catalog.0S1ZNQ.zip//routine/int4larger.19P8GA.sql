CREATE FUNCTION int4larger()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.int4larger(int4, int4)
  RETURNS int4
AS
$BODY$
int4larger
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

