CREATE FUNCTION ishorizontal()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.ishorizontal(point[])
  RETURNS bool
AS
$BODY$
lseg_horizontal
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.ishorizontal(float8[])
  RETURNS bool
AS
$BODY$
line_horizontal
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.ishorizontal(float8[], float8[])
  RETURNS bool
AS
$BODY$
point_horiz
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

