CREATE FUNCTION interval_mul()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.interval_mul(interval, float8)
  RETURNS interval
AS
$BODY$
interval_mul
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

