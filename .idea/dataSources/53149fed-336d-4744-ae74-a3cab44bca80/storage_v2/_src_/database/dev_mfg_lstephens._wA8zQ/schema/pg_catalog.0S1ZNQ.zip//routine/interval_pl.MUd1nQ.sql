CREATE FUNCTION interval_pl()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.interval_pl(interval, interval)
  RETURNS interval
AS
$BODY$
interval_pl
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

