CREATE FUNCTION circle_lt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.circle_lt(circle, circle)
  RETURNS bool
AS
$BODY$
circle_lt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

