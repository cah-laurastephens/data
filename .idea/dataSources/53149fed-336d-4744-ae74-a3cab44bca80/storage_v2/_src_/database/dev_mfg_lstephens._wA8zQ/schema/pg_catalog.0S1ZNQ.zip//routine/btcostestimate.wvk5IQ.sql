CREATE FUNCTION btcostestimate()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.btcostestimate(internal, internal, internal, internal, internal, internal, internal, internal)
  RETURNS void
AS
$BODY$
btcostestimate
$BODY$
LANGUAGE internal VOLATILE STRICT;
$$;

