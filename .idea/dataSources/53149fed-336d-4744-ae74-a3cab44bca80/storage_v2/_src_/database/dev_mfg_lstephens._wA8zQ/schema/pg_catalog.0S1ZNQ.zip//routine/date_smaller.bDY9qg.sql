CREATE FUNCTION date_smaller()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.date_smaller(date, date)
  RETURNS date
AS
$BODY$
date_smaller
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

