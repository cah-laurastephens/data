CREATE FUNCTION interval()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.interval(text)
  RETURNS interval
AS
$BODY$
text_interval
$BODY$
LANGUAGE internal STABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.interval(reltime)
  RETURNS interval
AS
$BODY$
reltime_interval
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.interval(time)
  RETURNS interval
AS
$BODY$
time_interval
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.interval(interval, int4)
  RETURNS interval
AS
$BODY$
interval_scale
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

