CREATE FUNCTION convert_timezone()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.convert_timezone(text, timestamp)
  RETURNS timestamp
AS
$BODY$
convert_utc
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.convert_timezone(text, text, timestamp)
  RETURNS timestamp
AS
$BODY$
convert_timezone
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

