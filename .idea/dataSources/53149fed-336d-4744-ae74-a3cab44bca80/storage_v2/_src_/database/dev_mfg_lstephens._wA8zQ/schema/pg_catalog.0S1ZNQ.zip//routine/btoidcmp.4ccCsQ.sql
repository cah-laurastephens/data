CREATE FUNCTION btoidcmp()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.btoidcmp(oid, oid)
  RETURNS int4
AS
$BODY$
btoidcmp
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

