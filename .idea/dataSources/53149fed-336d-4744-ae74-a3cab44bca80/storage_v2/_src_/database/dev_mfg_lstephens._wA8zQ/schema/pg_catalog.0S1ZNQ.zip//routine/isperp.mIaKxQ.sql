CREATE FUNCTION isperp()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.isperp(point[], point[])
  RETURNS bool
AS
$BODY$
lseg_perp
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.isperp(float8[], float8[])
  RETURNS bool
AS
$BODY$
line_perp
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

