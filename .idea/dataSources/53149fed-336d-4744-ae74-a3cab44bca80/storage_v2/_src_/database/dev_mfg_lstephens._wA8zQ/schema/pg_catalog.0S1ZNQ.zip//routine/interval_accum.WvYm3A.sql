CREATE FUNCTION interval_accum()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.interval_accum(interval[], interval)
  RETURNS interval[]
AS
$BODY$
interval_accum
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

