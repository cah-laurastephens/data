CREATE FUNCTION int8out()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.int8out(int8)
  RETURNS cstring
AS
$BODY$
int8out
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

