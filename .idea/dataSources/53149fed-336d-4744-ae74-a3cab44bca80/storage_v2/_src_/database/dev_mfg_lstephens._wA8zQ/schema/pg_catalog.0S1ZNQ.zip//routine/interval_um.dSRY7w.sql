CREATE FUNCTION interval_um()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.interval_um(interval)
  RETURNS interval
AS
$BODY$
interval_um
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

