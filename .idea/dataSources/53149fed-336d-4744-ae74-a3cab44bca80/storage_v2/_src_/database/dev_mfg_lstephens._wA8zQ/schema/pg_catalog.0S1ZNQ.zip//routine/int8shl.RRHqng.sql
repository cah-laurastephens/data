CREATE FUNCTION int8shl()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.int8shl(int8, int4)
  RETURNS int8
AS
$BODY$
int8shl
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

