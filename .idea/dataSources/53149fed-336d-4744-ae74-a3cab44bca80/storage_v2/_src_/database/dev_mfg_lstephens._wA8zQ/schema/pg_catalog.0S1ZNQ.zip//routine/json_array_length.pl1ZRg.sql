CREATE FUNCTION json_array_length()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.json_array_length(text)
  RETURNS int4
AS
$BODY$
json_array_length
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.json_array_length(text, bool)
  RETURNS int4
AS
$BODY$
json_array_length_tolerate_invalid
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

