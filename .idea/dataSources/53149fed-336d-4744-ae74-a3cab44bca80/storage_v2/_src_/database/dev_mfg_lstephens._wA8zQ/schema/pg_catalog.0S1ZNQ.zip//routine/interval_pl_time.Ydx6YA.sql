CREATE FUNCTION interval_pl_time()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.interval_pl_time(interval, time)
  RETURNS time
AS
$BODY$
select $2 + $1
$BODY$
LANGUAGE sql IMMUTABLE STRICT;
$$;

