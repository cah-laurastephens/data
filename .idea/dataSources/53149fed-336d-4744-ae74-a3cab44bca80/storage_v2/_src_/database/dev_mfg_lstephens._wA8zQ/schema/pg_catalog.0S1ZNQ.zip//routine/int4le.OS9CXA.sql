CREATE FUNCTION int4le()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.int4le(int4, int4)
  RETURNS bool
AS
$BODY$
int4le
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

