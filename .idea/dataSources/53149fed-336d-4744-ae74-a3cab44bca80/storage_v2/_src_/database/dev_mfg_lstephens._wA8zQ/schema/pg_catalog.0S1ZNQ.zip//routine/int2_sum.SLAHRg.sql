CREATE FUNCTION int2_sum()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.int2_sum(int8, int2)
  RETURNS int8
AS
$BODY$
int2_sum
$BODY$
LANGUAGE internal IMMUTABLE;
$$;

