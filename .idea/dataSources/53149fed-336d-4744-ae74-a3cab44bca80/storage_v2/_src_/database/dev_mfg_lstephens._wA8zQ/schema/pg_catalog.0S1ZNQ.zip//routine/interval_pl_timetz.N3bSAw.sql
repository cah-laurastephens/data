CREATE FUNCTION interval_pl_timetz()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.interval_pl_timetz(interval, timetz)
  RETURNS timetz
AS
$BODY$
select $2 + $1
$BODY$
LANGUAGE sql IMMUTABLE STRICT;
$$;

