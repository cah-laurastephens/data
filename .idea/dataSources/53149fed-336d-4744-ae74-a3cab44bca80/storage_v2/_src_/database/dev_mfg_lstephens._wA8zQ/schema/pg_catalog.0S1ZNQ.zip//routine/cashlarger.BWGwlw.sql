CREATE FUNCTION cashlarger()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.cashlarger(money, money)
  RETURNS money
AS
$BODY$
cashlarger
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

