CREATE FUNCTION lag()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.lag(int8)
  RETURNS int8
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.lag(int4)
  RETURNS int4
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.lag(int2)
  RETURNS int2
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.lag(float4)
  RETURNS float4
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.lag(float8)
  RETURNS float8
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.lag(timestamp)
  RETURNS timestamp
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.lag(timestamptz)
  RETURNS timestamptz
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.lag(interval)
  RETURNS interval
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.lag(numeric)
  RETURNS numeric
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.lag(date)
  RETURNS date
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.lag(text)
  RETURNS text
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.lag(bool)
  RETURNS bool
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.lag(int8, int4)
  RETURNS int8
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.lag(int4, int4)
  RETURNS int4
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.lag(int2, int4)
  RETURNS int2
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.lag(float4, int4)
  RETURNS float4
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.lag(float8, int4)
  RETURNS float8
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.lag(timestamp, int4)
  RETURNS timestamp
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.lag(timestamptz, int4)
  RETURNS timestamptz
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.lag(interval, int4)
  RETURNS interval
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.lag(numeric, int4)
  RETURNS numeric
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.lag(date, int4)
  RETURNS date
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.lag(text, int4)
  RETURNS text
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.lag(bool, int4)
  RETURNS bool
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.lag(int8, int4, int8)
  RETURNS int8
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.lag(int4, int4, int4)
  RETURNS int4
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.lag(int2, int4, int2)
  RETURNS int2
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.lag(float4, int4, float4)
  RETURNS float4
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.lag(float8, int4, float8)
  RETURNS float8
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.lag(timestamp, int4, timestamp)
  RETURNS timestamp
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.lag(timestamptz, int4, timestamp)
  RETURNS timestamptz
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.lag(interval, int4, interval)
  RETURNS interval
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.lag(numeric, int4, numeric)
  RETURNS numeric
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.lag(date, int4, date)
  RETURNS date
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.lag(text, int4, text)
  RETURNS text
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.lag(bool, int4, bool)
  RETURNS bool
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
$$;

