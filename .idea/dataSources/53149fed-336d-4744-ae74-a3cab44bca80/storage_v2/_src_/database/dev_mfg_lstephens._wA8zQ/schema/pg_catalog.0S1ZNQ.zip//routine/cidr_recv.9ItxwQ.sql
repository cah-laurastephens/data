CREATE FUNCTION cidr_recv()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.cidr_recv(internal)
  RETURNS cidr
AS
$BODY$
cidr_recv
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

