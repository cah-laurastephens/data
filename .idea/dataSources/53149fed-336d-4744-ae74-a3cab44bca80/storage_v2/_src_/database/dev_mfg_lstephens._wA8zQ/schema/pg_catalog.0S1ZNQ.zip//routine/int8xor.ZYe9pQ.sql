CREATE FUNCTION int8xor()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.int8xor(int8, int8)
  RETURNS int8
AS
$BODY$
int8xor
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

