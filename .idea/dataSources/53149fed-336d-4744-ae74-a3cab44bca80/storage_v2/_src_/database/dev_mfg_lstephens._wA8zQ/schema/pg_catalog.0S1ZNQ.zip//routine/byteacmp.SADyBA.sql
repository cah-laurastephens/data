CREATE FUNCTION byteacmp()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.byteacmp(bytea, bytea)
  RETURNS int4
AS
$BODY$
byteacmp
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

