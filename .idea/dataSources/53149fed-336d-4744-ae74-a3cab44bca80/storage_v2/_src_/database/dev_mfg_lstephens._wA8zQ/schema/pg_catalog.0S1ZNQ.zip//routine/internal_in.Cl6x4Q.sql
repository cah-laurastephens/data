CREATE FUNCTION internal_in()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.internal_in(cstring)
  RETURNS internal
AS
$BODY$
internal_in
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

