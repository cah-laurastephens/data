CREATE FUNCTION interval_larger()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.interval_larger(interval, interval)
  RETURNS interval
AS
$BODY$
interval_larger
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

