CREATE FUNCTION isclosed()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.isclosed(path)
  RETURNS bool
AS
$BODY$
path_isclosed
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

