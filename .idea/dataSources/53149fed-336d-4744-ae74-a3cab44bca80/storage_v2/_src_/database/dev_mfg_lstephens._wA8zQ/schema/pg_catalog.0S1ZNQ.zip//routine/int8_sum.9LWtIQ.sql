CREATE FUNCTION int8_sum()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.int8_sum(numeric, int8)
  RETURNS numeric
AS
$BODY$
int8_sum
$BODY$
LANGUAGE internal IMMUTABLE;
$$;

