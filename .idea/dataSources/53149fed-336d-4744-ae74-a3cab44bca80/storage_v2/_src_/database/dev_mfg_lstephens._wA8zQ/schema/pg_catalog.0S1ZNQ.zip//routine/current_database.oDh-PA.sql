CREATE FUNCTION current_database()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.current_database()
  RETURNS char[]
AS
$BODY$
current_database
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

