CREATE FUNCTION interval_gt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.interval_gt(interval, interval)
  RETURNS bool
AS
$BODY$
interval_gt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

