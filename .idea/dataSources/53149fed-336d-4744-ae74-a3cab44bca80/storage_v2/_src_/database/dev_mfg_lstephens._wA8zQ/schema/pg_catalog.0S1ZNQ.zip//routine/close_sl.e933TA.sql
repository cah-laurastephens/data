CREATE FUNCTION close_sl()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.close_sl(point[], float8[])
  RETURNS float8[]
AS
$BODY$
close_sl
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

