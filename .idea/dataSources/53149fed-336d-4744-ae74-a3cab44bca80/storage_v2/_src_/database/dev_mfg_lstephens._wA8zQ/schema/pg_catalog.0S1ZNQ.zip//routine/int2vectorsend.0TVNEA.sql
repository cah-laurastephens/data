CREATE FUNCTION int2vectorsend()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.int2vectorsend(int2[])
  RETURNS bytea
AS
$BODY$
int2vectorsend
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

