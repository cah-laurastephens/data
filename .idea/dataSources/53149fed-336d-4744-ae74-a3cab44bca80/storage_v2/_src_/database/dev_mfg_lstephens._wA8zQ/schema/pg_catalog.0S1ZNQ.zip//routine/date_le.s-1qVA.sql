CREATE FUNCTION date_le()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.date_le(date, date)
  RETURNS bool
AS
$BODY$
date_le
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

