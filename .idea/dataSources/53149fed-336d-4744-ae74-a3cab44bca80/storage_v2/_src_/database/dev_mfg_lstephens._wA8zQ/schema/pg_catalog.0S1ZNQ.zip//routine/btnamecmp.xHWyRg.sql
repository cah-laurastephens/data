CREATE FUNCTION btnamecmp()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.btnamecmp(char[], char[])
  RETURNS int4
AS
$BODY$
btnamecmp
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

