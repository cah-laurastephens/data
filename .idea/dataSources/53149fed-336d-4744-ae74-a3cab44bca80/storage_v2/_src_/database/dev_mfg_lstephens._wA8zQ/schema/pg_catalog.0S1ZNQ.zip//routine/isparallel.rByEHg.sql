CREATE FUNCTION isparallel()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.isparallel(point[], point[])
  RETURNS bool
AS
$BODY$
lseg_parallel
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.isparallel(float8[], float8[])
  RETURNS bool
AS
$BODY$
line_parallel
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

