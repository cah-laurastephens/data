CREATE FUNCTION circle_div_pt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.circle_div_pt(circle, float8[])
  RETURNS circle
AS
$BODY$
circle_div_pt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

