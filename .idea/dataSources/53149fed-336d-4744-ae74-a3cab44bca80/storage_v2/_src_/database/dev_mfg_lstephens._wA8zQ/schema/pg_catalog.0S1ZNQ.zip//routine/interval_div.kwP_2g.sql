CREATE FUNCTION interval_div()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.interval_div(interval, float8)
  RETURNS interval
AS
$BODY$
interval_div
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

