CREATE FUNCTION isfinite()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.isfinite(abstime)
  RETURNS bool
AS
$BODY$
abstime_finite
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.isfinite(timestamp)
  RETURNS bool
AS
$BODY$
timestamp_finite
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.isfinite(timestamptz)
  RETURNS bool
AS
$BODY$
timestamp_finite
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.isfinite(interval)
  RETURNS bool
AS
$BODY$
interval_finite
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

