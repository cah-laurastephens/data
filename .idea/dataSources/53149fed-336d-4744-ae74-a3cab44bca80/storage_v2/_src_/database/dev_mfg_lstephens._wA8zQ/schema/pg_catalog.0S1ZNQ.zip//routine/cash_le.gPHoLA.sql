CREATE FUNCTION cash_le()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.cash_le(money, money)
  RETURNS bool
AS
$BODY$
cash_le
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

