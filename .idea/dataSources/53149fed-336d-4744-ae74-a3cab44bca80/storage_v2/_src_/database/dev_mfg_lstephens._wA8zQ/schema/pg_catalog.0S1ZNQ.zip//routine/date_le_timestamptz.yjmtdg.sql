CREATE FUNCTION date_le_timestamptz()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.date_le_timestamptz(date, timestamptz)
  RETURNS bool
AS
$BODY$
date_le_timestamptz
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

