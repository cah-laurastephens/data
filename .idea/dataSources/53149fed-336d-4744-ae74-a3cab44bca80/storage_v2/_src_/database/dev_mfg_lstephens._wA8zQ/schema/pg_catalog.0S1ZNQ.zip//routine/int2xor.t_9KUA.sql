CREATE FUNCTION int2xor()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.int2xor(int2, int2)
  RETURNS int2
AS
$BODY$
int2xor
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

