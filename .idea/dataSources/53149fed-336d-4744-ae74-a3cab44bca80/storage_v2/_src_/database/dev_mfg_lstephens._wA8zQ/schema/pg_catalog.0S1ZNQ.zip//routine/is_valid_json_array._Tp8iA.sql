CREATE FUNCTION is_valid_json_array()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.is_valid_json_array(text)
  RETURNS bool
AS
$BODY$
is_valid_json_array
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

