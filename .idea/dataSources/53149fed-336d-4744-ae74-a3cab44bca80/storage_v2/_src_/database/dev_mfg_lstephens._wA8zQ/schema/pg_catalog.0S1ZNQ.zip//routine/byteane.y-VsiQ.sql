CREATE FUNCTION byteane()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.byteane(bytea, bytea)
  RETURNS bool
AS
$BODY$
byteane
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

