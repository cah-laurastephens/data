CREATE FUNCTION int8le()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.int8le(int8, int8)
  RETURNS bool
AS
$BODY$
int8le
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

