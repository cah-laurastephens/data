CREATE FUNCTION btmarkpos()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.btmarkpos(internal)
  RETURNS void
AS
$BODY$
btmarkpos
$BODY$
LANGUAGE internal VOLATILE STRICT;
$$;

