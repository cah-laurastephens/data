CREATE FUNCTION interval_mi()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.interval_mi(interval, interval)
  RETURNS interval
AS
$BODY$
interval_mi
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

