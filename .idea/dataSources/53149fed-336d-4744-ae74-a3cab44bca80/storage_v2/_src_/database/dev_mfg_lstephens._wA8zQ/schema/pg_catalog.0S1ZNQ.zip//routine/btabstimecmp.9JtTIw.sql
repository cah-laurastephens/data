CREATE FUNCTION btabstimecmp()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.btabstimecmp(abstime, abstime)
  RETURNS int4
AS
$BODY$
btabstimecmp
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

