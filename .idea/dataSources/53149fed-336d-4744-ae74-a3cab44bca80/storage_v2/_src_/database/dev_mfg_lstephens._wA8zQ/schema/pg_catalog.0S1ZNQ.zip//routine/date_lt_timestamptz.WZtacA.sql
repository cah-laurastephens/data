CREATE FUNCTION date_lt_timestamptz()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.date_lt_timestamptz(date, timestamptz)
  RETURNS bool
AS
$BODY$
date_lt_timestamptz
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

