CREATE FUNCTION int4recv()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.int4recv(internal)
  RETURNS int4
AS
$BODY$
int4recv
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

