CREATE FUNCTION bpcharsend()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.bpcharsend(bpchar)
  RETURNS bytea
AS
$BODY$
bpcharsend
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

