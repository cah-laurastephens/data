CREATE FUNCTION checksum()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.checksum(int4)
  RETURNS int4
AS
$BODY$
checksum_int4
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.checksum(varchar)
  RETURNS int4
AS
$BODY$
checksum_varchar
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.checksum(numeric)
  RETURNS int4
AS
$BODY$
checksum_numeric
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

