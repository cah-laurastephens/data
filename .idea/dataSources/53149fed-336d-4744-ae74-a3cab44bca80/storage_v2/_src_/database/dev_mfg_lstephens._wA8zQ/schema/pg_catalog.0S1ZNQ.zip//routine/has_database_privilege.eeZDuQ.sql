CREATE FUNCTION has_database_privilege()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.has_database_privilege(text, text)
  RETURNS bool
AS
$BODY$
has_database_privilege_name
$BODY$
LANGUAGE internal STABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.has_database_privilege(oid, text)
  RETURNS bool
AS
$BODY$
has_database_privilege_id
$BODY$
LANGUAGE internal STABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.has_database_privilege(char[], text, text)
  RETURNS bool
AS
$BODY$
has_database_privilege_name_name
$BODY$
LANGUAGE internal STABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.has_database_privilege(char[], oid, text)
  RETURNS bool
AS
$BODY$
has_database_privilege_name_id
$BODY$
LANGUAGE internal STABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.has_database_privilege(int4, text, text)
  RETURNS bool
AS
$BODY$
has_database_privilege_id_name
$BODY$
LANGUAGE internal STABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.has_database_privilege(int4, oid, text)
  RETURNS bool
AS
$BODY$
has_database_privilege_id_id
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

