CREATE FUNCTION isnottrue()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.isnottrue(bool)
  RETURNS bool
AS
$BODY$
isnottrue
$BODY$
LANGUAGE internal IMMUTABLE;
$$;

