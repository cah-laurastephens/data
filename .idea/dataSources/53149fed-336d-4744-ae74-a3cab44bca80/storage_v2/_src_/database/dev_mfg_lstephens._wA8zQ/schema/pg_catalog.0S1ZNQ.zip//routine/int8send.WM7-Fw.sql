CREATE FUNCTION int8send()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.int8send(int8)
  RETURNS bytea
AS
$BODY$
int8send
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

