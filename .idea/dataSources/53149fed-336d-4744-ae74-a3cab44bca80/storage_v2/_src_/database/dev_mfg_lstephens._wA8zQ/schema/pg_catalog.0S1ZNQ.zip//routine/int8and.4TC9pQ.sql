CREATE FUNCTION int8and()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.int8and(int8, int8)
  RETURNS int8
AS
$BODY$
int8and
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

