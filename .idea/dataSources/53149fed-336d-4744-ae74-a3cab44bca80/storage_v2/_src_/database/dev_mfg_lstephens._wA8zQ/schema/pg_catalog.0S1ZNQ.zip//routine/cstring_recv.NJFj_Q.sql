CREATE FUNCTION cstring_recv()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.cstring_recv(internal)
  RETURNS cstring
AS
$BODY$
cstring_recv
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

