CREATE FUNCTION date_gt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.date_gt(date, date)
  RETURNS bool
AS
$BODY$
date_gt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

