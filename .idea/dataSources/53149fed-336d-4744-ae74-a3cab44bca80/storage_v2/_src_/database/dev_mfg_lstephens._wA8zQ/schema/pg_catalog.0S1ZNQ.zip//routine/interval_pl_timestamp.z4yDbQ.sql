CREATE FUNCTION interval_pl_timestamp()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.interval_pl_timestamp(interval, timestamp)
  RETURNS timestamp
AS
$BODY$
select $2 + $1
$BODY$
LANGUAGE sql IMMUTABLE STRICT;
$$;

