CREATE FUNCTION int8ge()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.int8ge(int8, int8)
  RETURNS bool
AS
$BODY$
int8ge
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

