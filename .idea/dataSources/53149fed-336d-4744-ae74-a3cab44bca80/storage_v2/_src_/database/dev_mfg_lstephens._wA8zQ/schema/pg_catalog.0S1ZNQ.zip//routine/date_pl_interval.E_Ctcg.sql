CREATE FUNCTION date_pl_interval()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.date_pl_interval(date, interval)
  RETURNS timestamp
AS
$BODY$
date_pl_interval
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

