CREATE FUNCTION inter_sl()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.inter_sl(point[], float8[])
  RETURNS bool
AS
$BODY$
inter_sl
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

