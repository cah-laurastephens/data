CREATE FUNCTION int4mod()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.int4mod(int4, int4)
  RETURNS int4
AS
$BODY$
int4mod
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

