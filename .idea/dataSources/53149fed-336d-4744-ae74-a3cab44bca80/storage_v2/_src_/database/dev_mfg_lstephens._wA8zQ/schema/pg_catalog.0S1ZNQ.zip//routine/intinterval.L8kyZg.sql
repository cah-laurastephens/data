CREATE FUNCTION intinterval()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.intinterval(abstime, tinterval)
  RETURNS bool
AS
$BODY$
intinterval
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

