CREATE FUNCTION cash_pl()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.cash_pl(money, money)
  RETURNS money
AS
$BODY$
cash_pl
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

