CREATE FUNCTION int8div()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.int8div(int8, int8)
  RETURNS int8
AS
$BODY$
int8div
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

