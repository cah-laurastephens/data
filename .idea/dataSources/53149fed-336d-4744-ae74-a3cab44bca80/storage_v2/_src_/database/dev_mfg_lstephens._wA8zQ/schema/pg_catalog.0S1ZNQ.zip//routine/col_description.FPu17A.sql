CREATE FUNCTION col_description()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.col_description(oid, int4)
  RETURNS text
AS
$BODY$
select description from pg_catalog.pg_description where objoid = $1 and classoid = 'pg_catalog.pg_class'::regclass and objsubid = $2
$BODY$
LANGUAGE sql STABLE STRICT;
$$;

