CREATE FUNCTION bpchariclike()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.bpchariclike(bpchar, text)
  RETURNS bool
AS
$BODY$
texticlike
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

