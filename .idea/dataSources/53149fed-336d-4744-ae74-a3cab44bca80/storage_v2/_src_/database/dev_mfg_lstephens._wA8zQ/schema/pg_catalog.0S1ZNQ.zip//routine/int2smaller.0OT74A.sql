CREATE FUNCTION int2smaller()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.int2smaller(int2, int2)
  RETURNS int2
AS
$BODY$
int2smaller
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

