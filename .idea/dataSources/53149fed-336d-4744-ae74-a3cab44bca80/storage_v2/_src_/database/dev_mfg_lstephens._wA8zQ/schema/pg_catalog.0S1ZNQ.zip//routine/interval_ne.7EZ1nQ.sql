CREATE FUNCTION interval_ne()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.interval_ne(interval, interval)
  RETURNS bool
AS
$BODY$
interval_ne
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

