CREATE FUNCTION int8mod()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.int8mod(int8, int8)
  RETURNS int8
AS
$BODY$
int8mod
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

