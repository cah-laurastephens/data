CREATE FUNCTION int2vectorout()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.int2vectorout(int2[])
  RETURNS cstring
AS
$BODY$
int2vectorout
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

