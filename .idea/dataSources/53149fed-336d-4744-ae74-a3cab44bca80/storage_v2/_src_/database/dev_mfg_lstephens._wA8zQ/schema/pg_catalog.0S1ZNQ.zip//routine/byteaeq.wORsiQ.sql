CREATE FUNCTION byteaeq()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.byteaeq(bytea, bytea)
  RETURNS bool
AS
$BODY$
byteaeq
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

