CREATE FUNCTION interval_hash()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.interval_hash(interval)
  RETURNS int4
AS
$BODY$
interval_hash
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

