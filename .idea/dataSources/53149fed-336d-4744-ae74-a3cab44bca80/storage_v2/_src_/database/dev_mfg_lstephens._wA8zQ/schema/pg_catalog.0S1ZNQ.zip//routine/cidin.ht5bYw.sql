CREATE FUNCTION cidin()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.cidin(cstring)
  RETURNS cid
AS
$BODY$
cidin
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

