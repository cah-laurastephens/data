CREATE FUNCTION bpchargt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.bpchargt(bpchar, bpchar)
  RETURNS bool
AS
$BODY$
bpchargt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

