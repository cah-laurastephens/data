CREATE FUNCTION int8ne()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.int8ne(int8, int8)
  RETURNS bool
AS
$BODY$
int8ne
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

