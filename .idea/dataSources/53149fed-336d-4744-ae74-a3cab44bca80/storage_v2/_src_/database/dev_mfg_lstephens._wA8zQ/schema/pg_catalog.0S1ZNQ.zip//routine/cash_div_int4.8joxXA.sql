CREATE FUNCTION cash_div_int4()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.cash_div_int4(money, int4)
  RETURNS money
AS
$BODY$
cash_div_int4
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

