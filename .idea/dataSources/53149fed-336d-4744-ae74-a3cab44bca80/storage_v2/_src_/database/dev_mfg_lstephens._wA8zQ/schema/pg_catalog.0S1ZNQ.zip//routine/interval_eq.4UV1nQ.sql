CREATE FUNCTION interval_eq()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.interval_eq(interval, interval)
  RETURNS bool
AS
$BODY$
interval_eq
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

