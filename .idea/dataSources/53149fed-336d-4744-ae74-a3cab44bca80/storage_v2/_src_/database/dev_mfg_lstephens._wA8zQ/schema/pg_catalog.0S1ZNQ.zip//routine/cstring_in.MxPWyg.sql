CREATE FUNCTION cstring_in()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.cstring_in(cstring)
  RETURNS cstring
AS
$BODY$
cstring_in
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

