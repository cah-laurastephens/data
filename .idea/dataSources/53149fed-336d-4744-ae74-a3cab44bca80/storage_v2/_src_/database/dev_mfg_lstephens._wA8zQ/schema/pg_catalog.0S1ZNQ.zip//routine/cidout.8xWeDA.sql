CREATE FUNCTION cidout()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.cidout(cid)
  RETURNS cstring
AS
$BODY$
cidout
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

