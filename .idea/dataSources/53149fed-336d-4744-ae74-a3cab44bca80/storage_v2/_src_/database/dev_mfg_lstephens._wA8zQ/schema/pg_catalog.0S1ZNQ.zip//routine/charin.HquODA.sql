CREATE FUNCTION charin()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.charin(cstring)
  RETURNS char
AS
$BODY$
charin
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

