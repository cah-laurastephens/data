CREATE FUNCTION int4lt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.int4lt(int4, int4)
  RETURNS bool
AS
$BODY$
int4lt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

