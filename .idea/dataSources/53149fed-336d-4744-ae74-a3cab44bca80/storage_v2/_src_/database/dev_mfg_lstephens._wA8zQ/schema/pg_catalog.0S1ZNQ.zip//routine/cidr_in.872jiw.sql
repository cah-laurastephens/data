CREATE FUNCTION cidr_in()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.cidr_in(cstring)
  RETURNS cidr
AS
$BODY$
cidr_in
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

