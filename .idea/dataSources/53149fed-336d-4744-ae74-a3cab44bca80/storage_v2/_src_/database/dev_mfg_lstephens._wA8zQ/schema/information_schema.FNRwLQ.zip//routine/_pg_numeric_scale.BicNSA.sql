CREATE FUNCTION "_pg_numeric_scale"()
AS $$
CREATE OR REPLACE FUNCTION information_schema._pg_numeric_scale(typid oid, typmod int4)
  RETURNS int4
AS
$BODY$
SELECT
  CASE WHEN $1 IN (21, 23, 20) THEN 0
       WHEN $1 IN (1700) THEN
            CASE WHEN $2 = -1
                 THEN null
                 ELSE ($2 - 4) & 65535
                 END
       ELSE null
  END
$BODY$
LANGUAGE sql IMMUTABLE STRICT;
$$;

