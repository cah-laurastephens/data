CREATE FUNCTION btarraycmp()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.btarraycmp(anyarray, anyarray)
  RETURNS int4
AS
$BODY$
btarraycmp
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

