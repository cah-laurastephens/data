CREATE FUNCTION circle_below()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.circle_below(circle, circle)
  RETURNS bool
AS
$BODY$
circle_below
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

