CREATE FUNCTION int4smaller()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.int4smaller(int4, int4)
  RETURNS int4
AS
$BODY$
int4smaller
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

