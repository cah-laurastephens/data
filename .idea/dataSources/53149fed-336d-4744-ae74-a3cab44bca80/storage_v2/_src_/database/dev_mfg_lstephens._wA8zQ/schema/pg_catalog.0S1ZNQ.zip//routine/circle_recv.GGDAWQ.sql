CREATE FUNCTION circle_recv()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.circle_recv(internal)
  RETURNS circle
AS
$BODY$
circle_recv
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

