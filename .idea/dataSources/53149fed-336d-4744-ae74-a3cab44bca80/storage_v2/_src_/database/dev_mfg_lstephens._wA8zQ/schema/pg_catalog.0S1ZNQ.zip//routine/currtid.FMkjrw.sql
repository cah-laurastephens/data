CREATE FUNCTION currtid()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.currtid(oid, tid)
  RETURNS tid
AS
$BODY$
currtid_byreloid
$BODY$
LANGUAGE internal VOLATILE STRICT;
$$;

