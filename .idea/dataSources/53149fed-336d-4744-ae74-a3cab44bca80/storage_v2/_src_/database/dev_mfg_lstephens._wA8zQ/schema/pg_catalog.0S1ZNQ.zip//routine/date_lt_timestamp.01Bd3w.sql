CREATE FUNCTION date_lt_timestamp()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.date_lt_timestamp(date, timestamp)
  RETURNS bool
AS
$BODY$
date_lt_timestamp
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

