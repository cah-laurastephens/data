CREATE FUNCTION interval_pl_timestamptz()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.interval_pl_timestamptz(interval, timestamptz)
  RETURNS timestamptz
AS
$BODY$
select $2 + $1
$BODY$
LANGUAGE sql STABLE STRICT;
$$;

