CREATE FUNCTION interval_cmp()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.interval_cmp(interval, interval)
  RETURNS int4
AS
$BODY$
interval_cmp
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

