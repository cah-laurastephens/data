CREATE FUNCTION int4_avg_accum()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.int4_avg_accum(int8[], int4)
  RETURNS int8[]
AS
$BODY$
int4_avg_accum
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

