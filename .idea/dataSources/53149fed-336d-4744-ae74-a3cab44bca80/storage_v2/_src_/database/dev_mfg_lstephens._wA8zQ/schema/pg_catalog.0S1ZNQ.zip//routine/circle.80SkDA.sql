CREATE FUNCTION circle()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.circle(point[])
  RETURNS circle
AS
$BODY$
box_circle
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.circle(polygon)
  RETURNS circle
AS
$BODY$
poly_circle
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.circle(float8[], float8)
  RETURNS circle
AS
$BODY$
cr_circle
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

