CREATE FUNCTION interval_send()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.interval_send(interval)
  RETURNS bytea
AS
$BODY$
interval_send
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

