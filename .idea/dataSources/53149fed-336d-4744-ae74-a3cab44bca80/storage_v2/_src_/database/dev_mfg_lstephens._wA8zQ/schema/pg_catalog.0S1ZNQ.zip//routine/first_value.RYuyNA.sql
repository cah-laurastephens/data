CREATE FUNCTION first_value()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.first_value(bool)
  RETURNS bool
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.first_value(int8)
  RETURNS int8
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.first_value(int2)
  RETURNS int2
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.first_value(int4)
  RETURNS int4
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.first_value(text)
  RETURNS text
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.first_value(float4)
  RETURNS float4
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.first_value(float8)
  RETURNS float8
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.first_value(date)
  RETURNS date
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.first_value(timestamp)
  RETURNS timestamp
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.first_value(timestamptz)
  RETURNS timestamptz
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.first_value(interval)
  RETURNS interval
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
CREATE OR REPLACE FUNCTION pg_catalog.first_value(numeric)
  RETURNS numeric
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal IMMUTABLE;
$$;

