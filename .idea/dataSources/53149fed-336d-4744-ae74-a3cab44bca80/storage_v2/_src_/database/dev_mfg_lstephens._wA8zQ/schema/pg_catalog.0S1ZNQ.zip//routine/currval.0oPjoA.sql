CREATE FUNCTION currval()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.currval(text)
  RETURNS int8
AS
$BODY$
currval
$BODY$
LANGUAGE internal VOLATILE STRICT;
$$;

