CREATE FUNCTION date_in()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.date_in(cstring)
  RETURNS date
AS
$BODY$
date_in
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

