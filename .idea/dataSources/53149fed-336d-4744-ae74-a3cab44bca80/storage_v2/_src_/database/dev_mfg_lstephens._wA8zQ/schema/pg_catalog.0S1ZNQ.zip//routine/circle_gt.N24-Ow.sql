CREATE FUNCTION circle_gt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.circle_gt(circle, circle)
  RETURNS bool
AS
$BODY$
circle_gt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

