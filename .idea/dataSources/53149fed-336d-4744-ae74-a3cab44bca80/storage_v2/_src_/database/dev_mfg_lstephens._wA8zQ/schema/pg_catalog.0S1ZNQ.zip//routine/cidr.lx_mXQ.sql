CREATE FUNCTION cidr()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.cidr(text)
  RETURNS cidr
AS
$BODY$
text_cidr
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

