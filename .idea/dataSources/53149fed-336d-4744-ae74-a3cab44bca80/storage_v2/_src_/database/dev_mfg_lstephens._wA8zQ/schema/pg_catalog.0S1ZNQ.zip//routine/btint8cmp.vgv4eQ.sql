CREATE FUNCTION btint8cmp()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.btint8cmp(int8, int8)
  RETURNS int4
AS
$BODY$
btint8cmp
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

