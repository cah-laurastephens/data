CREATE FUNCTION interval_lt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.interval_lt(interval, interval)
  RETURNS bool
AS
$BODY$
interval_lt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

