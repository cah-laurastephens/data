CREATE FUNCTION int4out()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.int4out(int4)
  RETURNS cstring
AS
$BODY$
int4out
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

