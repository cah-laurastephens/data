CREATE FUNCTION bpcharicnlike()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.bpcharicnlike(bpchar, text)
  RETURNS bool
AS
$BODY$
texticnlike
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

