CREATE FUNCTION bpcharin()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.bpcharin(cstring, oid, int4)
  RETURNS bpchar
AS
$BODY$
bpcharin
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

