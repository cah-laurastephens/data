CREATE FUNCTION int4ne()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.int4ne(int4, int4)
  RETURNS bool
AS
$BODY$
int4ne
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

