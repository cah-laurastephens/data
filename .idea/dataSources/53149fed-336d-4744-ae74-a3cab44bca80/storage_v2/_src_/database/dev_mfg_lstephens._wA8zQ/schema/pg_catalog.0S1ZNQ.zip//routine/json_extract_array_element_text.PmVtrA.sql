CREATE FUNCTION json_extract_array_element_text()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.json_extract_array_element_text(text, int4)
  RETURNS text
AS
$BODY$
json_extract_array_element_text
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.json_extract_array_element_text(text, int4, bool)
  RETURNS text
AS
$BODY$
json_extract_array_element_text_tolerate_invalid
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

