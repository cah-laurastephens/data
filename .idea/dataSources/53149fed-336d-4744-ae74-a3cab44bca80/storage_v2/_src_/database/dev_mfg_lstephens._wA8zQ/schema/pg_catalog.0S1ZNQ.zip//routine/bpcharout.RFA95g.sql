CREATE FUNCTION bpcharout()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.bpcharout(bpchar)
  RETURNS cstring
AS
$BODY$
bpcharout
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

