CREATE FUNCTION btrim()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.btrim(text)
  RETURNS text
AS
$BODY$
btrim1
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.btrim(bytea, bytea)
  RETURNS bytea
AS
$BODY$
byteatrim
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.btrim(text, text)
  RETURNS text
AS
$BODY$
btrim
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

