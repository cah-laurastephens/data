CREATE FUNCTION bpcharne()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.bpcharne(bpchar, bpchar)
  RETURNS bool
AS
$BODY$
bpcharne
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

