CREATE FUNCTION ceiling()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.ceiling(float8)
  RETURNS float8
AS
$BODY$
dceil
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.ceiling(numeric)
  RETURNS numeric
AS
$BODY$
numeric_ceil
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

