CREATE FUNCTION istrue()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.istrue(bool)
  RETURNS bool
AS
$BODY$
istrue
$BODY$
LANGUAGE internal IMMUTABLE;
$$;

