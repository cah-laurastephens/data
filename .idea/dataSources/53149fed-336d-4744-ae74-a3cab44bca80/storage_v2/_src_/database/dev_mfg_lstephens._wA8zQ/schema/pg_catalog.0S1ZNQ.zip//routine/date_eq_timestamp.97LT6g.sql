CREATE FUNCTION date_eq_timestamp()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.date_eq_timestamp(date, timestamp)
  RETURNS bool
AS
$BODY$
date_eq_timestamp
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

