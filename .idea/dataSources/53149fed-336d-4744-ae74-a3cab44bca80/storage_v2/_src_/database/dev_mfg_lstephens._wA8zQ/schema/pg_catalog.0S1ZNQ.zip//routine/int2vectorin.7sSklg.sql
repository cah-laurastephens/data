CREATE FUNCTION int2vectorin()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.int2vectorin(cstring)
  RETURNS int2[]
AS
$BODY$
int2vectorin
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

