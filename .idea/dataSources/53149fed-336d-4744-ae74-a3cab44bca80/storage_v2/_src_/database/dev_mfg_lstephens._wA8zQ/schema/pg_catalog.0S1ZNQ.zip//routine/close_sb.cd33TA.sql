CREATE FUNCTION close_sb()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.close_sb(point[], point[])
  RETURNS float8[]
AS
$BODY$
close_sb
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

