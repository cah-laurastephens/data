CREATE FUNCTION int8_accum()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.int8_accum(numeric[], int8)
  RETURNS numeric[]
AS
$BODY$
int8_accum
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

