CREATE FUNCTION int8_avg()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.int8_avg(int8[])
  RETURNS int8
AS
$BODY$
int8_avg
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

