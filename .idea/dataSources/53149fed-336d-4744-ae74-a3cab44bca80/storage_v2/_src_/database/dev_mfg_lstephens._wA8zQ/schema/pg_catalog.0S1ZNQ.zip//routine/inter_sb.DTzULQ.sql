CREATE FUNCTION inter_sb()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.inter_sb(point[], point[])
  RETURNS bool
AS
$BODY$
inter_sb
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

