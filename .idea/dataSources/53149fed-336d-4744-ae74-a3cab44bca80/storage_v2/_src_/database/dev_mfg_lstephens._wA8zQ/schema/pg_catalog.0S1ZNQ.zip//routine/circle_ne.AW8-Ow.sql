CREATE FUNCTION circle_ne()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.circle_ne(circle, circle)
  RETURNS bool
AS
$BODY$
circle_ne
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

