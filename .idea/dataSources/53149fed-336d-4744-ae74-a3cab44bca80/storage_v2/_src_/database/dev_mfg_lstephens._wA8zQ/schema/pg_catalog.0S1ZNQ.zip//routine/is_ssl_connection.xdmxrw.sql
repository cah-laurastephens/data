CREATE FUNCTION is_ssl_connection()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.is_ssl_connection()
  RETURNS bool
AS
$BODY$
is_ssl_connection
$BODY$
LANGUAGE internal IMMUTABLE;
$$;

