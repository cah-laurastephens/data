CREATE FUNCTION date_trunc()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.date_trunc(text, timestamp)
  RETURNS timestamp
AS
$BODY$
timestamp_trunc
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.date_trunc(text, timestamptz)
  RETURNS timestamptz
AS
$BODY$
timestamptz_trunc
$BODY$
LANGUAGE internal STABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.date_trunc(text, interval)
  RETURNS interval
AS
$BODY$
interval_trunc
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

