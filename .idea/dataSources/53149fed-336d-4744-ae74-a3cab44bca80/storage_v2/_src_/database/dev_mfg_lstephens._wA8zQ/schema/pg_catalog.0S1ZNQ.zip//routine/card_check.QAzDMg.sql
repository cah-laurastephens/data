CREATE FUNCTION card_check()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.card_check(int8)
  RETURNS int8
AS
$BODY$
card_check
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

