CREATE FUNCTION int8_pl_timestamp()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.int8_pl_timestamp(int8, timestamp)
  RETURNS timestamp
AS
$BODY$
select $2 + $1
$BODY$
LANGUAGE sql IMMUTABLE STRICT;
$$;

