CREATE FUNCTION charout()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.charout(char)
  RETURNS cstring
AS
$BODY$
charout
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

