CREATE FUNCTION isopen()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.isopen(path)
  RETURNS bool
AS
$BODY$
path_isopen
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

