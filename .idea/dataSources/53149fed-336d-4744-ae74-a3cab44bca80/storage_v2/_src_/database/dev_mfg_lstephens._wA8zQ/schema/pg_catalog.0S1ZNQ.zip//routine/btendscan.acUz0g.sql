CREATE FUNCTION btendscan()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.btendscan(internal)
  RETURNS void
AS
$BODY$
btendscan
$BODY$
LANGUAGE internal VOLATILE STRICT;
$$;

