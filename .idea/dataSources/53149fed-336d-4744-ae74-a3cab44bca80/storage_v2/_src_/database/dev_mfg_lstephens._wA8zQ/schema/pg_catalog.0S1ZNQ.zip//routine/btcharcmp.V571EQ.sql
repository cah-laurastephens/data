CREATE FUNCTION btcharcmp()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.btcharcmp(char, char)
  RETURNS int4
AS
$BODY$
btcharcmp
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

