CREATE FUNCTION int8shr()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.int8shr(int8, int4)
  RETURNS int8
AS
$BODY$
int8shr
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

