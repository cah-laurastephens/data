CREATE FUNCTION date_ge()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.date_ge(date, date)
  RETURNS bool
AS
$BODY$
date_ge
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

