CREATE FUNCTION int8lt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.int8lt(int8, int8)
  RETURNS bool
AS
$BODY$
int8lt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

