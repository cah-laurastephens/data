CREATE FUNCTION bpchar_pattern_ge()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.bpchar_pattern_ge(bpchar, bpchar)
  RETURNS bool
AS
$BODY$
text_pattern_ge
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

