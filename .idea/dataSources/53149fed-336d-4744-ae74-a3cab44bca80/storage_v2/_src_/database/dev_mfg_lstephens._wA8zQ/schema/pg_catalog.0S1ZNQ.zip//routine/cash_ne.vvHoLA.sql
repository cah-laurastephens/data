CREATE FUNCTION cash_ne()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.cash_ne(money, money)
  RETURNS bool
AS
$BODY$
cash_ne
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

