CREATE FUNCTION bpcharlike()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.bpcharlike(bpchar, text)
  RETURNS bool
AS
$BODY$
textlike
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

