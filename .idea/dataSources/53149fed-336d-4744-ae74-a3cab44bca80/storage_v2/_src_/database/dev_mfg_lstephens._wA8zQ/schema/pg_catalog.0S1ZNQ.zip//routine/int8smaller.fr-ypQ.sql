CREATE FUNCTION int8smaller()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.int8smaller(int8, int8)
  RETURNS int8
AS
$BODY$
int8smaller
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

