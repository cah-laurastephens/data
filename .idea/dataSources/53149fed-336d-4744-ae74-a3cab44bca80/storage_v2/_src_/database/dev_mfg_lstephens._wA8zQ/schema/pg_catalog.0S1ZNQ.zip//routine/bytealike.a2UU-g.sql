CREATE FUNCTION bytealike()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.bytealike(bytea, bytea)
  RETURNS bool
AS
$BODY$
bytealike
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

