CREATE FUNCTION cash_div_int2()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.cash_div_int2(money, int2)
  RETURNS money
AS
$BODY$
cash_div_int2
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

