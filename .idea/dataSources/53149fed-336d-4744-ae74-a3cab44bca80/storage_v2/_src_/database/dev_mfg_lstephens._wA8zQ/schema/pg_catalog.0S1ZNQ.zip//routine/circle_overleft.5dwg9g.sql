CREATE FUNCTION circle_overleft()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.circle_overleft(circle, circle)
  RETURNS bool
AS
$BODY$
circle_overleft
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

