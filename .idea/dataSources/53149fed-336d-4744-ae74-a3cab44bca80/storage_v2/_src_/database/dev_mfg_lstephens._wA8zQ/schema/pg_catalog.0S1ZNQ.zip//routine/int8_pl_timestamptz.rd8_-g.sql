CREATE FUNCTION int8_pl_timestamptz()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.int8_pl_timestamptz(int8, timestamptz)
  RETURNS timestamptz
AS
$BODY$
select $2 + $1
$BODY$
LANGUAGE sql IMMUTABLE STRICT;
$$;

