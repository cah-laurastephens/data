CREATE FUNCTION is_valid_json()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.is_valid_json(text)
  RETURNS bool
AS
$BODY$
is_valid_json
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

