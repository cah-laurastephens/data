CREATE FUNCTION int4mul()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.int4mul(int4, int4)
  RETURNS int4
AS
$BODY$
int4mul
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

