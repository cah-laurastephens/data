CREATE FUNCTION circle_sub_pt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.circle_sub_pt(circle, float8[])
  RETURNS circle
AS
$BODY$
circle_sub_pt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

