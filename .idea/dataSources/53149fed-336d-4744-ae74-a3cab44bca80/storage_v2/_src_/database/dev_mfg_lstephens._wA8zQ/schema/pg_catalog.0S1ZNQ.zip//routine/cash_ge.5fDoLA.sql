CREATE FUNCTION cash_ge()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.cash_ge(money, money)
  RETURNS bool
AS
$BODY$
cash_ge
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

