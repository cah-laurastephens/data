CREATE FUNCTION charlt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.charlt(char, char)
  RETURNS bool
AS
$BODY$
charlt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

