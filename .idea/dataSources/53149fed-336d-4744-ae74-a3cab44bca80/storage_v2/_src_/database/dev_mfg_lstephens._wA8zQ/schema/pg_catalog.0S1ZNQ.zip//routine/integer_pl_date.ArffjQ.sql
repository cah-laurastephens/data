CREATE FUNCTION integer_pl_date()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.integer_pl_date(int4, date)
  RETURNS date
AS
$BODY$
select $2 + $1
$BODY$
LANGUAGE sql IMMUTABLE STRICT;
$$;

