CREATE FUNCTION cash_gt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.cash_gt(money, money)
  RETURNS bool
AS
$BODY$
cash_gt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

