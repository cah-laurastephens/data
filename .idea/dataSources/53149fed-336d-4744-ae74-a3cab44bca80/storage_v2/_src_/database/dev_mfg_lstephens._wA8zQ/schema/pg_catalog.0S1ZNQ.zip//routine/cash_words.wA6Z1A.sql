CREATE FUNCTION cash_words()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.cash_words(money)
  RETURNS text
AS
$BODY$
cash_words
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

