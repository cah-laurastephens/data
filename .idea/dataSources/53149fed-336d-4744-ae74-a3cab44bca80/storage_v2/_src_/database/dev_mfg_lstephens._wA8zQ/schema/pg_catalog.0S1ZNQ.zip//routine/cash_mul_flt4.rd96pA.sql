CREATE FUNCTION cash_mul_flt4()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.cash_mul_flt4(money, float4)
  RETURNS money
AS
$BODY$
cash_mul_flt4
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

