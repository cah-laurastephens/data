CREATE FUNCTION btint28cmp()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.btint28cmp(int2, int8)
  RETURNS int4
AS
$BODY$
btint28cmp
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

