CREATE FUNCTION json_extract_path_text()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.json_extract_path_text(text, text)
  RETURNS text
AS
$BODY$
json_extract_path_text_1
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.json_extract_path_text(text, text, bool)
  RETURNS text
AS
$BODY$
json_extract_path_text_tolerate_invalid_1
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.json_extract_path_text(text, text, text)
  RETURNS text
AS
$BODY$
json_extract_path_text_2
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.json_extract_path_text(text, text, text, bool)
  RETURNS text
AS
$BODY$
json_extract_path_text_tolerate_invalid_2
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.json_extract_path_text(text, text, text, text)
  RETURNS text
AS
$BODY$
json_extract_path_text_3
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.json_extract_path_text(text, text, text, text, bool)
  RETURNS text
AS
$BODY$
json_extract_path_text_tolerate_invalid_3
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.json_extract_path_text(text, text, text, text, text)
  RETURNS text
AS
$BODY$
json_extract_path_text_4
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.json_extract_path_text(text, text, text, text, text, bool)
  RETURNS text
AS
$BODY$
json_extract_path_text_tolerate_invalid_4
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.json_extract_path_text(text, text, text, text, text, text)
  RETURNS text
AS
$BODY$
json_extract_path_text_5
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
CREATE OR REPLACE FUNCTION pg_catalog.json_extract_path_text(text, text, text, text, text, text, bool)
  RETURNS text
AS
$BODY$
json_extract_path_text_tolerate_invalid_5
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

