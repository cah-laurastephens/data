CREATE FUNCTION btbpchar_pattern_cmp()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.btbpchar_pattern_cmp(bpchar, bpchar)
  RETURNS int4
AS
$BODY$
bttext_pattern_cmp
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

