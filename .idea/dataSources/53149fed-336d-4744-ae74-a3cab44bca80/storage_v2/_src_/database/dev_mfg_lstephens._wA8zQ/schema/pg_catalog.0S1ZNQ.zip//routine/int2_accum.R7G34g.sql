CREATE FUNCTION int2_accum()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.int2_accum(numeric[], int2)
  RETURNS numeric[]
AS
$BODY$
int2_accum
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

