CREATE FUNCTION int8gt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.int8gt(int8, int8)
  RETURNS bool
AS
$BODY$
int8gt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

