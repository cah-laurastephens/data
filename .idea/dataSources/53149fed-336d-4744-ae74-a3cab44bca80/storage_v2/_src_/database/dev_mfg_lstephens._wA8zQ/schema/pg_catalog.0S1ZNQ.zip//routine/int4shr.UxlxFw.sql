CREATE FUNCTION int4shr()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.int4shr(int4, int4)
  RETURNS int4
AS
$BODY$
int4shr
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

