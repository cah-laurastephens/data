CREATE FUNCTION cume_dist()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.cume_dist()
  RETURNS float8
AS
$BODY$
aggregate_dummy
$BODY$
LANGUAGE internal VOLATILE STRICT;
$$;

