CREATE FUNCTION isfalse()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.isfalse(bool)
  RETURNS bool
AS
$BODY$
isfalse
$BODY$
LANGUAGE internal IMMUTABLE;
$$;

