CREATE FUNCTION isnotfalse()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.isnotfalse(bool)
  RETURNS bool
AS
$BODY$
isnotfalse
$BODY$
LANGUAGE internal IMMUTABLE;
$$;

