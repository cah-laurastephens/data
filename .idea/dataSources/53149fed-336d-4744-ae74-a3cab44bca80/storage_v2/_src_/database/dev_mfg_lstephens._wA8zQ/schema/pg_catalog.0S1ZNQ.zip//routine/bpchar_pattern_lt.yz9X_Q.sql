CREATE FUNCTION bpchar_pattern_lt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.bpchar_pattern_lt(bpchar, bpchar)
  RETURNS bool
AS
$BODY$
text_pattern_lt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

