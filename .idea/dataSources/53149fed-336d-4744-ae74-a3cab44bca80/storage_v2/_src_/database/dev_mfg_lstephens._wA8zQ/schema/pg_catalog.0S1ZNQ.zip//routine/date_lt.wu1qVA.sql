CREATE FUNCTION date_lt()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.date_lt(date, date)
  RETURNS bool
AS
$BODY$
date_lt
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

