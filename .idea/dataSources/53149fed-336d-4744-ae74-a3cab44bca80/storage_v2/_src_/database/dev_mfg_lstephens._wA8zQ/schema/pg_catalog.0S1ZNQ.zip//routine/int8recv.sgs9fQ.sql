CREATE FUNCTION int8recv()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.int8recv(internal)
  RETURNS int8
AS
$BODY$
int8recv
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

