CREATE FUNCTION date_ne_timestamptz()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.date_ne_timestamptz(date, timestamptz)
  RETURNS bool
AS
$BODY$
date_ne_timestamptz
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

