CREATE FUNCTION btint2cmp()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.btint2cmp(int2, int2)
  RETURNS int4
AS
$BODY$
btint2cmp
$BODY$
LANGUAGE internal IMMUTABLE STRICT;
$$;

