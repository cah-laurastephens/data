CREATE FUNCTION contsel()
AS $$
CREATE OR REPLACE FUNCTION pg_catalog.contsel(internal, oid, internal, int4)
  RETURNS float8
AS
$BODY$
contsel
$BODY$
LANGUAGE internal STABLE STRICT;
$$;

