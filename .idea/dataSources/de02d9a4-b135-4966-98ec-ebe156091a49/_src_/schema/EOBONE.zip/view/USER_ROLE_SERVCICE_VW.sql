CREATE VIEW USER_ROLE_SERVCICE_VW AS SELECT
		f.facilityid AS facility_id,
		f.name AS facility_name,
		u.user_id,
		u.user_code,
		u.firstname,
		u.lastname,
		r.role_id,
		r.name AS role_name,
		s.service_id,
		s.name AS service_name
	FROM
		user_vw u
		JOIN
		user_fac_xref ufx ON (u.user_id = ufx.user_id)
		JOIN
		facility f ON (ufx.facility_id = f.facilityid)
		JOIN
		roles r ON (ufx.role_id = r.role_id)
		JOIN
		role_svc_xref rsx ON (r.role_id = rsx.role_id)
		JOIN
		service s ON (rsx.service_id = s.service_id)


/
