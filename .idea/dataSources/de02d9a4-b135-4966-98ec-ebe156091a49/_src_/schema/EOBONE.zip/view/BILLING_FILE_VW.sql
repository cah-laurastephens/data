CREATE VIEW BILLING_FILE_VW AS SELECT
		bf.billing_file_id,
		bf.facility_id,
		f.name facility_name,
		bf.name,
		bf.path,
		bf.size_bytes,
		bf.hash,
		bfs.name AS status,
		bft.name AS file_type,
		bff.name AS file_format,
		bf.creation_time,
		bf.modification_time
FROM
	billing_file bf
	JOIN
	facility f ON (bf.facility_id = f.facilityid)
	JOIN
	billing_file_status bfs ON (bf.billing_file_status_id = bfs.billing_file_status_id)
	JOIN
	billing_file_format bff ON (bf.billing_file_format_id = bff.billing_file_format_id)
	JOIN
	billing_file_type bft ON (bff.billing_file_type_id = bft.billing_file_type_id)


/
