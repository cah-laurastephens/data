CREATE VIEW USER_VW AS SELECT
	u.user_id,
	u.user_code,
	u.password,
	u.last_login_date,
	u.is_active,
	up.firstname,
	up.middlename,
	up.lastname,
	up.email,
	up.mobilephone,
	up.passquestion,
	up.passanswer,
	up.changepassword,
	up.user_info,
	ut.name AS user_type,
	up.email_notify,
	up.internal,
	u.at_dt_created,
	u.at_dt_password_changed,
	u.invalid_login_attempts,
	st.status AS account_status
FROM
	users u
	JOIN
	user_profile up ON (u.user_id = up.user_id)
	JOIN
	user_type ut ON (up.user_type_id = ut.user_type_id)
	LEFT JOIN
	account_status st ON (u.account_status_id = st.account_status_id)

/
