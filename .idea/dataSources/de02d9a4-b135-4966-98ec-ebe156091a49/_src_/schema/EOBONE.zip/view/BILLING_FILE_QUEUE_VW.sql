CREATE VIEW BILLING_FILE_QUEUE_VW AS SELECT
		billing_file_id,
		file_type,
		name,
		path,
		facility_id,
		facility_name,
		creation_time,
		TO_CHAR(creation_time, 'YYYY-MM-DD HH24:MI:SS') AS creation_time_text,
		size_bytes,
		ROUND((size_bytes / 1024), 4) AS size_kilobytes,
		ROUND((size_bytes / (1024 * 1024)), 4) AS size_megabytes,
		file_format,
		status
	FROM
		billing_file_vw
	WHERE
		status = 'NEW'
	ORDER BY
		creation_time


/
