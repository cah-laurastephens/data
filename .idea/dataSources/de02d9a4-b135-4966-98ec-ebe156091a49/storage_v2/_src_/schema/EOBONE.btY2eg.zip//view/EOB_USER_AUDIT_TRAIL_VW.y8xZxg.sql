CREATE VIEW EOB_USER_AUDIT_TRAIL_VW AS
  SELECT
		audit_id,
		facility_id,
		user_id,
		functionality_id,
		in_time,
		out_time,
		operation_status,
		misc,
		access_ip
FROM
	eob_user_audit_trail
	UNION
	(
		SELECT
			audit_id,
			facility_id,
			user_id,
			functionality_id,
			in_time,
			out_time,
			operation_status,
			misc,
			access_ip
		FROM
			eob_user_audit_archive
	)


/

