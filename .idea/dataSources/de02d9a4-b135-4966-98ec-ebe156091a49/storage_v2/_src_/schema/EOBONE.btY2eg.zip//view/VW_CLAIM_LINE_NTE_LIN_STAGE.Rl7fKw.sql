CREATE VIEW VW_CLAIM_LINE_NTE_LIN_STAGE AS
  SELECT
	claim_id,
	line_seq_no,
	claim_line_id,
	seq_no,
	rec_type,
	nte_type,
	nte_text,
	drug_qual,
	drug_ndc_no,
	drug_price,
	drug_qty,
	drug_UM,
	drug_rx_qual,
	drug_rx_no
FROM
	claim_line_nte_lin_stage


/

