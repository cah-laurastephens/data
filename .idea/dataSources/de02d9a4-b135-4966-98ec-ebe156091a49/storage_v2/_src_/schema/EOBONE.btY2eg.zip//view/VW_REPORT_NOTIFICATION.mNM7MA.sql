CREATE VIEW VW_REPORT_NOTIFICATION AS
  SELECT
	q.facility_id,
	q.user_id,
	q.date_last_modified AS date_notification_attempted,
	s.name AS notification_status,
	d.report_id,
	r.name AS report_name,
	r.path AS report_path,
	r.filesize AS report_file_size,
	r.startdate AS report_start_date,
	r.enddate AS report_end_date,
	c.description AS report_status,
	r.lastmodified AS report_last_modified,
	r.templateid AS report_template_id,
	t.rpt_path AS current_report_template_path,
	q.report_notification_queue_id
FROM
	report_notification_queue q
	JOIN
	report_notification_detail d ON (q.report_notification_queue_id = d.report_notification_queue_id)
	JOIN
	report_notification_status s ON (q.report_notification_status_id = s.report_notification_status_id)
	JOIN
	report_vw r ON (d.report_id = r.id)
	JOIN
	svc_rpt_details t ON (r.templateid = t.service_id)
	JOIN
	statuscodes c ON (r.status = c.status)


/

