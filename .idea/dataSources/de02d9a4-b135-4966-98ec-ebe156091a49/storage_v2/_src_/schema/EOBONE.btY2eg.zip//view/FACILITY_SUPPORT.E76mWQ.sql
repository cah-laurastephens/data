CREATE VIEW FACILITY_SUPPORT AS
  SELECT
		fsd.facility_id,
		fsd.date_remittance,
		fsd.date_claim,
		fsd.date_last_login,
		fsc.short_note,
		fsd.last_checked_date,
		fsd.ignore_billing_file_dates
	FROM
		facility_support_date fsd
		JOIN
		facility_support_comment fsc ON (fsd.facility_id = fsc.facility_id)
/

