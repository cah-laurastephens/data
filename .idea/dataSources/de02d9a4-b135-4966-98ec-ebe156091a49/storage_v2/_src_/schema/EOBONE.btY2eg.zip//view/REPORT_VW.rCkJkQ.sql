CREATE VIEW REPORT_VW AS
  SELECT
		rf.facility_id,
		r.id,
		r.name,
		r.path,
		r.templateid,
		r.content,
		r.filesize,
		r.startdate,
		r.enddate,
		r.hash,
		r.status,
		r.createtime,
		r.lastmodified,
		r.generation_start_time,
		r.generation_end_time,
		((r.generation_end_time - r.generation_start_time) * 24 * 60 * 60),
		((r.generation_end_time - r.generation_start_time) * 24 * 60)
	FROM
		reports r
		JOIN report_facility rf ON (r.id = rf.report_id)


/

