CREATE VIEW VW_NEW_PAYERS AS
  SELECT DISTINCT
  REPLACE(ep.payername, '*') AS payer_name,
  ep.payerid AS payer_id,
  f.name AS facility_name,
  f.facilityid AS facility_id
FROM
  eob_payer ep
  LEFT JOIN
  remit_claims_extract rce ON (ep.payerid = rce.payer_id)
  LEFT JOIN
  facility f ON (rce.facility_id = f.facilityid)
WHERE
  ep.payername LIKE '%*%'
ORDER BY
  REPLACE(ep.payername, '*'),
  ep.payerid,
  f.name,
  f.facilityid


/

